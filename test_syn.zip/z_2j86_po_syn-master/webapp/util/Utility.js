/**************************************************************************************************************************************
* Project                : PO Synthesis 
* Module                 : V1
* Functional document    : ...
* Technical document     : ...
*-------------------------------------------------------------------------------------------------------------------------------------
* File name              : Utility.js
* Written by             : 
* Company                : Sopra Steria
*--------------------------------------------------------------------------------------------------------------------------------------
* File description       : This file is used to handle all the miscellaneous function
*--------------------------------------------------------------------------------------------------------------------------------------
***************************************************************************************************************************************/
sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/json/JSONModel", "sap/ui/core/util/Export", "sap/ui/core/util/ExportTypeCSV", "sap/m/MessageBox"], function (Controller, JSONModel, Export, ExportTypeCSV, MessageBox) {
    "use strict";

    return {


        /**
 		 * @HJC  on 09.09.2019
 		 * 
		 * @function: getPODeliveredDataSetStyle
 		 * @description:  Manage Dataset Styling for PO by Month Chart
 		 * @param:
         */

        getPODeliveredDataSetStyle : function() {

            var CurrYear = new Date().getFullYear();
            var PrvYear = new Date().getFullYear() - 1;
            var NxtYear = new Date().getFullYear() + 1;

            var oStyle = {
                "rules":
                    [
                        {
                            "dataContext": {"PrevCount": '*'},
                            "properties": {
                                "color":"#339dbd",
                                "lineColor":"#339dbd"
                            },
                            "displayName": PrvYear,
                            "dataName" : {
                                "PrevCount" : PrvYear
                            }
                        },
                        {
                            "dataContext": {"CurrCount": '*'},
                            "properties": {
                                "color":"#00205b",
                                "lineColor":"#00205b"
                            },
                            "displayName": CurrYear,
                             "dataName" : {
                                "CurrCount" : CurrYear
                            }
                        },
                        {
                            "dataContext": {"NextCount": '*'},
                            "properties": {
                                "color":"#84bd5b",
                                "lineColor":"#84bd5b"
                            },
                            "displayName": NxtYear,
                            "dataName" : {
                                "NextCount" : NxtYear
                            }
                        }
            
                    ]
            };

            return oStyle;

        },


		/**
 		 * @HJC  on 09.09.2019
 		 * 
		 * @function: getFALDataSetStyle
 		 * @description:  Manage Dataset Styling for PO by FAL Chart
 		 * @param: 
		 */

        getFALDataSetStyle : function(){

            var oStyle = {
                "rules":
                    [
                        {
                            "dataContext": {"TLSCount": '*'},
                            "properties": {
                                "color":"#780a67",
                                "lineColor":"#780a67"
                            },
                            "displayName":"Toulouse",
                            "dataName" : {
                                "TLSCount" : "Toulouse"
                            }
                        },
                        {
                            "dataContext": {"HMBCount": '*'},
                            "properties": {
                                "color":"#03b076",
                                "lineColor":"#03b076"
                            },
                            "displayName":"Hambourg",
                             "dataName" : {
                                "HMBCount" : "Hambourg"
                            }
                        },
                        {
                            "dataContext": {"MOBCount": '*'},
                            "properties": {
                                "color":"#e1e000",
                                "lineColor":"#e1e000"
                            },
                            "displayName":"Mobile",
                            "dataName" : {
                                "MOBCount" : "Mobile"
                            }
                        },
                        {
                            "dataContext": {"TJNCount": '*'},
                            "properties": {
                                "color":"#84BD00",
                                "lineColor":"#84BD00"
                            },
                            "displayName":"Tianjin",
                            "dataName" : {
                                "TJNCount" : "Tianjin"
                            }
                        },
                        {
                            "dataContext": {"NOFALCount": '*'},
                            "properties": {
                                "color":"#8f9295",
                                "lineColor":"#8f9295"
                            },
                            "displayName":"No FAL",
                            "dataName" : {
                                "NOFALCount" : "No FAL"
                            }
                        }
            
                    ]
            };

            return oStyle;

        },
        
        /**
 		 * @HJC  on 09.09.2019
 		 * 
		 * @function: getNetPriceDataStyle
 		 * @description:  Manage Dataset Styling for PO Median Net Price 
 		 * @param: 
         */

         getNetPriceDataStyle : function(){

            var oStyle = {
                "rules":
                    [
                        {
                            "dataContext": {"MaxPrice": '*'},
                            "properties": {
                                "color":"#00205b",
                                "lineColor":"#00205b",
                                "lineType":"line"
                            },
                            "displayName":"PO Max. Value",
                            "dataName" : {
                                "MaxPrice" : "PO Max. Value"
                            }
                        },
                        {
                            "dataContext": {"MedianPrice": '*'},
                            "properties": {
                                "color":"#84bd5b",
                                "lineColor":"#84bd5b",
                                "lineType":"dash"
                            },
                            "displayName":"Median",
                            "dataName" : {
                                "MedianPrice" : "Median"
                            }
                        },
                        {
                            "dataContext": {"MinPrice": '*'},
                            "properties": {
                                "color":"#339dbd",
                                "lineColor":"#339dbd",
                                "lineType":"line"
                            },
                            "displayName":"PO Min. Value",
                            "dataName" : {
                                "MinPrice" : "PO Min. Value"
                            }
                        }

                    ]
            };

            return oStyle;
         },

         /**
 		 * @HJC  on 09.09.2019
 		 * 
		 * @function: setPriceModel
 		 * @description:  Fill Net Price model when the User update the Filter
 		 * @param: oView, aFilters
          */

         setPriceModel : function(oView, aFilters){
             var oModel= oView.getModel("digital");
             var oPriceModel = oView.getModel("LocalPrice");

             oModel.read("/ETPOSynAvgNetPriceSet",{
                filters : aFilters,
                success : function(data) {
                    oPriceModel.setProperty("/Price", data.results);
                    }
            });


         }

};
});