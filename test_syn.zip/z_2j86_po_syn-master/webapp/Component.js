sap.ui.define([ "sap/ui/core/UIComponent", "sap/ui/Device" ], function(UIComponent, Device) {
    "use strict";

    return UIComponent.extend("airbus.ui.po_synthesis.Component", {

	metadata : {
		manifest : "json",
		config : {
			fullWidth : true
		}
	},

	/**
	 * The component is initialized by UI5 automatically during the startup
	 * of the app and calls the init method once.
	 * 
	 * @public
	 * @override
	 */
	init : function() {
	    // call the base component's init function
		UIComponent.prototype.init.apply(this, arguments);
		
		var oLocalPriceModel = new sap.ui.model.json.JSONModel();
		var oModel = this.getModel("digital");
		oModel.read("/ETPOSynAvgNetPriceSet",{
			success : function(data) {
				oLocalPriceModel.setProperty("/Price", data.results);
				}
		});

		this.setModel(oLocalPriceModel, "LocalPrice");
	    // enable routing
	    var oRouter = this.getRouter();
	    if (oRouter) {
		oRouter.initialize();
	    }
	}

    });
});