/*******************************************************************************
 * Project : PO Activity Synthesis : Functional document : ... Technical
 * document : ...
 * -------------------------------------------------------------------------------------------------------------------------------------
 * File name : ManageSynthesis.controller.js Written by : SOPARA Team Company :
 * Sopra Steria Creation date : 07.08.2018
 * --------------------------------------------------------------------------------------------------------------------------------------
 * File description : This controller contains the functions that are supposed
 * to be called inside several screens in the application
 * --------------------------------------------------------------------------------------------------------------------------------------
 * Last modification date : Author : Description : Transport order :
 ******************************************************************************/

sap.ui.define(["airbus/ui/po_synthesis/controller/BaseController", 'sap/ui/model/json/JSONModel', "sap/m/MessageBox", 'sap/ui/model/Filter', 
'sap/ui/model/FilterOperator', "airbus/ui/po_synthesis/util/Utility", "sap/viz/ui5/controls/Popover", "sap/ui/core/HTML"],
	function (BaseController, JSONModel, MessageBox, Filter, FilterOperator, Utility, Popover, HTMLControl) {

		"use strict";

		return BaseController.extend("airbus.ui.po_synthesis.controller.ManageSynthesis", {

			utility: Utility,

			/**
 			 * @HJC for US BLM  on 28.08.2019
 			 * @description: Define Local Model to manage Popover Style and action for Average Net Price Chart
			 */

			settingsModel : {
				dataset : {
					name: "Custom Popover",
					defaultSelected : 0,
					values : [{
						name : "Custom Content",
						value : [{
							type: 'action',
							text: 'Go to PO',
							press: function(oEvent) {
								var sPONumber = jQuery.sap.getObject("airbus.global.digital.SelectedPO");

								if(sPONumber !== ""){
									var sDisplayPOUrl = window.location.origin + "/sap/bc/ui2/flp#ZSO_2J86_DISP_PO-display&//C_PurchaseOrderTP(PurchaseOrder='" + sPONumber
									+ "',DraftUUID=guid'00000000-0000-0000-0000-000000000000',IsActiveEntity=true)";
				
								var sWindow = Math.random().toString(36).replace(/[^a-z]+/g, '');
								var oWin = window.open(sDisplayPOUrl, sWindow);
								oWin.focus();
								}
							}
						}],
						popoverProps : {
							'customDataControl' : function(data){
								if (data.data.val) {
									
									var sPath;
									var sColor = data.data.color;
									var iSelectedIndex = data.data.val[1].value;
									var sId = data.data.val[2].id.substr(0,3);

									if (sId === "Max"){
										sPath = "/Price/" + iSelectedIndex + "/PO_max";
									}
									else if (sId === "Min"){
										sPath = "/Price/" + iSelectedIndex + "/PO_min";
									}
									
									var LocalPriceModel = jQuery.sap.getObject("airbus.global.digital.ManageSynthesis").getModel("LocalPrice");
									var sPONumber = LocalPriceModel.getProperty(sPath);

									jQuery.sap.setObject("airbus.global.digital.SelectedPO", sPONumber);

									var values = data.data.val, divStr = "", idx = values[1].value;
									var svg = "<svg width='20px' height='10px'><line x1='0' y1='5' x2='20' y2='5' stroke-width='2' stroke='" +
									          sColor + "'></line><path d='M-3,0 A3,3 0 1,0 3,0 A3,3 0 1,0 -3,0z' fill='" + sColor + "' transform='translate(10,5)'></path></svg>";
									divStr = divStr + "<div style = 'margin: 15px 30px 0 10px'>" + svg + "<b style='margin-left:10px'>" + values[0].value + "</b></div>";
									divStr = divStr + "<div style = 'margin: 5px 30px 0 30px'>" + values[2].name + "<b style = 'float: right'>" + values[2].value + "</b></div>";
									divStr = divStr + "<div style = 'margin: 5px 30px 15px 30px'>" + "PO Number<b style = 'float: right'>" + sPONumber + "</b></div>";
									return new HTMLControl({content:divStr});
								}
							}
						}
					}]
				}
			},
			

			/**
			 * 
			 * 
			 */
			onInit: function () {

				// Set the controller inside a global variable
				jQuery.sap.setObject("airbus.global.digital.ManageSynthesis", this);

				var oView = this.getView();
				var oModel = this.getOwnerComponent().getModel("digital");

				oView.setModel(oModel);

				var oSettingsModel = new JSONModel(this.settingsModel);
                this.getView().setModel(oSettingsModel, "settings");

				var oRouter = this.getOwnerComponent().getRouter();
				oRouter.getRoute("manageSynthesis").attachPatternMatched(this.onRouteMatched, this);

			},


			/**
			 * @function: beforePobymonthChartBind
			 * @description: Manage Viz Property for the PO by Month chart
			 * @HJC for BLM-330
			 */

			beforePobymonthChartBind : function(oEvent){

				var oView = this.getView();
				var mBindingParams = oEvent.getParameter("bindingParams");
				var sProgram = oView.byId("idProgram").getSelectedKey();
				var oChart = oView.byId("idPObyMonth").getChart();

				oChart.setVizProperties({
					dataLabel: {
						formatString: null, //sap.viz.ui5.format.ChartFormatter.DefaultPattern.SHORTFLOAT_MFD2,
						visible: true						
					},
					categoryAxis: {
						title: {
							visible: true							
						}
					},
					valueAxis: {
						title: {
							visible: true,
							text: "Number of PO"							
						},
						label: {
							formatString: null
						}
					},
					plotArea:{
						colorPalette:['#339dbd', '#00205b','#84bd5b'],
						dataPointStyle: this.utility.getPODeliveredDataSetStyle()
					}
					
				});

				if(sProgram !== ""){
					mBindingParams.filters.push(new Filter({
						path: "Zzpgm",
						operator: FilterOperator.EQ,
						value1: sProgram
					}));
				}
				
				
			},
                // CD128005
                beforePobyweekChartBind : function(oEvent){

				var oView = this.getView();
				var mBindingParams = oEvent.getParameter("bindingParams");
				var sProgram = oView.byId("idProgram").getSelectedKey();
				var oChart = oView.byId("idPObyWeek").getChart();

				oChart.setVizProperties({
					dataLabel: {
						formatString: null, //sap.viz.ui5.format.ChartFormatter.DefaultPattern.SHORTFLOAT_MFD2,
						visible: true						
					},
					categoryAxis: {
						title: {
							visible: true							
						}
					},
					valueAxis: {
						title: {
							visible: true,
							text: "Number of PO"							
						},
						label: {
							formatString: null
						}
					},
					plotArea:{
						colorPalette:['#339dbd', '#00205b','#84bd5b'],
						dataPointStyle: this.utility.getPODeliveredDataSetStyle()
					}
					
				});

				if(sProgram !== ""){
					mBindingParams.filters.push(new Filter({
						path: "Zzpgm",
						operator: FilterOperator.EQ,
						value1: sProgram
					}));
				}
				// CD128005
				
			},

			/**
 			 * @HJC for US BLM  on 23.07.2019
 			 * 
			 * @function: beforePOYearChartBind
 			 * @description: Manage Viz Property for the PO by Year chart
 			 * @param: oEvent
			 */

			beforePOYearChartBind : function(oEvent){
				var oView = this.getView();
				var mBindingParams = oEvent.getParameter("bindingParams");
				var sProgram = oView.byId("idProgram").getSelectedKey();
				var oChart = oView.byId("idPobyYear").getChart();

				oChart.setVizProperties({
					dataLabel: {
						formatString: null, // sap.viz.ui5.format.ChartFormatter.DefaultPattern.SHORTFLOAT_MFD2,
						visible: false,
						showTotal: true
					},
					categoryAxis: {
						title: {
							visible: true							
						}
					},
					valueAxis: {
						title: {
							visible: true,
							text: "Number of PO"							
						},
						label: {
							formatString: null
						}
					},
					plotArea:{
						colorPalette:['#339dbd', '#00205b','#84bd5b'],
						dataPointStyle: this.utility.getPODeliveredDataSetStyle()	
							
					}
					
				});

				if(sProgram !== ""){
					mBindingParams.filters.push(new Filter({
						path: "Zzpgm",
						operator: FilterOperator.EQ,
						value1: sProgram
					}));
				}
			},

			/**
 			 * @HJC for US BLM  on 23.08.2019
 			 * 
			 * @function: beforeFalbymonthChartBind
 			 * @description: Manage Viz Property for the PO per FAL by Month chart
 			 * @param: 
			 */

			beforeFalbymonthChartBind: function(oEvent){
				var oView = this.getView();
				var mBindingParams = oEvent.getParameter("bindingParams");
				var sProgram = oView.byId("idProgram").getSelectedKey();
				var oChart = oView.byId("idFALbyMonth").getChart();

				oChart.setVizProperties({
					dataLabel: {
						formatString: null,
						visible: false,
						showTotal: true
					},
					general: {
						enableScalingFactor: true
					},
					categoryAxis: {
						title: {
							visible: true,
							text: "Month of delivery"														
						}
					},
					valueAxis: {
						title: {
							visible: true,
							text: "Number of PO"							
						},
						label: {
							formatString: null
						}
					},
					plotArea:{
						colorPalette:["#780a67", "#03b076","#e1e000", "#8f9295", "#84BD00"],
						dataPointStyle: this.utility.getFALDataSetStyle(),
						dataPointSize: {
							min : 15, max : 15
						}						
					}

					
				});

				if(sProgram !== ""){
					mBindingParams.filters.push(new Filter({
						path: "Zzpgm",
						operator: FilterOperator.EQ,
						value1: sProgram
					}));
				}
			},

			/**
 			 * @HJC for US BLM  on 23.08.2019
 			 * 
			 * @function: beforeFALbyYearChartBind
 			 * @description: Manage Viz Property for the PO per FAL by Year chart
 			 * @param: 
			 */

			beforeFALbyYearChartBind : function(oEvent){

				var oView = this.getView();
				var mBindingParams = oEvent.getParameter("bindingParams");
				var sProgram = oView.byId("idProgram").getSelectedKey();
				var oChart = oView.byId("idFALbyYear").getChart();

				oChart.setVizProperties({
					dataLabel: {
						formatString: null,
						visible: false,
						showTotal: true
					},
					general: {
						enableScalingFactor: true
					},
					categoryAxis: {
						title: {
							visible: true							
						}
					},
					valueAxis: {
						title: {
							visible: true,
							text: "Number of PO"							
						},
						label: {
							formatString: null
						}
					},
					plotArea:{
						colorPalette:["#780a67", "#03b076","#e1e000", "#8f9295", "#84BD00"],
						dataPointStyle: this.utility.getFALDataSetStyle()						
					}

					
				});

				if(sProgram !== ""){
					mBindingParams.filters.push(new Filter({
						path: "Zzpgm",
						operator: FilterOperator.EQ,
						value1: sProgram
					}));
				}

			},

			/**
 			 * @SSH for US BLM  on 23.08.2019
 			 * 
			 * @function: beforePreqnotOrderedChartBind
 			 * @description:  Manage Viz Property for the Preq not Ordered for coming 18 months
 			 * @param: 
			 */

			beforePreqnotOrderedChartBind : function(oEvent){

				var oView = this.getView();
				var mBindingParams = oEvent.getParameter("bindingParams");
				var sProgram = oView.byId("idProgram").getSelectedKey();
				var oChart = oView.byId("idPreqnotOrdered").getChart();
				
				if( mBindingParams.filters.length > 0)
				{
					var oFilters = mBindingParams.filters[0].aFilters;

					if(oFilters.length == 1	)
					{
						for(var i in oFilters)
						{	
							if(mBindingParams.filters[0].aFilters[i].sPath == "Tlifnr")
								mBindingParams.filters = [];
						}
					}
					else if(oFilters.length > 1	)
					{
						for(var i in oFilters)
						{	
							if(mBindingParams.filters[0].aFilters[i].aFilters[0].sPath == "Tlifnr")
							mBindingParams.filters[0].aFilters.pop(i);
						}
					}
				}
				

				oChart.setVizProperties({
					dataLabel: {
						formatString: null,
						visible: false,
						showTotal: true
					},
					general: {
						enableScalingFactor: true
					},
					categoryAxis: {
						title: {
							visible: true							
						}
					},
					valueAxis: {
						title: {
							visible: true,
							text: "Number of Preq"							
						},
						label: {
							formatString: null
						}
					},
					plotArea:{
						colorPalette:["#339dbd"]
					}

					
				});

				if(sProgram !== ""){
					mBindingParams.filters.push(new Filter({
						path: "Zzpgm",
						operator: FilterOperator.EQ,
						value1: sProgram
					}));
				}

			},

			/**
 			 * @HJC for US BLM  on 23.08.2019
 			 * 
			 * @function: beforePObyNetpriceChartBind
 			 * @description:  Manage Viz Property for PO Median net price chart 
 			 * @param: 
			 */

			beforePObyNetpriceChartBind: function(oEvent){

				var oView = this.getView();
				var mBindingParams = oEvent.getParameter("bindingParams");
				var sProgram = oView.byId("idProgram").getSelectedKey();
				var oChart = oView.byId("idPObyNetPrice").getChart();

				oChart.attachSelectData(this.onSelectData, this);

				oView.byId("idPObyNetPrice").setSelectionMode("SINGLE");

				oChart.setVizProperties({
					dataLabel: {
						visible: false,
						showTotal: true
					},
					general: {
						enableScalingFactor: true
					},
					categoryAxis: {
						title: {
							visible: true						
						},
						label: {
							angle: 30
						}
					},
					valueAxis: {
						title: {
							visible: true,
							text: "Net Price"							
						}
					},
					plotArea:{
						colorPalette:['#339dbd','#84bd5b','#00205b'],
						dataPointStyle: this.utility.getNetPriceDataStyle()
					}

					
				});

				if(sProgram !== ""){
					mBindingParams.filters.push(new Filter({
						path: "Zzpgm",
						operator: FilterOperator.EQ,
						value1: sProgram
					}));
				}

				// Update Net Price Model data
				this.utility.setPriceModel(oView, mBindingParams.filters);

			},

			/**
 			 * @HJC for US BLM  on 02.09.2019
 			 * 
			 * @function: onDataPress
 			 * @description: Open data in tabular form for PO by Month Chart
 			 * @param: 
			 */

			onDataPress : function(){
				var oModel = this.getModel();
				var oChart = this.getView().byId("idPObyMonth").getChart();
				var aFilters = oChart.mBindingInfos.data.filters;

				if (!this.oDataDialog) {
					this.oDataDialog = sap.ui.xmlfragment("airbus.ui.po_synthesis.fragment.PObyMonthTable", this);
					this.getView().addDependent(this.oDataDialog);
				}

				// Rebind table with the Filter applied
				this.oDataDialog.getContent()[0].getBinding("items").filter(aFilters);
		
				this.oDataDialog.setModel(oModel);
				this.oDataDialog.open();
			},

			/**
 			 * @HJC for US BLM  on 02.09.2019
 			 * 
			 * @function: onOKPress
 			 * @description: Close dialog with data in Tabular Form
 			 * @param: 
			 * 
			 */

			onOKPress: function() {
				if(this.oDataDialog){
					this.oDataDialog.close();
				}

				if(this.oFALDataDialog){
					this.oFALDataDialog.close();
				}

				
			},

            //CD128005
			onDataPressWeek : function(){
				var oModel = this.getModel();
				var oChart = this.getView().byId("idPObyWeek").getChart();
				var aFilters = oChart.mBindingInfos.data.filters;

				if (!this.oDataDialogWeek) {
					this.oDataDialogWeek = sap.ui.xmlfragment("airbus.ui.po_synthesis.fragment.PObyWeekTable", this);
					this.getView().addDependent(this.oDataDialogWeek);
				}

				// Rebind table with the Filter applied
				this.oDataDialogWeek.getContent()[0].getBinding("items").filter(aFilters);
		
				this.oDataDialogWeek.setModel(oModel);
				this.oDataDialogWeek.open();
			},

			onOKPressWeek: function() {
				if(this.oDataDialogWeek){
					this.oDataDialogWeek.close();
				}

				if(this.oDataDialogWeek){
					this.oDataDialogWeek.close();
				}

				
			},

           //CD128005

			/**
 			 * @HJC for US BLM  on 05.09.2019
 			 * 
			 * @function: onFALDataPress
 			 * @description: Open data in tabular form for PO per FAL by Month Chart
 			 * @param: 
			 */

			onFALDataPress: function() {

				var oModel = this.getModel();
				var oChart = this.getView().byId("idFALbyMonth").getChart();
				var aFilters = oChart.mBindingInfos.data.filters;
				
				if (!this.oFALDataDialog) {
					this.oFALDataDialog = sap.ui.xmlfragment("airbus.ui.po_synthesis.fragment.PObyFALTable", this);
					this.getView().addDependent(this.oFALDataDialog);
				}

				// Rebind table with the Filter applied
				this.oFALDataDialog.getContent()[0].getBinding("items").filter(aFilters);
	
				this.oFALDataDialog.setModel(oModel);
				this.oFALDataDialog.open();
			},

			/**
 			 * @HJC for US BLM  on 28.08.2019
 			 * 
			 * @function: onSelectData
 			 * @description: Display chart Popover for the Average Net Price chart 
 			 * @param: 
			 */
			onSelectData : function(oEvent){
				var oPopOver;
				var oChart = oEvent.getSource();
				if (oEvent.mParameters.data[0].data.measureNames !== "MedianPrice"){					
					oPopOver = new Popover(this.getModel("settings").oData.dataset.values[0].popoverProps);
					oPopOver.connect(oChart.getVizUid());  
					oPopOver.setActionItems(this.getModel("settings").oData.dataset.values[0].value);
				}
				else{
					oPopOver = new Popover();
					oPopOver.connect(oChart.getVizUid());  
				}
			},

			/**
 			 * @HJC for US BLM  on 23.07.2019
 			 * 
			 * @function: onVariantLoad
 			 * @description: Manage Custom fields when Varient is Loaded
 			 * @param: 
 			 */

			 onVariantLoad: function (oEvent) {
				var oSource = oEvent.getSource();
				var oCustomData = oSource.getFilterData(true)["_CUSTOM"];
				if (oCustomData) {
					this.getView().byId("idProgram").setSelectedKey(oCustomData.program);
				}
				else {
					this.getView().byId("idProgram").setSelectedKey("");
				}

				// Trigger filter after the Varient Load
				this.getView().byId("idSmartSynthesis").fireSearch();
			},


			/**
			 * @HJC for US BLM 307 on 23.07.2019
			 * 
			 * @function: onVariantSave
			 * @description: Manage Custom fields when Varient is Saved
			 * @param: 
			 */

			onVariantSave: function (oEvent) {
				var oSource = oEvent.getSource();
				var sProgram = this.getView().byId("idProgram").getSelectedKey();

				oSource.setFilterData({
					_CUSTOM: {
						program: sProgram
					}
				});
			}

		});
	});

