sap.ui.define([ "sap/ui/core/UIComponent", "sap/ui/Device" ], function(UIComponent, Device) {
    "use strict";

    return UIComponent.extend("airbus.ui.po_validation.Component", {

	metadata : {
		manifest : "json",
		config : {
			fullWidth : true
		}
	},

	/**
	 * The component is initialized by UI5 automatically during the startup
	 * of the app and calls the init method once.
	 * 
	 * @public
	 * @override
	 */
	init : function() {
	    // call the base component's init function
		UIComponent.prototype.init.apply(this, arguments);
		
	    // enable routing
	    var oRouter = this.getRouter();
	    if (oRouter) {
		oRouter.initialize();
	    }
	}
    });

});