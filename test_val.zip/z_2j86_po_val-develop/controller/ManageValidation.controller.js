/*******************************************************************************
 * Project : PO Activity Synthesis : Functional document : ... Technical
 * document : ...
 * -------------------------------------------------------------------------------------------------------------------------------------
 * File name : ManageSynthesis.controller.js Written by : SOPARA Team Company :
 * Sopra Steria Creation date : 07.08.2018
 * --------------------------------------------------------------------------------------------------------------------------------------
 * File description : This controller contains the functions that are supposed
 * to be called inside several screens in the application
 * --------------------------------------------------------------------------------------------------------------------------------------
 * Last modification date : Author : Description : Transport order :
 ******************************************************************************/

sap.ui.define(["airbus/ui/po_validation/controller/BaseController", 'sap/ui/model/json/JSONModel', "sap/m/MessageBox", 'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator', "sap/ui/core/util/Export", "sap/ui/core/util/ExportTypeCSV"],
	function (BaseController, JSONModel, MessageBox, Filter, FilterOperator, Export, ExportTypeCSV) {

		"use strict";

		return BaseController.extend("airbus.ui.po_validation.controller.ManageValidation", {


			/**
			 * 
			 * 
			 */
			onInit: function () {

				var oView = this.getView();
				var oModel = this.getOwnerComponent().getModel("digital");

				oView.setModel(oModel);

				var oSettingsModel = new JSONModel(this.settingsModel);
				this.getView().setModel(oSettingsModel, "settings");

				var oRouter = this.getOwnerComponent().getRouter();
				oRouter.getRoute("manageValidation").attachPatternMatched(this.onRouteMatched, this);

			},

			/**
			 * 
			 * 
			 */
			onRouteMatched: function () {
				//initialize fragment for po creation popover
				this.oMessagePopover = sap.ui.xmlfragment('airbus.ui.po_validation.fragment.MessagePopOver', this);
				this.getView().addDependent(this.oMessagePopover);
			},

			/**
			 * @function: onBeforeBind
			 * @description: To allow input help on Program Filter Bar
			 * @KVE for US no.##
			 */
			onBeforeBind: function (oEvent) {
				var mBindingParams = oEvent.getParameter("bindingParams");
				var aProgram = this.getView().byId("idProgramPOval").getSelectedItems();

				for (var i in aProgram) {
					if (aProgram[i].getKey() !== "") {
						mBindingParams.filters.push(new Filter({
							path: "Zzprogram",
							operator: FilterOperator.EQ,
							value1: aProgram[i].getKey()
						}));
					}
				}
			},
			/**
			 * @function: onClearOVWFilter
			 * @description: Custom filter clearance
			 * @KVE for US no.##
			 */
			onClearOVWFilter: function (oEvent) {
				//Custom filter clearance
				this.getView().byId("idProgramPOval").clearSelection();
			},
            /**
			 * @function: onVariantLoad
			 * @description: Custom filter variant Load
			 * @KVE for US no.##
			 */
			onVariantLoad: function (oEvent) {
				var oSource = oEvent.getSource();
				var oCustomData = oSource.getFilterData(true)["_CUSTOM"];
				if (oCustomData) {
					this.getView().byId("idProgramPOval").setSelectedKeys(oCustomData.Zzprogram);
				}
			},
            /**
			 * @function: onVariantSave
			 * @description: Custom filter variant Save
			 * @KVE for US no.##
			 */
			onVariantSave: function (oEvent) {
				var oSource = oEvent.getSource();
				var aProgram = this.getView().byId("idProgramPOval").getSelectedKeys();

				oSource.setFilterData({
					_CUSTOM: {
						Zzprogram: aProgram
					}
				});
			},

			/**
			 * 
			 */

			onRowSelect: function (oEvent) {
				var i;
				try {
					var oSource = oEvent.getSource();
					var bMultiSelect = oEvent.getParameter('selectAll');
					var oContext = oEvent.getParameter('rowContext');
					var oModel = oSource.getBinding().getModel();

					var bSelect;
					var aRows = oEvent.getParameter('rowIndices');
					var sRowIndex = oEvent.getParameter('rowIndex');

					// if all rows has been ticked
					if (bMultiSelect) {
						bSelect = 'X';
					}
					// if all rows has been unticked
					else if (!bMultiSelect && sRowIndex === -1) {
						bSelect = '';
					}
					// if only one row has been ticked/unticked
					else if (!bMultiSelect && oContext) {
						if (oSource.getSelectedIndices().indexOf(sRowIndex) > -1) {
							bSelect = 'X';
						} else {
							bSelect = '';
						}
					}
					// loop on all rows to modify and update model with
					// selection/unselection
					for (i = 0; i < aRows.length; i++) {
						oModel.setProperty(oSource.getContextByIndex(aRows[i]).getPath() + "/Actiontype", bSelect);
					}
				} catch (e) {
					// TODO: handle exception
				}

			},

			/**
			 * 
			 * 
			 */


			onReleaseButtonPress: function () {
				var that = this;
				var oModel = this.getView().getModel("digital");

				if (oModel.hasPendingChanges()) {
					oModel.submitChanges(({
						success: that.onReleaseSuccess.bind(that),
						error: that.onReleaseError.bind(that)
					}));
				}
			},

			/**
			 * 
			 * 
			 */
			onReleaseSuccess: function (oData, oResponds) {
				var sBatchLength, sChangeRespLength, i, j, aChangesResp = [], aMessages = [], oMessage;
				this.getView().byId("idSmartPOValTable").getTable().setSelectedIndex(-1);
				this.getView().byId("idSmartPOValTable").getTable().getBinding("rows").refresh();

				if (oData.__batchResponses) {
					sBatchLength = oData.__batchResponses.length;
					for (i = 0; i < sBatchLength; i++) {
						if (oData.__batchResponses[i].__changeResponses) {
							aChangesResp = aChangesResp.concat(oData.__batchResponses[i].__changeResponses);
						}
					}
					if (aChangesResp.length > -1) {
						sChangeRespLength = aChangesResp.length;
						for (j = 0; j < sChangeRespLength; j++) {
							oMessage = this.retrieveMessages(aChangesResp[j]);
							aMessages = oMessage ? aMessages.concat(oMessage) : aMessages;
						}
					}
					var oModel = new JSONModel();
					oModel.setData(aMessages);
					this.oMessagePopover.setModel(oModel, "message");
					this.getView().byId("idMessagePORelease").setText(aMessages.length + "");
					this.oMessagePopover.toggle(this.getView().byId('idMessagePORelease'));

				}
			},

			/**
			 * 
			 * 
			 */
			retrieveMessages: function (oChangesResp) {
				var oFirstLevel, aMessages = [], sDetailLength, i;
				var oMessage = {
					type: '',
					title: ''
				};

				try {
					oFirstLevel = JSON.parse(oChangesResp.headers["sap-message"]);

					switch (oFirstLevel.severity) {
						case 'error':
							oMessage.type = 'Error';
							break;
						case 'info':
							oMessage.type = 'Success';
							break;

						default:
							oMessage.type = 'Information';
							break;
					}
					oMessage.title = oFirstLevel.message;
					aMessages = aMessages.concat(oMessage);
				} catch (e) {
					if (oChangesResp.message) {
						switch (oChangesResp.severity) {
							case 'error':
								oMessage.type = 'Error';
								break;
							case 'info':
								oMessage.type = 'Success';
								break;

							default:
								oMessage.type = 'Information';
								break;
						}
						oMessage.title = oChangesResp.message;
						return oMessage;
					} else {
						return;
					}
				}

				if (!oFirstLevel.details) {
					return aMessages;
				}
				sDetailLength = oFirstLevel.details.length;
				if (sDetailLength > -1) {
					for (i = 0; i < sDetailLength; i++) {
						aMessages = aMessages.concat(this.retrieveMessages(oFirstLevel.details[i]));
					}
				}

				return aMessages;
			},



			/**
			 * 
			 * 
			 * 
			 */
			onReleaseError: function (oResponds) {
				var oi18n = this.getView().getModel("i18n");
				sap.m.MessageToast.show(oi18n.getProperty("Error"));
			},


			/**
 			  * @function: handleMessagePopoverPress
              * @description: ..............
              * 
              */
			handleMessagePopoverPress: function handleMessagePopoverPress(oEvent) {
				// open popover
				this.oPOCreationPopover.toggle(oEvent.getSource());
			},


			onMessageDownload: function () {
				var oModel = this.oMessagePopover.getModel("message");
				var oi18n = this.getView().getModel("i18n");
				var aMessages = [], aColumns;
				var sDocTitle = oi18n.getProperty("fileName");

				var aData = oModel.oData;

				for (var i = 0; i < aData.length; i++) {
					var oError = {};
					oError.Type = aData[i].type;
					var aDetails = aData[i].title.match(/\d+/g);
					oError.PO = aDetails[0];
					oError.CAC = aDetails[1];
					oError.MSN = aDetails[2];
					oError.Vendor = aData[i].title.split(":")[4].trim();

					var sMessage = aData[i].title.split(":")[0];
					var iMessageLength = sMessage.length - 13;
					oError.Message = sMessage.substr(0, iMessageLength);
					aMessages.push(oError);
				}

				aColumns = [{
					name: "Type",
					template: {
						content: "{Type}"
					}
				},
				{
					name: "PO Number",
					template: {
						content: "{PO}"
					}
				},
				{
					name: "CAC",
					template: {
						content: "{CAC}"
					}
				},
				{
					name: "MSN",
					template: {
						content: "{MSN}"
					}
				},
				{
					name: "Vendor",
					template: {
						content: "{Vendor}"
					}
				}, {
					name: "Message",
					template: {
						content: "{Message}"
					}
				}];


				var oMessageModel = new JSONModel();
				oMessageModel.setData(aMessages);

				var oExport = new Export({

					exportType: new ExportTypeCSV({
						separatorChar: ","
					}),

					models: oMessageModel,

					rows: {
						path: "/"
					},

					columns: aColumns
				});

				var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
					pattern: "YYYYMMdd"
				});
				var sDateFormatted = oDateFormat.format(new Date());

				// download exported file
				oExport.saveFile(sDocTitle + sDateFormatted).catch(function (oError) {
					MessageBox.error(oi18n.getProperty("exportError") + oError);
				}).then(function () {
					oExport.destroy();
				});
			},

			/**
         * @SSH for US BLM  on 18.02.2020
         * 
         * @function: onListItemPress
         * @description: Open PO Card on click of PO Number only
         * @param: 
         */

        onItemPress: function (oEvent) {
            var sPonumber;
            var oi18nModel = this.getModel("i18n");
            var sPath = oEvent.getParameter("rowBindingContext").getPath();
            sPonumber = oEvent.getSource().getText();
            
            if (!sPonumber && sPonumber !== "") {
                sPonumber = this.getModel().getProperty(sPath).Ponumber;
            }

            if (sPonumber !== "") {

                if (sPonumber.indexOf("67") === 0 || sPonumber.indexOf("70") === 0 || sPonumber.indexOf("65") === 0){
                    var sDisplayPOUrl = window.location.origin + "/sap/bc/ui2/flp#ZSO_2J86_DISP_PO-display&//C_PurchaseOrderTP(PurchaseOrder='" + sPonumber
                    + "',DraftUUID=guid'00000000-0000-0000-0000-000000000000',IsActiveEntity=true)";

                var sWindow = Math.random().toString(36).replace(/[^a-z]+/g, '');
                var oWin = window.open(sDisplayPOUrl, sWindow);
                oWin.focus();
                }
                else{
                    sap.m.MessageToast.show(oi18nModel.getProperty("POCard.wrongPOMsg"));
                }
                
            }
            else {
                sap.m.MessageToast.show(oi18nModel.getProperty("POCard.noPOMsg"));
            }


        },
		
		onAfterRendering: function(){
			var oFilterBar = this.getView().byId("idSmartPOValFilter") ;
			var aGroupItems = oFilterBar.getFilterGroupItems();

			for(var i = 0; i < aGroupItems.length; i++){

				if(aGroupItems[i].getName() === "Materialnumber" || aGroupItems[i].getName() === "Materialdesc"){
					var oControl = aGroupItems[i].getControl();
					oControl.attachEvent("valueHelpRequest", function(){
						setTimeout(function(){ 						
							var sControlName = oControl.getId().slice(oControl.getId().lastIndexOf("-") + 1);
							var sNewControlName,oTable;
							if(sControlName === "Materialnumber"){
								sNewControlName = "Materialdesc";
							}
							else{
								sNewControlName = "Materialnumber";
							}
						
							var sValueHelpId = oControl.getId()+"-valueHelpDialog";
							if(sap.ui.getCore().byId(sValueHelpId) !== undefined){
								oTable = sap.ui.getCore().byId(sValueHelpId).getContent()[0].getItems()[1].getItems()[1];
								oTable.setThreshold(1000);
							}
							else{
								sValueHelpId = sValueHelpId.replace(sControlName,sNewControlName);
								oTable = sap.ui.getCore().byId(sValueHelpId).getContent()[0].getItems()[1].getItems()[1];
								oTable.setThreshold(1000);
							}

							
						}, 2000);
					});
				}
			}
		}



		});
	});

