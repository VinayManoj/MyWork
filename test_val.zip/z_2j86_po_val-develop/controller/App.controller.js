sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("airbus.ui.po_validation.controller.App", {
	
	
	});

});