/*!
 * ${copyright}
 */

sap.ui.define(["sap/ui/comp/smarttable/SmartTable","sap/m/Text"],

	function () {
		"use strict";

		/**
		 * SmartTable renderer.
		 * @namespace
		 */
		var SmartTableRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param {sap.ui.core.Control} oControl
		 *            the control to be rendered
		 */
		SmartTableRenderer.render = function (oRm, oControl) {
			// execute standard control method
			sap.ui.comp.smarttable.SmartTableRenderer.render(oRm,oControl);
		};

		return SmartTableRenderer;

	}, /* bExport= */ true);