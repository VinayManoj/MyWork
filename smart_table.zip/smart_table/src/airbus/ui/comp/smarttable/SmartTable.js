/*!
 * ${copyright}
 */
jQuery.sap.require("sap.ui.comp.smarttable.SmartTable");

// Provides control airbus.ui.comp.smarttable.SmartTable.
sap.ui.define([
	"../library", 
	"sap/ui/comp/smarttable/SmartTable", 
	"sap/ui/Device",
	"./SmartTableRenderer"
], function (library, SmartTable, Device, SmartTableRenderer) {
	"use strict";
	/**
	 * Constructor for a new SmartTable control.
	 *
	 * @param {string} [sId] id for the new control, generated automatically if no id is given
	 * @param {object} [mSettings] initial settings for the new control
	 *
	 * @class
	 * Some class description goes here.
	 * @extends sap.ui.core.Control
	 *
	 * @author SAP SE
	 * @version ${version}
	 *
	 * @constructor
	 * @public
	 * @alias airbus.ui.comp.smarttable.SmartTable
	 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
	 */
	var AirbusSmartTable = SmartTable.extend("airbus.ui.comp.smarttable.SmartTable", {
		metadata: {
			library: "airbus.ui.comp",
			properties: {
				/**
				 * Can be set to true or false depending on whether you want to export data to a GSheet.<br>
				 * <i>Note:</i><br>
				 * If <code>exportType</code> is <code>sap.ui.comp.smarttable.ExportType.GW</code>, any $expand parameters are removed when
				 * sending the request to generate the spreadsheet.<br>
				 */
				useExportToGSheet: {
					type: "boolean",
					group: "Misc",
					defaultValue: true
				}
			},
			events: {
				/**
				 * Event is fired when the user clicks on the control.
				 */
				press: {}
			}
		},
		init: function(){
			// define variable for control initial loading handling
			this._bInitialLoading = true;

			// call to parent control method
			sap.ui.comp.smarttable.SmartTable.prototype.init.apply(this, arguments);
		},

		/**
		* Called once the necessary Model metadata is available
		*
		* @private
		*/
		_addExportToExcelToToolbar: function() {
			this._addGSheetToCustomToolbarContent( );
			// call to parent control method
			sap.ui.comp.smarttable.SmartTable.prototype._addExportToExcelToToolbar.apply(this, arguments);
		},
		
		/**
		 * Callback when the property changes for the SmartTable control.
		 *
		 * @param {object} oEvent - the event object
		 * @private
		 */
		_onPropertyChange: function(oEvent) {
			// call to parent control method
			sap.ui.comp.smarttable.SmartTable.prototype._onPropertyChange.apply(this, arguments);
			if(oEvent.getParameter("name") === "useExportToGSheet"){
				sap.ui.comp.smarttable.SmartTable.prototype._createToolbarContent.apply(this);
			}
		},
		
		_addGSheetToCustomToolbarContent: function ( ){
			//Load icons
			sap.ui.core.IconPool.addIcon("gsheet", "GSuite", "icomoon", "e901");

			if(this.getUseExportToGSheet() === true ){
				// always remove content first
				if (this._oUseExportToGSheet) {
					this._oUseExportToGSheet.destroy();
					this._oUseExportToGSheet = null;
				}
				
				var sButtonId = this.getId() + "-btnExcelGSheet";
				var sButtonLabel = sap.ui.getCore().getLibraryResourceBundle("airbus.ui.comp.smarttable").getText("EXPORT_GSHEET");
				var sIconUrl = "sap-icon://GSuite/gsheet";
				this._oUseExportToGSheet = new sap.m.OverflowToolbarButton(sButtonId, {
							icon: sIconUrl,
							text: sButtonLabel,
							tooltip: sButtonLabel,
							press: this._triggerGSheetExport.bind(this)
						});
				this._oToolbar.addContent(this._oUseExportToGSheet);	
				this._setGSheetExportEnableState();
			}
			else{
				// always remove content first
				if (this._oUseExportToGSheet) {
					this._oUseExportToGSheet.destroy();
					this._oUseExportToGSheet = null;
				}
			}
		},
		
		/**
		 * disables the export to GSheet button if no data is present, otherwise enables it
		 *
		 * @private
		 */
		_setGSheetExportEnableState: function() {
			if (this._oUseExportToGSheet) {
				var iRowCount = this._getRowCount();
				this._oUseExportToGSheet.setEnabled(iRowCount > 0);
			}
		},
		
		/**
		 * disables the export to excel button if no data is present, otherwise enables it
		 *
		 * @private
		 */
		_setExcelExportEnableState: function() {
			// call to parent control method
			sap.ui.comp.smarttable.SmartTable.prototype._setExcelExportEnableState.apply(this, arguments);
			
			this._setGSheetExportEnableState();
		},
		
		/**
		 * Cleans up the control
		 *
		 * @protected
		 */
		 exit: function() {
		 	// call to parent control method
			sap.ui.comp.smarttable.SmartTable.prototype.exit.apply(this, arguments);
			
			if (this._oUseExportToGSheet) {
				this._oUseExportToGSheet.destroy();
			}
			this._oUseExportToGSheet = null;
		 },
		
		/**
		 * Trigger GSheet export using Gateway service.
		 *
		 * @private
		 */
		_triggerGSheetExport: function(){
			var oResourceBundle = sap.ui.getCore().getLibraryResourceBundle("sap.ui.comp");
			
			//Function to check columns from Smart Table and open url to launch export
			var fDownloadGSheet = function(){
				var oRowBinding = this._getRowBinding();
				var sUrl = oRowBinding.getDownloadUrl("GSheet");
				
				//Check visible columns, and change the list of selected columns in the url
				var aVisibleColumns = this._getVisibleColumns();
				var sNewSelect = "select=" + aVisibleColumns.join("%2c");
				var aMatchs = /select=([\w%]+)/.exec(sUrl);
				if(aMatchs.length > 0){
					if(aMatchs[0] !== sNewSelect){
						sUrl = sUrl.replace(aMatchs[0],sNewSelect);
					}
				}
				
				sUrl = this._removeExpandParameter(sUrl);
				
				//Add a parameter for filename if 
				if(this.getHeader() && this.getHeader().length > 0)
				{
					sUrl += "&fname=" + this.getHeader();
				}
				
				// check for length of URL -> URLs longer than 2048 chars aren't supported in some browsers (e.g. Internet Explorer)
				if (sUrl && sUrl.length > 2048 && Device.browser.msie) {
	                sap.m.MessageBox.error(oResourceBundle.getText("DOWNLOAD_TOO_COMPLEX_TEXT"));
	                return;
	            }
	            
	            var mExportSettings = {
					url: sUrl,
					type: "GSheet"
				};
				
				// Fire event to enable export url manipulation
				this.fireBeforeExport({
					exportSettings: mExportSettings
				});
				
				window.open(mExportSettings.url);
			}.bind(this);
            
            //Check number of lines to be exported
            var iRowCount = this._getRowCount(true);
	        if (iRowCount > 10000) {
	            sap.m.MessageBox.confirm(oResourceBundle.getText("DOWNLOAD_CONFIRMATION_TEXT", iRowCount), {
	                actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
	                onClose: function(Y) {
	                    if (Y === sap.m.MessageBox.Action.YES) {
	                        fDownloadGSheet();
	                    }
	                }
	            });
	        } else {
	            fDownloadGSheet();
	        }
		},
		
		/**
		 * Return a table of visible columns
		 *
		 * @private
		 */
		_getVisibleColumns : function (){
			var aColumns = this._oTable.getColumns(), i, iLen = aColumns.length, oColumn, oColumnData, sPath, aSheetColumns = [];
			for (i = 0; i < iLen; i++) {
				sPath = null;
				oColumn = aColumns[i];
				if (oColumn.getVisible()) {
					if (oColumn.getLeadingProperty) {
						sPath = oColumn.getLeadingProperty();
					}
					oColumnData = oColumn.data("p13nData");
					if (!sPath && oColumnData) {
						sPath = oColumnData["leadingProperty"];
					}
					if (Array.isArray(sPath)) {
						sPath = sPath[0];
					}
					if (sPath) {
						aSheetColumns.push(sPath);
					}
				}
			}
			return aSheetColumns;
		},
		
		renderer: SmartTableRenderer
	});
	return AirbusSmartTable;
}, /* bExport= */ true);