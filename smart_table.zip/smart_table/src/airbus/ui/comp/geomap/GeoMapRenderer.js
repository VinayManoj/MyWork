/*!
 * ${copyright}
 */

sap.ui.define(["sap/ui/vbm/GeoMapRenderer"],

	function (GeoMapRenderer) {
		"use strict";

		/**
		 * GeoMap renderer.
		 * @namespace
		 */
		var AirbusGeoMapRenderer = {};

		/**
		 * Renders the HTML for the given control, using the provided
		 * {@link sap.ui.core.RenderManager}.
		 *
		 * @param {sap.ui.core.RenderManager} oRm
		 *            the RenderManager that can be used for writing to
		 *            the Render-Output-Buffer
		 * @param {airbus.ui.comp.geomap.GeoMap} oControl 
		 *            the control to be rendered
		 */
		AirbusGeoMapRenderer.render = function (oRm, oControl) {
			GeoMapRenderer.render(oRm, oControl);
		};

		// execute standard control method

		return AirbusGeoMapRenderer;

	}, /* bExport= */ true);