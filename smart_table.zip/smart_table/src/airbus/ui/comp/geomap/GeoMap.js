/*!
 * ${copyright}
 */
jQuery.sap.require("sap.ui.vbm.GeoMap");
jQuery.sap.require("sap.m.MessageToast");

// Provides control airbus.ui.comp.
sap.ui.define(["jquery.sap.global", "./../library", "sap/m/MessageToast", "sap/ui/vbm/GeoMap", "./GeoMapRenderer"],
	function (jQuery, library, MessageToast, GeoMap, GeoMapRenderer) {
		"use strict";

		/**
		 * Constructor for a new GeoMap Control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends  GeoMap
		 *
		 * @author SAP SE
		 * @version ${version}
		 *
		 * @constructor
		 * @public
		 * @alias airbus.ui.comp.geomap.GeoMap
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var oGeoMap = GeoMap.extend("airbus.ui.comp.geomap.GeoMap", {
			metadata: {
				library: "airbus.ui.comp",
				properties: {
					/**
					 * Map Provider
					 */
					provider: {
						type: "string",
						group: "Misc",
						defaultValue: "OSM"
					}
				}
			},

			init: function () {
				// define variable for control initial loading handling
				this._bInitialLoading = true;
				this._oDataCalled = false;

				//Initialize without map
				var oMapConfiguration = {
					"MapProvider": [{
						"name": this.getProvider(),
						"tileX": "256",
						"tileY": "256",
						"minLOD": "3",
						"maxLOD": "18",
						"copyright": "",
						"Source": [{
							"id": "e1",
							"url": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAfQAAAH0AQMAAADxGE3JAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAAEnQAABJ0Ad5mH3gAAAADUExURf///6fEG8gAAAA1SURBVBgZ7cExAQAAAMIg+6feYwxgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABd9AAAB6AINvwAAAABJRU5ErkJggg=="
						}]
					}],
					"MapLayerStacks": [{
						"name": "DEFAULT",
						"MapLayer": {
							"name": "BASE",
							"refMapProvider": this.getProvider(),
							"opacity": "1",
							"colBkgnd": "RGB(255,255,255)"
						}
					}]
				};

				//Center on Europe
				this.setMapConfiguration(oMapConfiguration);
				this.setRefMapLayerStack("DEFAULT");
				this.setInitialZoom(5);
				this.setInitialPosition("0;46;0");

				// call to parent control method
				sap.ui.vbm.GeoMap.prototype.init.apply(this, arguments);
			},

			onBeforeRendering: function (oEvent) {
				var that = this;

				//Initialize map only on first call
				if (this._oDataCalled === false) {
					var oMapConfiguration = this.getMapConfiguration();
					var oResourceBundle = sap.ui.getCore().getLibraryResourceBundle("airbus.ui.comp.geomap");
					var oModel = new sap.ui.model.odata.v2.ODataModel({
						serviceUrl: "/sap/opu/odata/sap/VBI_APPL_DEF_SRV/"
					});
					oModel.read("/VBIApplicationSet('" + this.getProvider() + "')?$format=json", {
						success: function (oData) {
							that._oDataCalled = true;
							if (oData.ProjectJSON) {
								var oProject = JSON.parse(oData.ProjectJSON);
								if (oProject.SAPVB && oProject.SAPVB.MapProviders && oProject.SAPVB.MapLayerStacks) {
									var oMapProvider = oProject.SAPVB.MapProviders.Set.MapProvider;
									var oMapLayerStack = oProject.SAPVB.MapLayerStacks.Set.MapLayerStack;

									//Configuration of Map Provider
									oMapConfiguration.MapProvider[0].name = oMapProvider.name;
									oMapConfiguration.MapProvider[0].tileX = oMapProvider.tileX;
									oMapConfiguration.MapProvider[0].tileY = oMapProvider.tileY;
									oMapConfiguration.MapProvider[0].minLOD = oMapProvider.minLOD;
									oMapConfiguration.MapProvider[0].maxLOD = oMapProvider.maxLOD;
									oMapConfiguration.MapProvider[0].copyright = oMapProvider.copyright;
									oMapConfiguration.MapProvider[0].copyrightLink = oMapProvider.copyrightLink;

									oMapConfiguration.MapProvider[0].Source = [];
									for (var i = 0; i < oMapProvider.Source.length; i++) {
										oMapConfiguration.MapProvider[0].Source.push(oMapProvider.Source[i]);
									}

									//Configuration of Map Layer Stack
									oMapConfiguration.MapLayerStacks[0].name = oMapLayerStack.name;
									oMapConfiguration.MapLayerStacks[0].copyright = oMapLayerStack.copyright;
									oMapConfiguration.MapLayerStacks[0].copyrightLink = oMapLayerStack.copyrightLink;
									oMapConfiguration.MapLayerStacks[0].MapLayer.name = oMapLayerStack.MapLayer.name;
									oMapConfiguration.MapLayerStacks[0].MapLayer.refMapProvider = oMapLayerStack.MapLayer.refMapProvider;
									oMapConfiguration.MapLayerStacks[0].MapLayer.opacity = oMapLayerStack.MapLayer.opacity;
									oMapConfiguration.MapLayerStacks[0].MapLayer.colBkgnd = oMapLayerStack.MapLayer.colBkgnd;

									that.setMapConfiguration(oMapConfiguration);
									that.setRefMapLayerStack(oMapLayerStack.name);
								} else {
									MessageToast.show(oResourceBundle.getText("ODATA_CONF"));
								}
							} else {
								MessageToast.show(oResourceBundle.getText("ODATA_CONF"));
							}
						},
						error: function (oError) {
							that._oDataCalled = true;
							MessageToast.show(oResourceBundle.getText("ODATA_ACCESS") + ":" + that.getProvider());
						}
					});
				}
				sap.ui.vbm.GeoMap.prototype.onBeforeRendering.apply(this, arguments);
			},
			renderer: GeoMapRenderer
		});
		return oGeoMap;
	}, /* bExport= */ true);