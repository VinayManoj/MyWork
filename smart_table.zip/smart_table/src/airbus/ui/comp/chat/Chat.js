/*!
 * ${copyright}
 */

// Provides control com.airbus.test.z_lib_test.
sap.ui.define(["jquery.sap.global",
	"./../library",
	"sap/ui/core/Control",
	"sap/ui/core/XMLComposite",
	"airbus/ui/comp/chat/jsChat",
	"airbus/ui/comp/chat/formatter",
	"sap/ui/richtexteditor/RichTextEditor",
	"sap/ui/richtexteditor/library",
	"sap/ui/model/Filter",
	"airbus/ui/comp/chat/mention",
	"airbus/ui/comp/chat/tag-user.class",
	"airbus/ui/comp/chat/TagUserODataSource",
	"airbus/ui/comp/chat/ITagUserSource",
	"sap/base/util/uid",
	"sap/base/util/UriParameters"
],
	function (jQuery, library, Control, XMLComposite, jsChat, formatter, RTE, RTELib, Filter, MentionPlug, taguser, TagUserODataSource, ITagUserSource, uid, UriParameters) {
		"use strict";
		/**
		 * Constructor for a new Chat Control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends  XMLComposite
		 *
		 * @author LTRC - Alexandre PRIETO (NG7F4F5).
		 * @version ${version}
		 *
		 * @constructor
		 * @public
		 * @alias airbus.ui.comp.chat.Chat
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var oI18n = library.fnGetI18n("airbus.ui.comp.chat");
		var oChat = XMLComposite.extend("airbus.ui.comp.chat.Chat", {
			formatter: formatter,
			_oJsChat: null,
			metadata: {
				library: "airbus.ui.comp",
				properties: {
					apcApplication: {    //Mandatory
						type: "string",
						invalidate: true
					},
					channel: {			 //Mandatory
						type: "string",
						invalidate: true
					},
					room: {
						type: "string",
						defaultValue: "",
						invalidate: true
					},
					urlSrvUsersDB: {
						type: "string",
						invalidate: true,
						defaultValue: "/sap/opu/odata/sap/Z_2L05_CHAT_USERS_CDS",
						deprecated: true
					},
					entitySrvUsersDB: {
						type: "string",
						invalidate: true,
						defaultValue: "Z_2L05_CHAT_USERS",
						deprecated: true
					},
					tagUserSource: {
						type: "airbus.ui.comp.chat.ITagUserSource",
					},
					notifTargetName: {
						type: "string",
						defaultValue: "",
					},
					notifTargetAction: {
						type: "string",
						defaultValue: "display&/UNC/",
					},
					notifNavParams: {
						type: "string",
						defaultValue: "",
					},
					notifActionStr: {
						type: "string",
						defaultValue: "%room%///openChat",
					},
					title: {
						type: "string",
						defaultValue: ""
					},
					useRoomAsTitle: {
						type: "boolean",
						defaultValue: true
					},
					historyOn: {
						type: "boolean",
						defaultValue: true
					},
					notifyUsersOn: {
						type: "boolean",
						defaultValue: true,
						invalidate: true
					},
					readOnly: {
						type: "boolean",
						defaultValue: false
					},
					showTitle: {
						type: "boolean",
						defaultValue: true
					},
					showToolbar: {
						type: "boolean",
						defaultValue: false
					},
					showSeparator: {
						type: "sap.m.ListSeparators",
						defaultValue: "None",
						invalidate: true
					},
					showUnread: {
						type: "boolean",
						defaultValue: true,
						invalidate: true
					},
					showHistorySwitch: {
						type: "boolean",
						defaultValue: false
					},
					showMessages: {
						type: "boolean",
						defaultValue: true
					},
					showInOutComers: {
						type: "boolean",
						defaultValue: false
					},
					showWarningMsg: {
						type: "boolean",
						defaultValue: true
					},
					showCloseButton: {
						type: "boolean",
						defaultValue: true
					}
				},
				events: {
					onIncomer: {
						parameters: {
							Incomer: { type: "object", defaultValue: {} }
						}
					},
					onOutcomer: {
						parameters: {
							Outcomer: { type: "object", defaultValue: {} }
						}
					},
					onMessage: {
						parameters: {
							Message: { type: "object", defaultValue: {} }
						}
					},
					onWarn: {
						parameters: {
							Class: { type: "string", defaultValue: "" },
							Timestamp: { type: "string", defaultValue: "" },
							MsgNo: { type: "integer" },
							Msg: { type: "string", defaultValue: "" }
						}
					},
					onBusyChange: {
						parameters: {
							NewStatus: { type: "boolean" },
							OldStatus: { type: "boolean" }
						}
					},
					onCloseButtonPress: {
						parameters: {

						}
					}
				},
				publicMethods: ["clearRoom",
					"appendMsg",
					"updateMsg",
					"deleteMsg",
					"appendWarnMsg",
					"exitRoom",
					"enterRoom",
					"postMsg",
					"scrollToBottomMsg",
					"scrollToFirstUnreadMsg",
					"getFirstUnreadMsgIdx",
					"getUnreadMsgCount",
					"UpdateChatUI"]
			},
			/**************************************************************************************
			 * Public Methods (Control API)
			 */
			getjsChat: function () {
				if (!this._oJsChat) {
					if ((this.getNotifyUsersOn() === true) && (this.getNotifTargetName() === "")) {
						try {
							var sTarget = sap.ushell.services.AppConfiguration.getCurrentApplication().sFixedShellHash.split("-")[0].replace("#", "");
							this.setNotifTargetName(sTarget);
						} catch (e) { }
					}
					if (!this.getTagUserSource()) {
						this.setTagUserSource(new TagUserODataSource("/sap/opu/odata/sap/Z_2L05_CHAT_USERS_CDS",
							"Z_2L05_CHAT_USERS",
							"Fullname",
							"uname",
							["Fullname", "Department"]));
					}
					this._oJsChat = new jsChat(this.getApcApplication(), this.getChannel(), {
						historyOn: this.getHistoryOn(),
						notifyUsersOn: this.getNotifyUsersOn(),
						notifTargetName: this.getNotifTargetName(),
						notifTargetAction: this.getNotifTargetAction(),
						fnNotifNavParams: function () { return this._resolveTokens(this.getNotifNavParams()) }.bind(this),
						fnNotifActionStr: function () { return this._resolveTokens(this.getNotifActionStr()) }.bind(this)
					});
				}
				return this._oJsChat;
			},
			clearRoom: function () {
				if (!this._oModel) {
					this._initModel();
				} else {
					this._oModel.getData().BufferStack.length = 0;
					this._oModel.getData().RoomStack.length = 0;
					this._oModel.getData().WarnMsgs.length = 0;
					this._oModel.refresh();
				}
				this.byId("idWarnMsgs").updateProperty("visible");
				this.byId("idWarnMsgs").updateProperty("text");
				this.byId("idNewMsgs").setVisible(false);
				this.setRoom("");
				if (this.getUseRoomAsTitle()) {
					this.setTitle(this.getRoom());
					this.byId("idChatTitle").updateProperty("text");
				}
			},
			closeRoom: function (sRoom, sReason, fnSuccessCallback, fnErrorCallback) {
				if (!sRoom) {
					return;
				}
				this.getjsChat().Connect()
					.done(function (oJsChat) {
						oJsChat.closeRoom(sRoom, sReason)
							.done(function (oRequestFrame) {
								if (typeof fnSuccessCallback === "function") {
									fnSuccessCallback(oRequestFrame.oReqFields.Room);
								}
							}.bind(this))
							.fail(function (oRequestFrame, oError) {
								if (typeof fnErrorCallback === "function") {
									fnErrorCallback(oRequestFrame.oReqFields.Room, oError);
								}
							}.bind(this));
					}.bind(this))
					.fail(function (oError) {
						if (typeof fnErrorCallback === "function") {
							fnErrorCallback(sRoom, oError);
						}
					}.bind(this));
			},
			appendMsg: function (oMsg) {
				var aRoomStack = this._oModel.getData().RoomStack;
				aRoomStack.push(oMsg);
				this._oModel.refresh();
				this._newMsgLabelVisible(true, false);
				this.fireEvent(jsChat.prototype.Events.onMessage, { Message: oMsg });
			},
			updateMsg: function (oMsg) {
				var aRoomStack = this._oModel.getData().RoomStack;
				for (var i = 0; i < aRoomStack.length; i++) {
					if (aRoomStack[i].MUUID === oMsg.MUUID) {
						oMsg.TIMESTAMP = aRoomStack[i].TIMESTAMP;
						aRoomStack[i] = oMsg;
						break;
					}
				}
				this._oModel.refresh();
				this._newMsgLabelVisible(true, false);
				this.fireEvent(jsChat.prototype.Events.onMessage, { Message: oMsg });
			},
			deleteMsg: function (oMsg) {
				var RoomStack = this._oModel.getData().RoomStack;
				for (var i = 0; i < RoomStack.length; i++) {
					if (RoomStack[i].MUUID === oMsg.MUUID) {
						oMsg.TIMESTAMP = RoomStack[i].TIMESTAMP;
						RoomStack[i] = oMsg;
						break;
					}
				}
				this._oModel.refresh();
				this.fireEvent(jsChat.prototype.Events.onMessage, { Message: oMsg });
			},
			appendWarnMsg: function (oMsg) {
				var aEntries = this._oModel.getData().WarnMsgs;
				aEntries.unshift(oMsg);
				this._oModel.refresh();
				this.byId("idWarnMsgs").updateProperty("visible");
				this.byId("idWarnMsgs").updateProperty("text");
			},
			exitRoom: function (sRoom) {
				var oDeferredReturn = $.Deferred();
				if (((sRoom === undefined) || (sRoom === "")) && (this.getRoom() === "")) {
					oDeferredReturn.reject();
					return oDeferredReturn;
				}
				var bReset = false;
				var sLeavedRoom = ((this.getRoom() !== "") && (sRoom === undefined)) ? this.getRoom() : sRoom;
				if (sLeavedRoom === this.getRoom()) { //if leaved room is current room, clear chat msgs
					var bReset = true;
				}
				this._oJsChat.exitFromRoom(sLeavedRoom)
					.then(function (oReqParams) {
						if (bReset) {
							this.clearRoom();
							oDeferredReturn.resolve();
						}
					}.bind(this));
				return oDeferredReturn;
			},
			enterRoom: function (sRoom) {
				var oDeferredReturn = $.Deferred();
				if ((sRoom === undefined) || (sRoom === "") || (sRoom === null)) {
					oDeferredReturn.reject();
					return oDeferredReturn;
				}
				// if((this.getRoom() !== "") && (this.getRoom() === sRoom)){
				// 	oDeferredReturn.reject();
				// 	return oDeferredReturn;//enterRoom pending Already into Room, exitRoom must be call before.
				// }
				this.clearRoom();
				this.getjsChat().enterToRoom(sRoom)
					.done(function (oReqParams) {
						this.setRoom(sRoom);
						if (this.getUseRoomAsTitle()) {
							this.setTitle(this.getRoom());
						}
						oDeferredReturn.resolve();
					}.bind(this))
					.fail(function (oReqParams) {
						//this.clearRoom();
						oDeferredReturn.reject();
					}.bind(this));
				return oDeferredReturn;
			},
			postMsg: function () {
				if (this.getReadOnly()) {
					return;
				}
				if (this._oEditor.getContent() === "") {
					this.byId("idFooterChat").getCustomData().pop().setValue("APPEND");
					this._oRTE.getCustomData().pop().setValue("");
					return;
				}
				this._oRTE.setBusy(true);

				this._oJsChat.sendMsg(this._oEditor.getContent(), this._oRTE.getCustomData().pop().getValue())
					.done(function (oReqFrame) {
						this._oEditor.setContent("");
						this._oRTE.getCustomData().pop().setValue("");
						this.byId("idFooterChat").getCustomData().pop().setValue("APPEND");
						this._oRTE.setBusy(false);
					}.bind(this))
					.fail(function (oReqFrame) {
						// if(this.getShowMessages()){
						// this._oJsChat.pushUnDeliveredMsg(oReqFrame);
						// }
						// this._oEditor.setContent("");
						// this._oRTE.getCustomData().pop().setValue("");
						// this.byId("idFooterChat").getCustomData().pop().setValue("APPEND");
						this._oRTE.setBusy(false);
					}.bind(this));
			},
			scrollToBottomMsg: function (bForce) {
				try {
					if ((this._bScrollAuto || bForce) && this._isRoomScrollBarVisible()) {
						this.scrollToMsg(this.byId("idMsgList").getItems().pop());
					}
				} catch (e) {
				}
			},
			getFirstUnreadMsgIdx: function (iStartFromIdx) {
				var items = this.byId("idMsgList").getItems();
				var iUnreadIdx = -1;
				if (!iStartFromIdx) {
					iStartFromIdx = 0;
				}
				if (iStartFromIdx > items.length) {
					return iUnreadIdx;
				}
				for (var i = iStartFromIdx; i < items.length; i++) {
					if (items[i].getUnread()) {
						iUnreadIdx = i;
						break;
					}
				}
				return iUnreadIdx;
			},
			scrollToMsg: function (oMsgItem) {
				if (sap.ui.Device.system.phone) {
					var o$MsgItem = oMsgItem.getDomRef();
					if (o$MsgItem) {
						this.byId("idScrollContChat").scrollTo(o$MsgItem.getBoundingClientRect().x, o$MsgItem.getBoundingClientRect().y, 0);
					}
				} else {
					this.byId("idScrollContChat").scrollToElement(oMsgItem, 0);
				}
			},
			scrollToFirstUnreadMsg: function (bForce, bDefaultScroll) {
				try {
					if (!((this._bScrollAuto || bForce) && this._isRoomScrollBarVisible())) {
						return;
					}
					this._bScrollAuto = false;
					this._stopObservation();
					var bDftScroll = (bDefaultScroll !== undefined) ? bDefaultScroll : true;
					var oFirstUnread = null;
					var iFMUIdx = this.getFirstUnreadMsgIdx(0);
					if (iFMUIdx > -1) {
						oFirstUnread = this.byId("idMsgList").getItems()[iFMUIdx];
					}
					this._startObservation();
					if (oFirstUnread) {
						this.scrollToMsg(oFirstUnread);
					} else if (bDftScroll) {
						this._bScrollAuto = true;
						this.scrollToBottomMsg(bForce);
					}
				} catch (e) {
				}
			},
			getUnreadMsgCount: function () {
				if (!this._oJsChat) {
					return 0;
				}
				var oJsChatStatus = this._oJsChat.getInfo().Status;
				if (oJsChatStatus) {
					return oJsChatStatus.unreadMsg;
				}
			},
			UpdateChatUI: function () {
				Promise.resolve()
					.then(this._updateLayout())
					.then(function () {
						if (this._oEditor) {
							if (this._oEditor.getContainer()) {
								this._oEditor.getContainer().click();

							}
						}
					}.bind(this));
			},
			init: function () {
				sap.ui.core.XMLComposite.prototype.init.apply(this, arguments);
				this.byId("idChatBox").setModel(oI18n.Model, "i18n");
				this._oRTE = null;
				this._oEditor = null;
				this._io = null;
				this._observerPausedTmOut = null;
				this._newMsgLblVisibleTmOut = null;
				this._oIoRect = null;
				this._oIdRTE = "";
				this._oTextAreaId = "";
				this._iRoomLimit = 1000;
				this._bObervationPaused = true;
				this._bScrollAuto = true;
				this._iLoadingStep = 0;
				this._isReady = $.Deferred();
				this._isReady.progress(function (iStep) {
					this._iLoadingStep = iStep;
				}.bind(this));
				this._initModel();
				sap.ui.core.ResizeHandler.register(this.byId("idChatBox"), this.onChatResize.bind(this));
			},
			exit: function (oEvent) {
				sap.ui.core.XMLComposite.prototype.exit.apply(this, arguments);
				this._cleanup();
			},
			destroy: function () {
				sap.ui.core.XMLComposite.prototype.destroy.apply(this, arguments);
				this._cleanup();
			},
			isReady: function () {
				return (this._isReady.state() === "resolved");
			},
			load: function () {
				this._begin();
				return this._isReady;
			},
			_initModel: function () {
				this._oModel = new sap.ui.model.json.JSONModel({
					"BufferStack": [],
					"RoomStack": [],
					"WarnMsgs": []
				});
				this._oModel.setSizeLimit(this._iRoomLimit);
				this.byId("idChatBox").setModel(this._oModel);
			},
			_bindEvents: function () {
				this.byId("idWarnMsgs").attachBrowserEvent("click", this.onClickWarningMsg.bind(this));
				this.byId("idNewMsgs").attachBrowserEvent("click", this.onClickNewMsgs.bind(this));
				this.byId("idRoom").onsapenter = function (oEvent) {
					this.onConnect(oEvent);
				}.bind(this);
				//Action done on message reception
				this._oJsChat.subscribeEvent(jsChat.prototype.Events.onMessage,
					function (sEvChannel, sEvent, oEventData) {
						if (this.getShowMessages()) {
							switch (oEventData.sCommandSrc) {
								case jsChat.prototype._Commands.Update:
									this.updateMsg(oEventData.oMsg);
									break;
								case jsChat.prototype._Commands.Delete:
									this.deleteMsg(oEventData.oMsg);
									break;
								case jsChat.prototype._Commands.RoomHisto:
									this._pushHisto(oEventData.oMsg);
									break;
								default:
									this.appendMsg(oEventData.oMsg);
							}
						}
					}.bind(this)
				);
				//Action done when people enter in room
				this._oJsChat.subscribeEvent(jsChat.prototype.Events.onIncomer,
					function (sEvChannel, sEvent, oEventData) {
						this.fireEvent("onIncomer", { Incomer: oEventData.oMsg });
						if (this.getShowInOutComers()) {
							this.appendMsg(oEventData.oMsg);
						}
					}.bind(this)
				);
				//Action done when people walk out the room
				this._oJsChat.subscribeEvent(jsChat.prototype.Events.onOutcomer,
					function (sEvChannel, sEvent, oEventData) {
						this.fireEvent("onOutcomer", { Outcomer: oEventData.oMsg });
						if (this.getShowInOutComers()) {
							this.appendMsg(oEventData.oMsg);
						}
					}.bind(this)
				);
				//Action done when warning message comes
				this._oJsChat.subscribeEvent(jsChat.prototype.Events.onWarn,
					function (sEvChannel, sEvent, oEventData) {
						this.fireEvent("onWarn", {
							Class: oEventData.oMsg.CLASS,
							Timestamp: oEventData.oMsg.TIMESTAMP,
							MsgNo: oEventData.oMsg.MsgNo,
							Msg: oEventData.oMsg.MSG
						});
						this.setReadOnly(oEventData.readOnly);
						if ((oEventData.oMsg.CLASS === jsChat.prototype.MsgClass.Author)
							|| this.getShowWarningMsg()) {
							this.appendWarnMsg(oEventData.oMsg);
						}
						if (oEventData.oMsg.CLASS === jsChat.prototype.MsgClass.Author) {
							this._oJsChat.setBusy(false);
						}
					}.bind(this)
				);
				//Action done on Room connection
				this._oJsChat.subscribeEvent(jsChat.prototype.Events.onRoomEnter,
					function (sEvChannel, sEvent, oEventData) {
						this.byId("idBtnConnect").setIcon("sap-icon://connected");
						if (this.byId("idToolBar").getVisible()) {
							this.byId("idRoom").setEnabled(false);
						}
						if (this.getUseRoomAsTitle()) {
							this.setTitle(this.getRoom());
						}
					}.bind(this)
				);
				//Action done on chat deconnection						  
				this._oJsChat.subscribeEvent(jsChat.prototype.Events.onRoomExit,
					function (sEvChannel, sEvent, oEventData) {
						this.byId("idBtnConnect").setIcon("sap-icon://disconnected");
						if (this.byId("idToolBar").getVisible()) {
							this.byId("idRoom").setEnabled(true);
						}
					}.bind(this)
				);
				//Action done on chat room closed (blocked)						  
				this._oJsChat.subscribeEvent(jsChat.prototype.Events.onRoomClosed,
					function (sEvChannel, sEvent, oEventData) {
						this.setReadOnly(oEventData.readOnly);
						if (this.getShowMessages()) {
							this.appendMsg(oEventData.oMsg);
						}
					}.bind(this)
				);
				//Action done when message send was acknowlege				  
				this._oJsChat.subscribeEvent(jsChat.prototype.Events.onMsgAck,
					function (sEvChannel, sEvent, oAckData) {
						this._updateAckMsg(oAckData);
					}.bind(this)
				);
				//Action done on chat change Busy status						  
				this._oJsChat.subscribeEvent(jsChat.prototype.Events.onBusyChange,
					function (sEvChannel, sEvent, oEventData) {
						this.fireEvent(jsChat.prototype.Events.onBusyChange,
							{
								NewStatus: oEventData.NewStatus,
								OldStatus: oEventData.OldStatus
							});
						this.byId("idChatBox").setBusy(oEventData.NewStatus);
						if (oEventData.isReady) {
							setTimeout(function () {
								this.UpdateChatUI();
							}.bind(this), 300);
						}
					}.bind(this)
				);
				//Action done on chat change Busy status						  
				this._oJsChat.subscribeEvent(jsChat.prototype.Events.onReady,
					function (sEvChannel, sEvent, oEventData) {
					}.bind(this)
				);
			},

			_updateAckMsg: function (oAckData) {
				if (oAckData.ForceAck) {
					var aRoomStack = this._oModel.getData().RoomStack;
					for (var i = 0; i < aRoomStack.length; i++) {
						if ((aRoomStack[i].MUUID === oAckData.ForceAck)
							&& (aRoomStack[i].CLASS !== jsChat.prototype.MsgClass.DelivFail)) {
							aRoomStack[i].CLASS = jsChat.prototype.MsgClass.DelivFail;
							this._oModel.refresh();
							this.fireEvent(jsChat.prototype.Events.onMessage, { Message: aRoomStack[i] });
						}
					}
				}
			},

			_begin: function () {
				if (this._iLoadingStep > 0) {
					return;
				}
				this._isReady.notify(1);
				this.setProperty("height", "100%");
				this.setProperty("width", "100%");

				this.getjsChat().Connect()
					.done(function () {
						this.byId("idChatBox").setBusy(this._oJsChat.getBusy());
						this._bindEvents();
						//open room on init if set
						if (this.getRoom()) {
							this.enterRoom();
						}
						this._oJsChat._isReady // WS connected + room open + history loaded if possible
							.done(function (oJsChat) {
								this._isReady.resolve(this);
							}.bind(this))
							.fail(function () {
								this._isReady.reject();
							}.bind(this));
					}.bind(this))
					.fail(function () {
						this._isReady.reject();
						this._cleanup();
					}.bind(this));
			},
			/**************************************************************************************
			 * Private Methods
			 */
			_cleanup: function () {
				if (this._oJsChat) this._oJsChat.destroy();
				if (this._oModel) this._oModel.destroy();
				if (this._oRTE) this._oRTE.destroy();
				this._io = undefined;
				this._oJsChat = undefined;
				this._oModel = undefined;
				this._oRTE = undefined;
				this._oEditor = undefined;
				this._observerPausedTmOut = undefined;
				this._newMsgLblVisibleTmOut = undefined;
				this._oIoRect = undefined;
				this._oIdRTE = undefined;
				this._oTextAreaId = undefined;
				this._iRoomLimit = undefined;
				this._bObervationPaused = undefined;
				this._bScrollAuto = undefined;
				this._iLoadingStep = undefined;
				this._isReady = undefined;
			},
			_getRootContainer: function () {
				var o$ChatContainer = jQuery("#" + this.byId("idChatBox").getParent().getId());
				var a$ParentsContainer = o$ChatContainer.parents();
				var oAncestor = null;
				var o$Ancestor = null;
				var bFound = false;
				for (var i = 0; i < a$ParentsContainer.length; i++) {
					try {
						oAncestor = sap.ui.getCore().byId(a$ParentsContainer[i].id);
						if (oAncestor) {
							switch (oAncestor.getMetadata().getName()) {
								case "sap.m.Popover":
								case "sap.m.Dialog":
									bFound = true;
									o$Ancestor = jQuery("#" + oAncestor.getId());
									break;
								case "sap.ui.core.mvc.XMLView":
									bFound = true;
									o$Ancestor = o$ChatContainer;
									break;
								default:
									bFound = false;
									o$Ancestor = o$ChatContainer;
							}
						} else {
							oAncestor = null;
							o$Ancestor = null;
						}
						if (bFound) {
							break;
						}
					} catch (e) {

					}
				}
				if (!o$Ancestor || !bFound) {
					o$Ancestor = o$ChatContainer;
				}
				if (!oAncestor || !bFound) {
					oAncestor = this.byId("idChatBox").getParent();
				}
				return { dom$Element: o$Ancestor, UI5Component: oAncestor }
			},
			_updateFooterPosition: function (oRootContainer) {
				var o$ChatFooter = jQuery("#" + this.byId("idFooterChat").getId());
				if (!oRootContainer || !o$ChatFooter) { return; }
				if (oRootContainer.UI5Component.getMetadata().getName() === "sap.m.Dialog") {
					o$ChatFooter.css("position", "fixed");
				}
			},
			_updateHBoxBodyHeight: function (oRootContainer) {
				var c = oRootContainer.dom$Element.height();
				var h = jQuery("#" + this.byId("idHeaderChat").getId()).height();
				var f = jQuery("#" + this.byId("idFooterChat").getId()).height();
				var hBody = c - (h + f);
				this.byId("idBodyChat").setHeight(hBody.toString() + "px");
			},
			_updateLayout: function () {
				var oRootContainer = this._getRootContainer();
				this._updateHBoxBodyHeight(oRootContainer);
				this._updateFooterPosition(oRootContainer);
				this._updIntersectionObserver();
			},
			_switchItemBtnVisibility: function (oItem) {
				try {
					//Get CustomData Layout value
					var sLayout = oItem.getCustomData()[0].getValue();
					// check if the event is coming from ME
					if (sLayout === "FROM") {
						if (oItem.getItems()[0].getCustomData().pop().getValue() !== "DELETED") {
							oItem.getItems()[1].setVisible(!oItem.getItems()[1].getVisible());
						}
					}
				} catch (e) {
				}
			},
			_hideItemButtons: function (oItem) {
				oItem.setVisible(false);
			},
			_newMsgLabelVisible: function (bVisible, bForceScrollAuto) {
				if (bVisible && (!this._bScrollAuto || bForceScrollAuto) && this._isRoomScrollBarVisible() && this.getUnreadMsgCount() > 0) {
					this.byId("idNewMsgs").setVisible(true);
				} else {
					this.byId("idNewMsgs").setVisible(false);
				}
			},
			_stackMsgToBuffer: function (oMsg) {
				var aBufferStack = this._oModel.getData().BufferStack;
				aBufferStack.push(oMsg);
			},
			_dumpStackBuffer: function () {
				var aBufferStack = this._oModel.getData().BufferStack;
				this._oModel.getData().RoomStack = this._oModel.getData().RoomStack.concat(aBufferStack);
				aBufferStack.splice(0, aBufferStack.length);
				aBufferStack.length = 0;
				this._oModel.refresh();
			},
			_pushHisto: function (oMsg) {
				this._stackMsgToBuffer(oMsg); //all msgs are buffered to wait the end of histo loading
				if (!(oMsg.Idx < oMsg.Count)) {// when all histo was loaded to the buffer, copy buffer to chat room stack
					this._dumpStackBuffer();
					this._newMsgLabelVisible(true, false);
					this.fireEvent(jsChat.prototype.Events.onMessage, { Message: oMsg });
				}
			},
			_isRoomScrollBarVisible: function () {
				var bScrollBarVisible = false;
				try {
					var oScrollContainer = this.byId("idScrollContChat");
					var o$ScrollContent = jQuery("#" + oScrollContainer.getScrollDelegate()._sContentId);
					var o$ScrollBox = jQuery("#" + oScrollContainer.getId());
					var i$ScrollBoxHeight = o$ScrollBox.height();
					if ((o$ScrollContent.height() > i$ScrollBoxHeight) && i$ScrollBoxHeight > 0) {
						bScrollBarVisible = true;
					}
				} catch (e) { }
				return bScrollBarVisible;
			},
			//*************************************************************************
			//******* IntersectionObserver ***************************************
			//
			_updIntersectionObserver: function () {
				if (!this.getShowUnread()) {
					return;
				}
				try {
					this._stopObservation();
					var domRoot = this.byId("idScrollContChat").getDomRef();
					var oCurrentClientRect = domRoot.getBoundingClientRect();

					//To manage update of observate box in termes of size or position comparing with old instance
					if (this._oIoRect
						&& this._io
						&& oCurrentClientRect.height > 100
						&& oCurrentClientRect.width > 100
						&& ((this._oIoRect.x !== oCurrentClientRect.x)
							|| (this._oIoRect.y !== oCurrentClientRect.y)
							|| (this._oIoRect.height !== oCurrentClientRect.height)
							|| (this._oIoRect.width !== oCurrentClientRect.width))) {
						var oObserved = this._io.takeRecords();
						this._io.disconnect();
						this._io = null;
						this._oIoRect = null;
					}

					//Create new IO instance (with 100px square as minimum surface to work, 
					// that to filter cases of intermedia resizing and popup usage)
					if (!this._io
						&& oCurrentClientRect.height > 100
						&& oCurrentClientRect.width > 100) {
						this._io = new IntersectionObserver(this.onMsgIntersectionChanges.bind(this), {
							root: domRoot,
							rootMargin: '0px',
							threshold: [0.75, 1],
							delay: 50,
							trackVisibility: false
						});
						this._oIoRect = (this._io) ? oCurrentClientRect : null;
					}
				} catch (e) {
					if (this._io) {
						this._io.disconnect();
						this._io = null;
						this._oIoRect = null;
					}
				}
				this._startObservation();
				this._addUnreadMsgList4Observation();
			},
			_addItem4Observation: function (oItem) {
				try {
					if (!oItem) {
						return;
					}
					var domItem = oItem.getDomRef();
					if (domItem) {
						this._io.observe(domItem);
					}
				} catch (e) {

				}
			},
			_addUnreadMsgList4Observation: function (oMsgItem2Observe) {
				var domItem = null;
				if (!this._io) {
					return;
				} else if (this._oJsChat.getBusy()) {
					return;
				} else {
					var items = this.byId("idMsgList").getItems();
					for (var i = 0; i < items.length; i++) {
						if (items[i].getUnread() !== true) {
							continue;
						}//is not read start Visibility tracking
						this._addItem4Observation(items[i]);
					}
				}
			},
			_stopObservation: function (iDuration) {
				clearTimeout(this._observerPausedTmOut);
				this._observerPausedTmOut = null;
				this._bObervationPaused = true;
				if (iDuration) {
					this._observerPausedTmOut = setTimeout(function () { this._bObervationPaused = false; }.bind(this), iDuration);
				}
			},
			_startObservation: function (iTimeout) {
				if (!this._bObervationPaused || this._observerPausedTmOut !== null) {
					return;
				}
				clearTimeout(this._observerPausedTmOut);
				this._observerPausedTmOut = null;
				if (iTimeout) {
					this._observerPausedTmOut = setTimeout(function () { this._bObervationPaused = false; }.bind(this), iTimeout);
				} else {
					this._bObervationPaused = false;
				}
			},
			_resolveTokens: function (sInput) {
				var sOutput = "";
				var tokens = [];
				sInput.replace(/\%(.*?)%/g, function (a, b) { tokens.push(b); });
				sOutput = sInput;
				for (var k = 0; k < tokens.length; k++) {
					sOutput = sOutput.replace("%" + tokens[k] + "%", this.mProperties[tokens[k]]);
				}
				return sOutput;
			},
			_insertRTE: function () {
				var sMUUID = "";
				try {
					if (this._oRTE) {
						sMUUID = this._oRTE.getCustomData().pop().getValue();
						this.byId("idRTEBox").removeItem(this._oRTE);
						this._oRTE.destroy();
						tinymce.get(this._oTextAreaId).destroy();
					}
					//add scroll event handler on Room list
					jQuery("#" + this.byId("idScrollContChat").getId()).on('scroll', this.onRoomScroll.bind(this));
				} catch (e) {
				}
				var oId = this.getId(),
					oIndex = oId.lastIndexOf("-");
				this._oIdRTE = oId.slice(oIndex + 1) + this.getRoom() + uid();
				this._oTextAreaId = this._oIdRTE + "-textarea";

				/* eslint-disable */
				this._oRTE = new RTE(this._oIdRTE, {
					editorType: sap.ui.richtexteditor.EditorType.TinyMCE4,
					width: "100%",
					showGroupFont: false,
					showGroupLink: false,
					showGroupInsert: false,
					beforeEditorInit: function () {
						var oSelector = "textarea" + "#" + this._oTextAreaId;
						var sRootPath = jQuery.sap.getModulePath("airbus.ui.comp");
						var sPluginPath = sRootPath + '/chat/mention'
						var sDebugMode = UriParameters.fromURL(window.location.href).get("sap-ui-debug");
						if ((sDebugMode !== "true") || (sDebugMode === null)) {
							sPluginPath = sPluginPath + ".js"; //load from minified file
						} else {
							sPluginPath = sPluginPath + "-dbg.js"; //load from un-minified file
						}
						tinymce.init({
							selector: oSelector,
							external_plugins: {
								'mention': sPluginPath,
							},
							height: 50,
							schema: 'html5',
							language: 'en',
							extended_valid_elements: 'tag-user[*]', //autorise tag-user only with userId attribute
							custom_elements: 'tag-user',
							default_link_target: "_blank",
							init_instance_callback: function (editor) {
								const edDoc = editor.getDoc();
								//Add custom Web Component Element
								const scriptTag = edDoc.createElement('script');
								scriptTag.src = jQuery.sap.getModulePath("airbus.ui.comp") + '/chat/tag-user.class.js';
								scriptTag.type = 'module';
								// Injection of the definition file in the <iframe/> at head of document
								edDoc.querySelector('head').appendChild(scriptTag);
								//Add Event for touch Devices
								if (sap.ui.Device.system.phone || sap.ui.Device.system.tablet) {
									edDoc.querySelector('body').addEventListener("beforeinput", function (e) {
										if (editor._onBeforeInputMention) {
											editor._onBeforeInputMention(e);
										}
									}.bind(this));
								}
							}.bind(this),
							setup: function (editor) {
								this._oEditor = editor;
								editor.on('keydown', function (e) {
									if (((e.which || e.keyCode) === 13) && !e.ctrlKey && !e.isDefaultPrevented()) {
										e.preventDefault();
										this.postMsg();
									}
								}.bind(this));
							}.bind(this),
							content_style: 'tag-user { background-color: #99bbcf !important; color : #fff !important; font-weight: 500; padding-left: 5px; padding-right: 5px; padding: 1px 4px; border-radius: 9px;}',
							plugins: ['autolink link anchor spellchecker mention'],
							mentions:
							{
								source: function (query, process, delimiter, maxRequestResults) {
									if ((delimiter === '@') && this.getTagUserSource()) {
										this.getTagUserSource().getData(query, process);
									}
								}.bind(this),
								queryBy: this.getTagUserSource().getQueryByField(),
								tagUserId: this.getTagUserSource().getUserIDField(),
								dropdownFields: this.getTagUserSource().getFieldsToList(),
								delay: 100,
								items: 10,
								minQueryLength: 3,
								maxRequestResults: 100
							},
							font_formats: 'Andale Mono=andale mono,times;',
							fontsize_formats: '8pt 10pt 12pt',
							menubar: false,
							statusbar: false,
							forced_root_block: false,
							image_advtab: false,
							paste_data_images: true,
							paste_enable_default_filters: false
						});
					}.bind(this)
				});
				/* eslint-enable */
				this._oRTE.bindProperty("blocked", "$this>readOnly", function (bValue) {
					return ((bValue !== undefined) && (bValue !== null)) ? bValue : false;
				}, sap.ui.model.BindingMode.OneWay);
				this._oRTE.addCustomData(new sap.ui.core.CustomData({ key: "MUUID", value: sMUUID }));
				this.byId("idRTEBox").insertItem(this._oRTE, 0);
			},
			/**************************************************************************************
			 * Event Handlers
			 */
			onBeforeRendering: function () {
				this._begin();
			},
			onAfterRendering: function () {
				//add rich text editor
				this._insertRTE();

				//Start Msgs Observation
				this._updIntersectionObserver();
			},
			onExit: function (oEvent) {
				this.exit(oEvent);
			},
			/**********************************************************************************
			*** Internal chat control event handlers
			*** Used to manage default and base behaviour
			**/
			onChatResize: function (oEvent) {
				if (oEvent.size.height > 100) { // to filter lower sizing on popup usage 
					Promise.resolve()
						.then(this._updateLayout())
						.then(this.scrollToFirstUnreadMsg(true))
						.then(function () {
							clearTimeout(this._newMsgLblVisibleTmOut);
							this._newMsgLblVisibleTmOut = setTimeout(function () {
								this._newMsgLabelVisible(true, true);
							}.bind(this), 3000); //appears after 3sec if any unread msg existe
						}.bind(this));
				}
			},
			onAfterRenderingMsg: function (oEvent) {
				var item = oEvent.getSource().getParent().getParent().getParent();
				if (!this._io) {
					return;
				} else if (!item) {
					return;
				} else if (!item.getUnread()) {
					return;
				}
				//is not read start Visibility tracking
				this._addItem4Observation(item);
			},
			onAfterRenderingScrollCont: function (oEvent) {
				this.scrollToFirstUnreadMsg();
			},
			onRoomScroll: function () {
				if (!this._isRoomScrollBarVisible()) {
					return;
				}
				var content = this.byId("idMsgList").getDomRef();
				var box = this.byId("idScrollContChat").getDomRef();
				if (Math.abs(content.offsetHeight - (box.scrollTop + box.clientHeight)) < 2) { //trigger EoL at +/- 2px
					this._bScrollAuto = true; //scroll auto enabled when scroller is at the end of list
					this._newMsgLabelVisible(false, false);
				} else {
					this._bScrollAuto = false; //scroll auto disabledin others cases
					this._startObservation();
				}
			},
			onConnect: function (oEvent) {
				if (this._oJsChat.isConnected()) {
					this._oJsChat.exitFromRoom();
				} else {
					this._oJsChat.enterToRoom(this.getRoom());
				}
			},
			onPost: function (oEvent) {
				this.postMsg();
			},
			onSwitchHisto: function (oEvent) {
				//do nothing (bind to xml control)
			},
			onClickWarningMsg: function (oEvent) {
				if (this.getReadOnly()) {
					return;
				}
				Promise.resolve()
					.then(this.byId("idWarnMsgs").setVisible(false))
					.then(this._updateLayout());
				oEvent.bPreventDefault = true;
			},
			onClickNewMsgs: function (oEvent) {
				Promise.resolve()
					.then(this._newMsgLabelVisible(false, false))
					.then(this._updateLayout())
					.then(this.scrollToFirstUnreadMsg(true, false)) //Scroll to new msg (if still existe) only without default bottom scrolling in other case.
					.then(function () {
						clearTimeout(this._newMsgLblVisibleTmOut);
						this._newMsgLblVisibleTmOut = setTimeout(function () {
							this._newMsgLabelVisible(true, true);
						}.bind(this)
							, 3000);  //reappears after 3sec if any unread msg still existe

					}.bind(this)
					);
				oEvent.bPreventDefault = true;
			},
			onSwipeRoomList: function (oEvent) {
				this._switchItemBtnVisibility(oEvent.getParameter("srcControl").getParent());
			},
			onPressRoomMsg: function (oEvent) {
				oEvent.preventDefault();
				this._switchItemBtnVisibility(oEvent.getParameter("srcControl").getParent());
			},
			onDelMsg: function (oEvent) {
				oEvent.preventDefault();
				var oMsg = this._oModel.getProperty(oEvent.getSource().getParent().getParent().getBindingContext().getPath());
				this._oJsChat.deleteMsg(oMsg);
				this._hideItemButtons(oEvent.getSource().getParent());
				this._oEditor.execCommand('mceInsertContent', false, " ");
			},
			onEditMsg: function (oEvent) {
				var oMsg = this._oModel.getProperty(oEvent.getSource().getParent().getParent().getBindingContext().getPath());
				this.byId("idFooterChat").getCustomData().pop().setValue("UPDATE");
				this._oRTE.getCustomData().pop().setValue(oMsg.MUUID);
				this._oEditor.setContent("");
				this._oEditor.execCommand('mceInsertContent', false, oMsg.MSG + "&nbsp;");
				this._hideItemButtons(oEvent.getSource().getParent());
			},
			onNamePress: function (oEvent) {
				//do nothing, not implemented 
			},
			onRoomUpdateFinished: function (oEvent) {
				try {
					switch (oEvent.getParameter("reason")) {
						case "Growing":
							this._updIntersectionObserver();
							break;
						case "Change":
							this.UpdateChatUI();
							if (oEvent.getParameter("actual") === this._oModel.getProperty("/RoomStack/").length) { //all model and list sync
								this.scrollToFirstUnreadMsg();
							} else {
								this.scrollToBottomMsg();
							}

							break;
						default:
					}
				} catch (e) {
					oEvent.preventDefault();
				}
			},
			onClosePress: function (oEvent) {
				this.fireEvent("onCloseButtonPress", {});
			},
			onMsgIntersectionChanges: function (entries, observer) {
				if (this._bObervationPaused) {
					return;
				}
				var bModelChanged = false;
				for (var i = 0; i < entries.length; i++) {
					try {
						var oMsgItem = sap.ui.getCore().byId(entries[i].target.getAttributeNode("id").value);
						var oMsg = this._oModel.getProperty(oMsgItem.getBindingContext().getPath());
						if ((entries[i].intersectionRatio >= 0.75) && oMsg.Unread) {
							oMsg.Unread = false;
							this._oJsChat.updateMsgStatus(oMsg);
							this._oModel.setProperty(oMsgItem.getBindingContext().getPath() + "/Unread", oMsg.Unread); // set msg unread status to false
							if (oMsg.CLASS !== jsChat.prototype.MsgClass.DelivFail) {
								bModelChanged = true;
							}
							oMsgItem.updateProperty("unread");
							observer.unobserve(entries[i].target); //When msg is visible stop observation on this msg
						}
					} catch (e) {

					}
				}
				if (bModelChanged) {
					this._oModel.refresh();
				}
				this._oJsChat.updateClientStatus();
			}
		});
		return oChat;

	}, /* bExport= */ true);