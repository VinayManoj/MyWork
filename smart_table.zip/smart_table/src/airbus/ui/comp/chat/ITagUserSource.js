sap.ui.define([
		"sap/ui/base/Object",
		"sap/ui/base/Interface"
	],
	/**
	 * Interface for controls which use Tag User Source property to externalise data source.
	 *
	 * @since 1.2.0
	 * @name airbus.ui.comp.chat.ITagUserSource
	 * @interface
	 * @public
	 */
	function (BaseObject, Interface) {
		"use strict";
		let ITagUserSource = BaseObject.extend(
			"airbus.ui.comp.chat.ITagUserSource", {
				metadata: {
					interfaces: [],
					abstract: true,
				},
				/**
			    * Constructor for a ITagUserSource.
				*
				* @interface
				* Abtsract Interface ITagUserSource to implement (any) Data Source for Tag User feature.
				* @extends sap.ui.base.Object
				*
				* @author LTRC - Alexandre PRIETO (NG7F4F5).
				* @version ${version}
				*
				* @constructor
				* @public
				* @alias airbus.ui.comp.chat.ITagUserSource
				*/
				constructor: function () {
					return new Interface(this, this.getMetadata().getAllPublicMethods());
				},
				/**
				 * Status Flag isReady.
				 *
				 * @private
				 */
				_isReady : false,
				/**
				 * Abstract function to return Ready state.
				 *
				 * @return {boolean} ready state.
				 * @public
				 */
				isReady : function () {},
				/**
				 * Abstract function to fetch data and process it.
				 *
				 * @param {string} query string.
				 * @param {function} process callback function called after data reception.
				 * @public
				 */
				getData : function (query, process) {},
				/**
				 * Abstract function to return field to be used in UserID Tag Property.
				 *
				 * @return {string} field name.
				 * @public
				 */
				getUserIDField : function () {},
				/**
				 * Abstract function to return field name to query.
				 *
				 * @return {string} field name.
				 * @public
				 */
				getQueryByField : function () {},
				/**
				 * Abstract function to return array of field names to be used in list.
				 *
				 * @return {array} array of field names.
				 * @public
				 */
				getFieldsToList: function () {},
			});
		return ITagUserSource;
	});