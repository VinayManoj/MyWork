/*!
 * ${copyright}
 */

// Provides chat instance object airbus.ui.comp.chat.jsChat.
sap.ui.define(["sap/ui/base/Object",
	"./../library",
	"sap/ui/core/ws/SapPcpWebSocket",
	"sap/ui/core/EventBus",
	"sap/base/util/uid",
	"sap/base/Log",
	"sap/ui/core/format/DateFormat"
], function (BaseObject, library, SapPcpWebSocket, EventBus, uid, Log, DateFormat) {
	"use strict";
	/**
	 * jsChat Class.
	 *
	 * @class (mandatory) Marks the function as a constructor (defining a class).
	 * @extends sap.ui.base.Object
	 * @param {string} sChannel chat communication channel to use.
	 * @param {string} sRoom chat room in channel (extension) to use.
	 * @param {string} [sWsURI=/sap/bc/apc/sap/z_xxxx_apc_chat] WebSocket uri.
	 * @public.
	 * @author LTRC - NG7F4F5.
	 * @since v1.60.29
	 * @extends sap.ui.base.Object.
	 * @name airbus.ui.comp.chat.jsChat (Mandatory when defining a class with extend).
	 */
	var oI18nBundle = library.fnGetI18n("airbus.ui.comp.chat").Bundle;
	var jsChat = BaseObject.extend("airbus.ui.comp.chat.jsChat", {

		/**
		 * Class Prototype Attributes
		 * @private
		 */
		_iReqSeqNr : 0,
		_iClientRequestTimeout : 60000,
		_isReady : null,
		_isConnected: null,
		_sEndCopyMUUID: 'CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC',
		_sUName: "",
		_bBusy: false,
		_sWsURI: "",
		_sChannel: "",
		_sRoom: "",
		_sEvChannel: "",
		_oEventBus: undefined,
		_oWs: undefined,
		_ReqSeqNrSeparator : "_",
		_oParams: {
			readOnly: false,
			historyOn: false,
			notifyUsersOn: false,
			notifTargetName : "",
			notifTargetAction :"",
			fnNotifNavParams: function(){return ""},
			fnNotifActionStr: function(){return ""}
		},
		_oStatus: null,
		_bStatusChanged : false,
		/**
		 * Class Prototype Attributes
		 * 
		 * @public
		 * @constant
		 * @type {object}
		 */
		 
		 Events: {
			onOpen: "onOpen", //Event trigged when WebSocket accept the connection
			onMessage: "onMessage", //Event trigged on incomming message was received from server
			onClose: "onClose", //Event trigged when WebSocket connection was closed by server or by the client
			onError: "onError", //Event trigged when WebSocket connection are in error
			onRoomEnter: "onRoomEnter", //Event trigged after client open request to room was accepted by server
			onRoomExit: "onRoomExit", //Event trigged after client exit request to room was accepted by server
			onRoomClosed: "onRoomClosed", //Event trigged after client exit request to room was accepted by server
			onIncomer: "onIncomer", //Event trigged when people come in room.
			onOutcomer: "onOutcomer", //Event trigged when people walk out the room.
			onMsgAck: "onMsgAck", //Event trigged when message received is an acknowlegment of msg previously sent
			onWarn: "onWarn", //Event trigged when warning message received
			onBusyChange: "onBusyChange", //Event trigged when Busy status change
			onReady: "onReady" //Event trigged when chat is connected and room loaded
		},

		_Commands: {
			EnterRoom: "ENTER_ROOM", //Command send for Enter or Open Room
			ExitRoom: "EXIT_ROOM", //Command send to leave Room
			CloseRoom: "CLOSE_ROOM", //Command send to leave Room
			Append: "APPEND", //Command send to append message in opened Room
			Update: "UPDATE", //Command send to update existing message in opened Room
			RoomHisto: "ROOM_HISTO", //Command send to append histo message in opened Room
			Warn: "WARN", //Command send to append warning message in opened Room (only for current user)
			Delete: "DELETE", //Command send to delete message in opened Room
			Notify: "NOTIFY", //Command send to delete message in opened Room
			ClientStatus: "CLIENT_STATUS" //Command send to delete message in opened Room
		},
		
		MsgClass: {
			Message: "MSG",
			Info: "INFO",
			System: "SYSTEM",
			Author: "AUTHOR",
			DelivFail: "DELIV_FAIL"
		},
		
		MsgState: {
			initial: "INITIAL",
			updated: "UPDATED",
			deleted: "DELETED",
		},
		
		_RequestParams: {
			MsgNo : 0,
    		Count:  1,
    		Idx : 1 ,
    		Unread: true,
    		historyOn: true, 
    		notifyUsersOn: true,
    		Busy: false,
    		ForceAck: null,
    		IsReady: false,
    		UName: "",
    		notifRecipients: "",
    		Timestamp: "",
    		notifTargetName: "",
    		notifTargetAction: "",
    		notifNavParams: "",
    		notifActionStr: "",
    		readOnly: false,
		},
		
		_PcpObject: {
			CUId: "",
			Command: "",
			Channel: "",
			Room: "",
			MUUId: "",
			oParams: {}
		},
/*******************************************************************************************************************
 * Private section																								   *
 * *****************************************************************************************************************/
 
		/**
		 * Convenient function to built PCPField object.
		 *
		 * @param {string} sCommand string with Chat Command.
		 * @param {string} sRoom string with Chat Room id.
		 * @private
		 */
		_buildRequestFields: function (sCommand, sRoom, sMUUID, sParams) {
			return {
				"CUID": this.mId,
				"COMMAND": sCommand,
				"CHANNEL": this._sChannel,
				"ROOM": sRoom,
				"MUUID": sMUUID,
				"PARAMS": sParams || JSON.stringify(this._oParams)
			};
		},

		/**
		 * Convenient function to read PCPField object from WS in Event object.
		 *
		 * @param {object} oEvent request object received by WS.
		 * @private
		 */
		_readFieldsFromRequest: function (oPcpFields) {
			if (oPcpFields.errorText) {
				throw new Error(oPcpFields.errorText);
			}
			var oNewPcp = Object.assign({}, this._PcpObject);
			var oParams = Object.assign({}, this._RequestParams);
			try {
				oNewPcp.CUId    = oPcpFields.CUID;
				oNewPcp.Command = oPcpFields.COMMAND;
				oNewPcp.Channel = oPcpFields.CHANNEL;
				oNewPcp.Room    = oPcpFields.ROOM;
				oNewPcp.MUUId   = oPcpFields.MUUID;
				var aParams     = oPcpFields.PARAMS.replace("{","").replace("}","").replaceAll("\"","").split(",") || [];
				aParams.forEach(function(sParam){ 
					let aParam = sParam.split(":");
						try{ 
							switch(aParam[0]){
								case "Count":
								case "Idx":
								case "MsgNo":
									oParams[aParam[0]] = parseInt(aParam[1], 10);
									break;
								default:
									oParams[aParam[0]] = ((aParam[1] === "true")||(aParam[1] === "false"))? (aParam[1] === "true") : aParam[1]; 
							}
						} catch(e){}
				});  
				oNewPcp.oParams = oParams;
			} catch (e) {
				//do nothing
			}
			return oNewPcp;
		},
		
		/**
		 * send Ack event.
		 *
		 * @param {object} oEventData event params object.
		 * @param {object} oReqFields PCP fields object.
		 * @param {boolean} bDelivered delivery status flag.
		 * @private
		 */
		_sendACK: function (oRequestFrame, bDelivered) {
			oRequestFrame.oEventData.bDelivered = bDelivered;
			if (this._isRequestFromCurrentClient(oRequestFrame.oReqFields)) {
				this._ackReq(oRequestFrame.oReqFields.CUId);
				this._oEventBus.publish(this._sEvChannel, this.Events.onMsgAck, oRequestFrame.oEventData);
			}else if (oRequestFrame.oEventData.ForceAck){
				this._oEventBus.publish(this._sEvChannel, this.Events.onMsgAck, oRequestFrame.oEventData);
			}
		},
		
		/**
		 * Renew JsChat Status.
		 *
		 * @param {object} oEventData event params object.
		 * @param {object} oReqFields PCP fields object.
		 * @private
		 */
		_renewStatus: function (oEventData, oReqFields) {
			if(this._oStatus) {
				this._oStatus.unreadMsgsList.clear();
				this._oStatus.unreadMsgsList = null;
				this._oStatus = null;
			}
			this._oStatus = {
						isReady : this.isReady(),
						onlineTime : "",
						statusTime : "",
						receivedMsg: 0,
						sendMsg: 0,
						unreadMsg: 0,
						lastReadMUUID: "",
						unreadMsgsList: new Map() };
			this._bStatusChanged = false;
		},
		
		/**
		 * update JsChat Status.
		 *
		 * @param {object} oEventData event params object.
		 * @param {object} oReqFields PCP fields object.
		 * @private
		 */
		_updateStatus: function (oEventData, oReqFields) {
			if(oEventData.oMsg.CLASS === this.MsgClass.Message){
				if(this._isRequestFromCurrentClient(oReqFields)){
					this._oStatus.sendMsg += 1;
				}else{
					this._oStatus.receivedMsg = (oEventData.oMsg.USER_NAME !== "ME")? this._oStatus.receivedMsg +1 : this._oStatus.receivedMsg;	
				}
			}
			this.updateMsgStatus(oEventData.oMsg);
		},
		
		/**
		 * Release instance memory alocations.
		 *
		 * @private
		 */
		_cleanup: function (){
			try{
				this._oWs.close();
				this._oWs.destroy();
			}catch(e){
				
			}
		},
		
		/**
		 * @constructor
		 * @param {string} sChannel Abap push channel name
		 * @public
		 * @alias airbus.ui.comp.chat.jsChat
		 */
		constructor: function (sApcApplication, sChannel, oParams /* = {historyOn : false, notifyUsersOn : false, notifTargetName : "", notifTargetAction : "", fnNotifActionStr : ()=>{}, fnNotifNavParams : ()=>{}, } */ ) {
			this._initCommands();
			this.mId = uid();
			this._isConnected = $.Deferred();
			this._isReady = $.Deferred();
			this._iReqSeqNr = 0;
			this._mRequestAck = new Map();
			this._sWsURI = "/airbus/fe/apc/" + sApcApplication + "?from=fe";
			this._sChannel = sChannel;
			this._sEvChannel = this._sChannel + "/" + this.mId;
			this._oParams = oParams || this._oParams;
			this._sUName = "";
			this._renewStatus();
			this._bDisableBusyAtEnd = false;
			this._exitFromRoomSync = "";
			
			this._oEventBus = sap.ui.getCore().getEventBus();
			
			if (this._oParams.hasOwnProperty("historyOn")) {
				if (this._oParams.historyOn) {
					this._bBusy = true; // to wait history load
				}
			}
		},
		
		
		/**
		 * on Error Internal Event Handler.
		 *
		 * @param {object} oEvent event params object.
		 * @private
		 */
		_onError: function (oEvent) {
			this._setIsConnected(false,oEvent.getId());
			this._sRoom = "";
			this._oEventBus.publish(this._sEvChannel, this.Events.onError, oEvent);
		},

		/**
		 * on Close Internal Event Handler.
		 *
		 * @param {object} oEvent event params object.
		 * @private
		 */
		_onConnectionClose: function (oEvent) {
			this._renewStatus();
			this._setIsConnected(false, oEvent.getId());
			this._sRoom = "";
			this._oEventBus.publish(this._sEvChannel, this.Events.onClose, oEvent);
		},

		/**
		 * on Open Internal Event Handler.
		 *
		 * @param {object} oEvent event params object.
		 * @private
		 */
		_onConnectionOpen: function (oEvent) {
			this._setIsConnected(true);
			if (this._sRoom !== "") {
				this._oEventBus.publish(this._sEvChannel, this.Events.onOpen, oEvent);
			}
			this._renewStatus();
			this._oStatus.onlineTime = Date.now();
		},
		
		getNewRequestFrame: function(){
			var oNewRequestFrame = {
				sEvent : "",
				oReqFields : Object.assign({}, this._PcpObject),
				oEventData : {
					sCommandSrc: "",
					oMsg: {
						MSG : "",
						CLASS: "",
						DEL_FLAG: "",
						MSG: "",
						MUUID: "",
						TIMESTAMP: "0.0000000",
						UPDTMSTAMP: "0.0000000",
						USER_NAME: "",
						State : this.MsgState.initial,
						Unread : true,
						Idx : 1,
						Count : 1,
						readOnly : false,
					}
				}
			};
			oNewRequestFrame.oReqFields = Object.assign({}, this._RequestParams);
			return oNewRequestFrame;
		},

		/**
		 * on Message Internal Event Handler.
		 *
		 * @param {object} oEvent event params object.
		 * @private
		 */
		_onMessage: function (oEvent) {
			this._bDisableBusyAtEnd = false;
			var strEntry = "";
			var oRequestFrame = {
				sEvent : this.Events.onMessage,
				oReqFields : this._readFieldsFromRequest(oEvent.getParameter("pcpFields")),
				oEventData : {}
			}
			oRequestFrame.oEventData = {
				sCommandSrc: oRequestFrame.oReqFields.Command,
				oMsg: null
			};
			console.log(oRequestFrame);
			// Parse Message
			try {
				strEntry = oEvent.getParameter("data").replaceAll(/\n/g, "\\\\n");
				oRequestFrame.oEventData.oMsg = JSON.parse(strEntry);
				oRequestFrame.oEventData.oMsg.MSG = oRequestFrame.oEventData.oMsg.MSG.replaceAll(/\\n/g, "\n");
				oRequestFrame.oEventData.oMsg.State = this.MsgState.initial;
				oRequestFrame.oEventData.oMsg.Unread = true;
				oRequestFrame.oEventData.oMsg.Idx = 1;
				oRequestFrame.oEventData.oMsg.Count = 1;
				oRequestFrame.oEventData.readOnly = false;
			} catch (e) {
				throw new Error("Error: inconsistent message received! contact your administrator.");
			}
			if(oRequestFrame.oEventData.oMsg.MUUID === this._sEndCopyMUUID){
				oRequestFrame.oEventData.oMsg.CLASS = "INFO";
				oRequestFrame.oEventData.oMsg.MSG = oI18nBundle.getText("END_OF_COPY"); 
			}
			if (this._sUName !== "" && oRequestFrame.oReqFields.oParams.hasOwnProperty("UName")) {
				if (this._sUName === oRequestFrame.oReqFields.oParams.UName) {
					oRequestFrame.oEventData.oMsg.USER_NAME = "ME";
					oRequestFrame.oEventData.oMsg.Unread = false;
				}
			}
			//Execute Commande
			try{
				if(!this._cmd[oRequestFrame.oReqFields.Command].call(this,oRequestFrame)){
					return;
				}
				this._cmdCommit(oRequestFrame);
			}catch(e){
				if(!oRequestFrame.oReqFields.hasOwnProperty("Command")){
					throw new Error("Bad Request received!");
				}
				if(!this._cmd.hasOwnProperty(oRequestFrame.oReqFields.Command)){
					throw new Error("Command : " + oRequestFrame.oReqFields.Command + " unknown!");
				}
				throw new Error("Command : " + oRequestFrame.oReqFields.Command + " failed!");
			}
		},
		
		/**
		 * Function to commit Command
		 *
		 * @param {object} Request frame objet.
		 * @private
		 */
		_cmdCommit: function(oRequestFrame){
			this._sendACK(oRequestFrame, true);
			if (oRequestFrame.oEventData.oMsg) {
				this._updateStatus(oRequestFrame.oEventData, oRequestFrame.oReqFields);
				this._oEventBus.publish(this._sEvChannel, oRequestFrame.sEvent, oRequestFrame.oEventData);
			}
			if(this._bDisableBusyAtEnd){
				this.setBusy(false);
			}
		},
		
		/**
		 * Function to process command EnterRoom
		 *
		 * @param {object} Request frame objet.
		 * @Return {boolean} true if command can be or must be commited
		 * @private
		 */
		_cmdEnterRoom: function (oRequestFrame){
			// This message is received by all clients, 
			// useful to inform every client when another people enter in room
			if (this._isRequestFromCurrentClient(oRequestFrame.oReqFields)) { //Check if it's response of current client
				this._renewStatus();
				this._sRoom = oRequestFrame.oReqFields.Room;
				this._sUName = oRequestFrame.oReqFields.oParams.UName;
				oRequestFrame.sEvent = this.Events.onRoomEnter;
			} else {
				oRequestFrame.sEvent = this.Events.onIncomer;
				oRequestFrame.oEventData.oMsg.MSG = oI18nBundle.getText("INCOMER_MSG_PATTERN");
				oRequestFrame.oEventData.oMsg.MSG = oRequestFrame.oEventData.oMsg.MSG.replace("%NAME%", oRequestFrame.oEventData.oMsg.USER_NAME);
			}
			return true;
		},
		
		/**
		 * Function to process command ExitRoom
		 *
		 * @param {object} Request frame objet.
		 * @Return {boolean} true if command can be or must be commited
		 * @private
		 */
		_cmdExitRoom: function (oRequestFrame){
			// This message is received by all clients, 
			// useful to inform every client when another people leave room
			if (this._isRequestFromCurrentClient(oRequestFrame.oReqFields)) { //Check if it's response of current client
				this._renewStatus();
				this._sRoom = "";
				oRequestFrame.sEvent = this.Events.onRoomExit;
			} else {
				oRequestFrame.sEvent = this.Events.onOutcomer;
				oRequestFrame.oEventData.oMsg.MSG = oI18nBundle.getText("OUTCOMER_MSG_PATTERN");
				oRequestFrame.oEventData.oMsg.MSG = oRequestFrame.oEventData.oMsg.MSG.replace("%NAME%", oRequestFrame.oEventData.oMsg.USER_NAME);
			}
			return true;
		},
		
		/**
		 * Function to process command Warn
		 *
		 * @param {object} Request frame objet.
		 * @Return {boolean} true if command can be or must be commited
		 * @private
		 */
		_cmdWarn: function (oRequestFrame){
			oRequestFrame.sEvent                 = this.Events.onWarn;
			//update instance parameters
			this._oParams.readOnly               = oRequestFrame.oReqFields.oParams.readOnly;
			this._oParams.historyOn              = oRequestFrame.oReqFields.oParams.historyOn;
			this._oParams.notifyUsersOn          = oRequestFrame.oReqFields.oParams.notifyUsersOn;
			this.setBusy(oRequestFrame.oReqFields.oParams.Busy);
			if(oRequestFrame.oReqFields.oParams.IsReady) this._setIsReady();
			
			//update Event parameters
			oRequestFrame.oEventData.oMsg.Unread = false;
			oRequestFrame.oEventData.readOnly    = oRequestFrame.oReqFields.oParams.readOnly;
			oRequestFrame.oEventData.MsgNo       = oRequestFrame.oReqFields.oParams.MsgNo;
			oRequestFrame.oEventData.ForceAck    = oRequestFrame.oReqFields.oParams.ForceAck;
			
			if (oRequestFrame.oReqFields.oParams.ForceAck) {
				this._sendACK(oRequestFrame, false);
			}
			if (oRequestFrame.oEventData.oMsg) {
				this._updateStatus(oRequestFrame.oEventData, oRequestFrame.oReqFields);
				this._oEventBus.publish(this._sEvChannel, oRequestFrame.sEvent, oRequestFrame.oEventData);
			}
			return false;
		},
		
		/**
		 * Function to process command CloseRoom
		 *
		 * @param {object} Request frame objet.
		 * @Return {boolean} false to no commit.
		 * @private
		 */
		_cmdCloseRoom: function (oRequestFrame){
			oRequestFrame.sEvent = this.Events.onRoomClosed ;
			if(this._sRoom === oRequestFrame.oReqFields.Room){
				oRequestFrame.oEventData.readOnly = oRequestFrame.oReqFields.oParams.readOnly;
				this._oParams.readOnly            = oRequestFrame.oReqFields.oParams.readOnly;
			}
			if(this._isRequestFromCurrentClient(oRequestFrame.oReqFields)){
				if(this._sRoom === oRequestFrame.oReqFields.Room){
					this.setBusy(false);
					this._renewStatus();
					this._sRoom = "";
				}
			}
			return true;
		},
		
		/**
		 * Function to process command Append
		 *
		 * @param {object} Request frame objet.
		 * @Return {boolean} true if command can be or must be commited
		 * @private
		 */
		_cmdAppend: function (oRequestFrame){
			//this._sendACK(oRequestFrame.oEventData, oRequestFrame.oReqFields, true);
			if (this._isRequestFromCurrentClient(oRequestFrame.oReqFields) 
			 && oRequestFrame.oReqFields.oParams.notifyUsersOn) { //Check if message come from current client
				this._notifyUsers(this._parseTagUsersForNotif(oRequestFrame.oEventData.oMsg));
			}
			return true;
		},
		
		/**
		 * Function to process command Update
		 *
		 * @param {object} Request frame objet.
		 * @Return {boolean} true if command can be or must be commited
		 * @private
		 */
		_cmdUpdate: function (oRequestFrame){
			oRequestFrame.oEventData.oMsg.State = this.MsgState.updated;
			//this._sendACK(oRequestFrame.oEventData, oRequestFrame.oReqFields, true);
			if(this._isRequestFromCurrentClient(oRequestFrame.oReqFields) 
			  && oRequestFrame.oReqFields.oParams.notifyUsersOn) { //Check if message come from current client
				this._notifyUsers(this._parseTagUsersForNotif(oRequestFrame.oEventData.oMsg));
			}
			return true;
		},
		
		/**
		 * Function to process command RoomHisto
		 *
		 * @param {object} Request frame objet.
		 * @Return {boolean} true if command can be or must be commited
		 * @private
		 */
		_cmdRoomHisto: function (oRequestFrame){
			oRequestFrame.oEventData.oMsg.Unread = oRequestFrame.oReqFields.oParams.Unread;
			oRequestFrame.oEventData.oMsg.Count  = oRequestFrame.oReqFields.oParams.Count
			oRequestFrame.oEventData.oMsg.Idx    = oRequestFrame.oReqFields.oParams.Idx
			if(oRequestFrame.oEventData.oMsg.DEL_FLAG === "X"){
				oRequestFrame.oEventData.oMsg.State = this.MsgState.deleted;
				oRequestFrame.oEventData.oMsg.MSG = oI18nBundle.getText("TXT_MSG_DELETED");
			}
			if(oRequestFrame.oEventData.oMsg.Idx === 1) { // drive Busy during history loading time
				this.setBusy(true);
			}
			if (!(oRequestFrame.oEventData.oMsg.Idx < oRequestFrame.oEventData.oMsg.Count)) {
				this._setIsReady();
			}
			return true;
		},
		
		/**
		 * Function to process command Delete
		 *
		 * @param {object} Request frame objet.
		 * @Return {boolean} true if command can be or must be commited
		 * @private
		 */
		_cmdDelete: function (oRequestFrame){
			oRequestFrame.oEventData.oMsg.MSG = oI18nBundle.getText("TXT_MSG_DELETED");
			//this._sendACK(oRequestFrame.oEventData, oRequestFrame.oReqFields, true);
			oRequestFrame.oEventData.oMsg.State = this.MsgState.deleted;
			return true;
		},
		
		
		/**
		 * Function to process command Notify
		 *
		 * @param {object} Request frame objet.
		 * @Return {boolean} false or true, if command can be or must be commited
		 * @private
		 */
		_cmdNotify: function (oRequestFrame){
			//Command managed on backend side only
			return false;
		},
		
		/**
		 * Function to process command ClientStatus
		 *
		 * @param {object} Request frame objet.
		 * @Return {boolean} false or true, if command can be or must be commited
		 * @private
		 */
		_cmdClientStatus: function (oRequestFrame){
			//Command managed on backend side only
			return false;
		},
		
		/**
		 * Function to init all supported Commands
		 *
		 * @private
		 */
		_initCommands : function() {
			this._cmd = {};
			this._cmd[this._Commands.EnterRoom]    = this._cmdEnterRoom;
			this._cmd[this._Commands.ExitRoom]     = this._cmdExitRoom;
			this._cmd[this._Commands.CloseRoom]    = this._cmdCloseRoom;
			this._cmd[this._Commands.Append]       = this._cmdAppend;
			this._cmd[this._Commands.Update]       = this._cmdUpdate;
			this._cmd[this._Commands.RoomHisto]    = this._cmdRoomHisto;
			this._cmd[this._Commands.Warn]         = this._cmdWarn;
			this._cmd[this._Commands.Delete]       = this._cmdDelete;
			this._cmd[this._Commands.Notify]       = this._cmdNotify;
			this._cmd[this._Commands.ClientStatus] = this._cmdClientStatus;
		},
		
		/**
		 * Function to extrat (all) any tag (HTML Element) from HTML string
		 *
		 * @param {string} oHTMLContent HTML formated text.
		 * @return {array} aTags tag object array.
		 * @private
		 */
		_parseTags: function (sHTMLContent, sTagName) {
			var aTags = [];
			try {
				if (sHTMLContent.indexOf(sTagName) >= 0) { // quick tag existence check
					var oDomParser = new DOMParser();
					var oDoc = oDomParser.parseFromString(sHTMLContent, "text/html");
					aTags = Array.from(oDoc.getElementsByTagName(sTagName));
				}
			} catch (e) {}
			return aTags;
		},
		/**
		 * Function to list any property from HTML Element (tag) array
		 *
		 * @param {array} aTags HTML Element (tag) array.
		 * @return {string} sProperty flated text.
		 * @private
		 */
		_getTagsProperty: function (aTags, sProperty) {
			var aProperty = [];
			try {
				$.each(aTags, function (i, tag) {
					if ($.inArray(tag.getAttribute(sProperty), aProperty) === -1) {
						aProperty.push(tag.getAttribute(sProperty));
					}
				});
			} catch (e) {}
			return aProperty;
		},
		
		/**
		 * Function to convert HTML to plaintext
		 *
		 * @param {string} oHTMLContent HTML formated text.
		 * @return {string} sPlainText flated text.
		 * @private
		 */
		_getPlainText: function (sHTMLContent) {
			var sPlainText = "";
			try{
				var oDomParser = new DOMParser();
				var oDoc = oDomParser.parseFromString(sHTMLContent, "text/html");
				sPlainText = oDoc.querySelectorAll("html")[0].innerText;
			} catch (e) {
				sPlainText = sHTMLContent;
			}
			return sPlainText;
		},
		/**
		 * Function to parse message to extract notification
		 * Note if no notif found return null
		 * @param {object} oMsg message object.
		 * @return {object} oNotif notification object.
		 * @private
		 */
		_parseTagUsersForNotif: function (oMsg) {
			if((oMsg.CLASS !== this.MsgClass.Message) || (this._oParams.notifyUsersOn === false)){ 
				return null; //Check class to enable notification only on user messages and option actived
			}
			
			var oNotif = {
					FromMsg : oMsg,
					Text : "",
					Params : {}
			};
			try{
				oNotif.Params = { 
						notifRecipients : "",
						Timestamp : "",
						notifTargetName : this._oParams.notifTargetName,
						notifTargetAction : this._oParams.notifTargetAction,
						notifNavParams : this._oParams.fnNotifNavParams(),
						notifActionStr: this._oParams.fnNotifActionStr() };
			}catch(e){}
			
			var aRecipients = [];
			var aUsers = this._getTagsProperty(this._parseTags(oMsg.MSG, "tag-user"), "userid");
			for(var i = 0; i < aUsers.length; i++){
				if (aUsers[i]) {
					aRecipients.push(aUsers[i]);
				}
			}
			if(aRecipients.length === 0){
				return null;
			}
			oNotif.Params.notifRecipients = aRecipients.toString().replaceAll(",",";");
			oNotif.Params.Timestamp = oMsg.TIMESTAMP;
			oNotif.Text = this._getPlainText(oMsg.MSG);
			return oNotif;
		},
		/**
		 * Function to notify Users
		 * 
		 * @param {object} oNotif notification object.
		 * @public
		 */
		_notifyUsers: function (oNotif) {
			if(oNotif && this._oParams.notifyUsersOn === true) {
				this._oWs.send(oNotif.Text, 
							   this._buildRequestFields(this._Commands.Notify, 
														this._sRoom, 
														oNotif.FromMsg.MUUID, 
														JSON.stringify(oNotif.Params)));
			}
		},
		/**
		 * Function to change chat Ready status (only for frontend)
		 * 
		 * Event onReady is publish after status change to true
		 * 
		 * @param {boolean} bStatus new Busy status.
		 * @private
		 */
		_setIsReady: function () {
			this._oEventBus.publish(this._sEvChannel, this.Events.onReady, {});
			this._isReady.resolve(this);
			this._bDisableBusyAtEnd = true;
		},
		/**
		 * Function to change chat Connected status (only for frontend)
		 * 
		 * Promise resolved when WS is connected or Rejected on error
		 * 
		 * @param {boolean} bIsConnected new Busy status.
		 * @param {string} error text pasted on reject.
		 * @private
		 */
		_setIsConnected: function (bIsConnected, sError) {
			if (bIsConnected){
				this._isConnected.resolve(this);
			}else{
				this._isConnected.reject(new Error(sError));
			}
		},
		/**
		 * Function to check if received request come from current chat client
		 * 
		 * @param {object} oReqFields.
		 * @return {boolean} test result.
		 * @private
		 */
		_isRequestFromCurrentClient: function(oReqFields){
			return ((this._parseCUID(oReqFields.CUId) === this.mId) && (this.mId !== ""));
		},
		/**
		 * Function to parse CUID form string value
		 * 
		 * @param {string} sValue.
		 * @return {string} CUID.
		 * @private
		 */
		_parseCUID : function(sValue){
			try{
				return sValue.split(this._ReqSeqNrSeparator,2)[0];
			}catch(e){
				return sValue;
			}
		},
		/**
		 * Function callback on request timeout
		 * 
		 * @param {string} sReqId Request Sequence number.
		 * @private
		 */
		_requestTimeout : function(sReqId){
			try{
				if(!this._mRequestAck.has(sReqId)){
					return;
				}
				this._mRequestAck.get(sReqId).reqFrame.oEventData.oMsg.TIMESTAMP = this._getTimestamp();
				this._mRequestAck.get(sReqId).reqFrame.oEventData.oMsg.CLASS = this.MsgClass.DelivFail;
				this._mRequestAck.get(sReqId).reqFrame.oEventData.oMsg.USER_NAME = "ME";
				this._mRequestAck.get(sReqId).reqFrame.oEventData.bDelivered = false;
				this._mRequestAck.get(sReqId).token.reject(this._mRequestAck.get(sReqId).reqFrame, new Error(oI18nBundle.getText("WS_REQ_TIMEOUT")));
				this._mRequestAck.delete(sReqId);
			}catch(e){
				throw new Error("jsChat Request timeout error!");
			}
		},
		/**
		 * Function to manage all sent Websocked request with acknowledgement 
		 * managed and registered by map object
		 * 
		 * @param {string} sMessage payload (html format or plain text).
		 * @param {object} oPcpFields Sap Pcp fields object .
		 * @param {object} oDeferredAck defered object use for acknowledgment.
		 * @return {string} sReqId Request Identifier.
		 * @private
		 */
		_wsSend : function(sMessage, oPcpFields, oDeferredAck) {
			var oReqFrame = this.getNewRequestFrame();
			oReqFrame.oReqFields = this._readFieldsFromRequest(oPcpFields);
			oReqFrame.oEventData.sCommandSrc = oReqFrame.oReqFields.Command;
			oReqFrame.oEventData.oMsg.MSG = sMessage;
			this._iReqSeqNr += 1;
			var sReqId = oReqFrame.oReqFields.CUId + this._ReqSeqNrSeparator + this._iReqSeqNr.toString()
			oPcpFields.CUID = sReqId;
			this._oWs.send(sMessage, oPcpFields);
			var oAck = {token : oDeferredAck, reqFrame : oReqFrame, timeout: setTimeout(function(sReqId){
				this._requestTimeout(sReqId);
			}.bind(this), this._iClientRequestTimeout, sReqId)};
			this._mRequestAck.set(sReqId, oAck) ;
			return sReqId;
		},
		/**
		 * Function to acknowledge request
		 * and remove acknowledge object from map collector
		 * 
		 * @param {string} sReqId Request Identifier.
		 * @private
		 */
		_ackReq : function(sReqId){
			try{
				if(!this._mRequestAck.has(sReqId)){
					return;
				}
				clearTimeout(this._mRequestAck.get(sReqId).timeout);
				this._mRequestAck.get(sReqId).token.resolve(this._mRequestAck.get(sReqId).reqFrame);
				this._mRequestAck.delete(sReqId);
			}catch(e){
				throw new Error("jsChat Request acknowledgement error!");
			}
		},
		/**
		 * Function to apply prerequisite checks before Room modification
		 * 
		 * @return {boolean} result.
		 * @private
		 */
		_preChecksBeforeRoomModif: function(){
			if (this.isConnected()
			&& !this.getReadOnly()
			&& !this._bBusy ) {
				return true;
			}
			return false;
		},
		/**
		 * Function to build timestamp sap formated like backend (todo)
		 * used by request timeout function callback
		 * 
		 * @return {string} sTimestamp.
		 * @private
		 */
		_getTimestamp: function () {
			var sTimestamp = "0.0000000";
			// var oDate = new Date();
			// sTimestamp = oDate.getFullYear().toString();
			// sTimestamp += (oDate.getMonth() < 10) ? "0"        + oDate.getMonth().toString()        : oDate.getMonth().toString();
			// sTimestamp += (oDate.getDate()  < 10) ? "0"        + oDate.getDate().toString()         : oDate.getDate().toString();
			// sTimestamp += (oDate.getHours() < 10) ? "0"        + oDate.getHours().toString()        : oDate.getHours().toString();
			// sTimestamp += (oDate.getMilliseconds() < 10) ? "0" + oDate.getMilliseconds().toString() : oDate.getMilliseconds().toString();
			// sTimestamp += ".0000000";
		    return sTimestamp;
		},
		
/*******************************************************************************************************************
 * Public section																								   *
 * *****************************************************************************************************************/
		/**
		 * Connect WS.
		 *
		 * @return {object} deferred object.
		 * @public
		 */
		Connect : function() {
			if(!this._oWs){
				this._oWs = new SapPcpWebSocket(this._sWsURI, SapPcpWebSocket.SUPPORTED_PROTOCOLS.v10);
				this._oWs.attachError(this._onError, this);
				this._oWs.attachOpen(this._onConnectionOpen, this);
				this._oWs.attachClose(this._onConnectionClose, this);
				this._oWs.attachMessage(this._onMessage, this);
			}
			return this._isConnected;
		},
		
		/**
		 * Disonnect WS.
		 *
		 * @return {object} deferred object.
		 * @public
		 */
		Disconnect : function() {
			var oDisconnect = $.Deferred();
			if(this._oWs){
				if(this._isConnected.state() === "pending") {
					this._isConnected.reject();	
				}
				this._isConnected = $.Deferred();
				this._oWs.detachError(this._onError, this);
				this._oWs.detachOpen(this._onConnectionOpen, this);
				this._oWs.detachClose(this._onConnectionClose, this);
				this._oWs.detachMessage(this._onMessage, this);
				this._oWs.attachClose(function(){ try{ oDisconnect.resolve(); }catch(e){} }, this);
				this._oWs.close();
			}
			return oDisconnect;
		},
		/**
		 * Function to change chat Busy status (only for frontend)
		 * 
		 * Event onBusyChange is publish after status change
		 * Note : For several cases, this property can be 
		 *		  drived by the backend (ex: on History load)
		 * 
		 * @param {boolean} bStatus new Busy status.
		 * @public
		 */
		setBusy: function (bStatus) {
			if (bStatus !== this._bBusy) {
				var oEvData = {
					OldStatus: this._bBusy,
					NewStatus: bStatus,
					isReady : this.isReady()
				};
				this._bBusy = bStatus;
				
				this._oEventBus.publish(this._sEvChannel, this.Events.onBusyChange, oEvData);
			}
		},

		/**
		 * Function return chat Busy status
		 * 
		 * @return {boolean} Busy status.
		 * @public
		 */
		getBusy: function () {
			return this._bBusy;
		},
		
		/**
		 * Return Read Only mode status.
		 *
		 * @return {boolean} Room connection status
		 * @public
		 */
		getReadOnly: function () {
			return this._oParams.readOnly;
		},
		
		/**
		 * Return Ready status.
		 *
		 * @return {boolean} ready status
		 * @public
		 */
		isReady: function () {
			return (this._isReady.state() === "resolved");
		},
		
		
		/**
		 * Return connection status.
		 *
		 * @return {boolean} Room connection status
		 * @public
		 */
		isConnected: function () {
			return (this._isConnected.state() === "resolved");
		},
		
		

		/**
		 * to subcribe function callback on Chat event.
		 *
		 * 
		 * @param {string} sEvent target event name.
		 * @param {reference} onEventCallBack function callback.
		 * @public
		 */
		subscribeEvent: function (sEvent, onEventCallBack) {
			this._oEventBus.subscribe(this._sEvChannel, sEvent, onEventCallBack, this);
		},

		/**
		 * to unsubcribe function callback on Chat event.
		 *
		 * 
		 * @param {string} sEvent target event name.
		 * @param {reference} onEventCallBack function callback.
		 * @public
		 */
		unsubscribeEvent: function (sEvent, onEventCallBack) {
			this._oEventBus.unsubscribe(this._sEvChannel, sEvent, onEventCallBack, this);
		},
		setRoom : function(sRoom){
			
		},
		/**
		 * to open Chat room.
		 *
		 * @param {string} sRoom name of room to chat.
		 * @public
		 */
		enterToRoom: function (sRoom) {
			var oDeferredAck = $.Deferred();
			this._syncRequest(this._exitFromRoomSync)
				.then(function() {
					this._exitFromRoomSync = "";
					this._isConnected.done(function(){
					if (sRoom === undefined) {
						oDeferredAck.reject();
					}else{
						this._wsSend("", this._buildRequestFields(this._Commands.EnterRoom, sRoom, ""), oDeferredAck);
					}
				}.bind(this));
			}.bind(this));
			return oDeferredAck;
		},
		_syncRequest: function (sReqId){
			var waitFor = $.Deferred();
			if((sReqId === "") || (sReqId === undefined) || (sReqId === null)){
				waitFor.resolve();
			}else{
				var oAck = this._mRequestAck.get(sReqId);
				if(oAck){
					waitFor = oAck.token;
				}else{
					waitFor.reject();
				}
			}
			return waitFor;
		},
		/**
		 * to close Chat room.
		 *
		 * @param {string} sRoom name of room to chat.
		 * @public
		 */
		closeRoom: function (sRoom, sReason) {
			var oDeferredAck = $.Deferred();
			if (sRoom === undefined) {
				oDeferredAck.reject();
				return oDeferredAck;
			}
			this._wsSend(sReason, this._buildRequestFields(this._Commands.CloseRoom, sRoom, ""), oDeferredAck);
			return oDeferredAck;
		},
		
		/**
		 * to exit current chat room.
		 *
		 * @param {string} sRoom name of room to chat (not used now,for futurs improvements).
		 * @public
		 */
		exitFromRoom: function (sRoom) {
			var oDeferredAck = $.Deferred();
			if (!this.isConnected()) {
				oDeferredAck.reject();
				return oDeferredAck;
			}
			this.updateClientStatus(); // send last client status before Exit request
			this._exitFromRoomSync = this._wsSend("", this._buildRequestFields(this._Commands.ExitRoom, this._sRoom, ""), oDeferredAck);
    		return oDeferredAck;
		},

		/**
		 * to send message in Chat room.
		 * 
		 * @param {string} sMessage message string.
		 * @return {boolean} return true if send has been done.
		 * @public
		 */
		sendMsg: function (sMessage, sMUUID) {
			var oDeferredAck = $.Deferred();
			if(!this._preChecksBeforeRoomModif()){
				oDeferredAck.reject();
				return oDeferredAck;
			}
			var sCmd = this._Commands.Append;
			if (sMUUID) {
				sCmd = this._Commands.Update;
			}
			this._wsSend(sMessage, this._buildRequestFields(sCmd, this._sRoom, sMUUID), oDeferredAck);
			return oDeferredAck;
		},
		
		/**
		 * to delete message in Chat room.
		 * 
		 * @param {string} sMessage message string.
		 * @return {boolean} return true if delete has been done.
		 * @public
		 */
		deleteMsg: function (oMsg) {
			var oDeferredAck = $.Deferred();
			if(!this._preChecksBeforeRoomModif()){
				oDeferredAck.reject();
				return oDeferredAck;
			}
			this._wsSend("", this._buildRequestFields(this._Commands.Delete, this._sRoom, oMsg.MUUID), oDeferredAck);
			return oDeferredAck;
		},
		
		updateMsgStatus: function (oMsg) {
			try{
				if(((oMsg.CLASS !== this.MsgClass.Message) && (oMsg.CLASS !== jsChat.prototype.MsgClass.DelivFail)) || (oMsg.USER_NAME === "ME")){
					return this._bStatusChanged;
				}
				if(oMsg.Unread) {
					this._oStatus.unreadMsgsList.set(oMsg.MUUID, ((oMsg.UPDTMSTAMP !== "0.0000000")? oMsg.UPDTMSTAMP : oMsg.TIMESTAMP));
					this._bStatusChanged = true;
				}else{
					this._oStatus.lastReadMUUID = oMsg.MUUID;
					this._oStatus.unreadMsgsList.delete(oMsg.MUUID);
					this._bStatusChanged = true;
				}
				this._oStatus.unreadMsg = this._oStatus.unreadMsgsList.size;
			}catch (e) {}
			return this._bStatusChanged;
		},
		updateClientStatus: function (oMsg) {
			var oDeferredAck = $.Deferred();
			if (!this.isConnected()) {
				oDeferredAck.reject();
			}
			if (this._bBusy) { //Chat currently Busy
				oDeferredAck.reject();
			}
			if(this._bStatusChanged === false){ //To not call backend if it's not needed
				oDeferredAck.reject();
			}
			if(oDeferredAck.state() !== "pending"){
				return oDeferredAck;
			}
			try{
				this._oStatus.statusTime = Date.now();
				var sStatus = JSON.stringify(this._oStatus, function (key, value) { 
													if(value instanceof Map) {
    													return { 'unreadMsgsList': '',
    														      value: Array.from(value.keys()).toString().replaceAll(",",";"),};
													} else {
    													return value;
													}}).replace('{"unreadMsgsList":"","value":','').replace('}}','}');
				if (sStatus && sStatus.length > 0 ) {
					this._bStatusChanged = false;
					this._wsSend(sStatus, this._buildRequestFields(this._Commands.ClientStatus, this._sRoom, this._sUName), oDeferredAck);
				}
			} catch (e) {}
			return oDeferredAck;
		},
		/**
		 * to push unDelivered message in Chat room.
		 * 
		 * @param {object} oAckData object 
		 * @param {string} sPayload message string.
		 * @public
		 */
		pushUnDeliveredMsg: function (oRequestFrame) {
			if (!oRequestFrame.oEventData.bDelivered) { //only if msg was not delivered
				var oEventData = {
					sCommandSrc: oRequestFrame.oEventData.sCommandSrc,
					oMsg: {
						USER_NAME: oRequestFrame.oEventData.oMsg.USER_NAME,
						TIMESTAMP: oRequestFrame.oEventData.oMsg.TIMESTAMP,
						UPDTMSTAMP: oRequestFrame.oEventData.oMsg.UPDTMSTAMP,
						MSG: oRequestFrame.oEventData.oMsg.MSG,
						CLASS: this.MsgClass.DelivFail,
						State: oRequestFrame.oEventData.oMsg.State,
						Unread: false
					}
				};
				this._oEventBus.publish(this._sEvChannel, this.Events.onMessage, oEventData);
			}
		},
		/**
		 * Return Chat information status.
		 * 
		 * @return {object} return object with all Chat info status.
		 * @public
		 */
		getInfo: function () {
			var oInfo = {
				Id: this.mId,
				Online: this.isConnected(),
				WS_URI: this._sWsURI,
				Channel: this._sChannel,
				Room: this._sRoom,
				UName: this._sUName,
				Options: this._oParams,
				Status: this._oStatus
			};
			return Object.assign({}, oInfo);
		},
		destroy: function (){
			this._cleanup();
		},

	});

	/**
	 * Check if WebSockets are supported
	 * 
	 */
	if (!sap.ui.Device.support.websocket) {
		throw new Error(oI18nBundle.getText("WS_UNSUPPORTED"));
	}
	return jsChat;
});