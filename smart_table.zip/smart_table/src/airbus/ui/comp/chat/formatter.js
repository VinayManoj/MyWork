sap.ui.define(["sap/ui/core/format/DateFormat",
			   "airbus/ui/comp/chat/jsChat",
			   	"./../library"
], function (DateFormat, jsChat, library) {
	"use strict";
	var oI18nBundle = library.fnGetI18n("airbus.ui.comp.chat").Bundle;
	return {
		getActiveState:function(bReadOnly){
			if(bReadOnly){
				return sap.m.ListType.Inactive;
			}else{
				return sap.m.ListType.Active;
			}
		},
		getEnabledPost: function(bReadOnly){
			if(bReadOnly){
				return false;
			}else{
				return true;
			}
		},
		formatDateTime: function (sCreateTmStamp, sUpdTmStamp, bDeletedMsg) {
			var value = ((sUpdTmStamp !== "0.0000000") && sUpdTmStamp )? sUpdTmStamp : sCreateTmStamp ;
			if (value) {
				var sDateTime = value.split(".", 2)[0]; // ignore milliseconds
				
				var oDateFormat = DateFormat.getDateTimeInstance({
					pattern: "dd-MM-yyyy HH:mm:ss"
				});
				var utcDate = new Date(sDateTime.replace(/^(\d{4})(\d\d)(\d\d)(\d\d)(\d\d)(\d\d)$/,"$4:$5:$6 $2/$3/$1"));
				var newDate = new Date(utcDate.getTime()+utcDate.getTimezoneOffset()*60*1000);
				var offset = utcDate.getTimezoneOffset() / 60;
    			var hours = utcDate.getHours();
    			newDate.setHours(hours - offset);
    			var sLabel = "";
    			if ((bDeletedMsg !== "X") && (sUpdTmStamp && (sUpdTmStamp !== "0.0000000"))){
    				sLabel = oI18nBundle.getText("TXT_MSG_EDITED");
    			}
				return sLabel + oDateFormat.format(newDate);
			} else {
				return value;
			}
		},
		
		setVisibleWarnsMsg: function (sOption, aWarnMsgs) {
			if ( (Array.isArray(aWarnMsgs) === false ) || (sOption === false ) ) {
				return false; 
			}else if (aWarnMsgs.length > 0 ) {
				return true;
			}
			return false;
		},
		formatWarnMsg : function (aWarnMsgs) {
			if (Array.isArray(aWarnMsgs) === false){ 
				return ""; 
			}else if (aWarnMsgs.length > 0 ) {
				if (aWarnMsgs[0].MSG !== "undefined"){
					return aWarnMsgs[0].MSG;
				}
			}
			return "";
		},
		applyMessageLayout : function (sClass, sFrom) {
			switch(sClass){
				case jsChat.prototype.MsgClass.Info:
					return "Information";
				case jsChat.prototype.MsgClass.DelivFail:
					return sFrom + "[!]";
				default:
					return sFrom;
			}
		},
		applyLayout : function (sClass, sFrom) {
			switch(sClass){
				case jsChat.prototype.MsgClass.Info:
					return "OTHER";
				case jsChat.prototype.MsgClass.DelivFail:
					if(sFrom === "ME")
						return "FROM_KO";
					else
						return "TO_KO";
				default:
					if (sFrom === "ME"){
						return "FROM";
					} else {
						return "TO";
					}
			}
		},
		htmlEmbedding: function (sMsgHTML) {
			return "<span class=\"myHtmlPayload\">"+sMsgHTML+"</span>";
		}
	};
});