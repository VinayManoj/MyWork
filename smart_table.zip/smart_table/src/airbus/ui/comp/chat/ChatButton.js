/*!
 * ${copyright}
 */
sap.ui.define([
		"./../library",
		"sap/ui/core/Control",
		"sap/ui/core/XMLComposite",
		"airbus/ui/comp/chat/Chat",
		"airbus/ui/comp/chat/formatter",
		"sap/m/ResponsivePopover",
		"sap/m/ButtonType",
		"jquery.sap.global",
		"sap/base/Log"
	],
	function (library, Control, XMLComposite, Chat, formatter, ResponsivePopover, ButtonType, jQuery, Log) {
		"use strict";
		/**
		 * Constructor for a new Chat Button Control.
		 *
		 * @param {string} [sId] id for the new control, generated automatically if no id is given
		 * @param {object} [mSettings] initial settings for the new control
		 *
		 * @class
		 * Some class description goes here.
		 * @extends  XMLComposite
		 *
		 * * @author LTRC - NG7F4F5.
		 * @since v1.60.29
		 * @version ${version}
		 *
		 * @constructor
		 * @public
		 * @alias airbus.ui.comp.chat.ChatButton
		 * @ui5-metamodel This control/element also will be described in the UI5 (legacy) designtime metamodel
		 */
		var oI18n = library.fnGetI18n("airbus.ui.comp.chat");
		var oChatButton = XMLComposite.extend("airbus.ui.comp.chat.ChatButton", {
			formatter: formatter,
			metadata: {
				library: "airbus.ui.comp",
				properties: {
					popoverPlacement: {
						type: "sap.m.PlacementType",
						defaultValue: "Top"
					},
					popoverHeight: {
						type: "sap.ui.core.CSSSize",
						defaultValue: "70%"
					},
					popoverWidth: {
						type: "sap.ui.core.CSSSize",
						defaultValue: "40%"
					},
					displayModal: {
						type: "boolean",
						defaultValue: false
					},
					asAppBarHeaderButton: {
						type: "boolean",
						defaultValue: false
					},
					unreadMsgCount: {
						type: "int",
					},
					buttonText: {
						type: "string",
						defaultValue: "Chat"
					},
					buttonTooltip: {
						type: "string",
						defaultValue: "Chat"
					},
					enabled: {
						type: "boolean",
						defaultValue: true
					},
					readOnly: {
						type: "boolean",
						defaultValue: false
					},
					apcApplication: {    //Mandatory
						type: "string"
					},
					channel: {			 //Mandatory
						type: "string"
					},
					room: {
						type: "string",
						defaultValue: ""
					},
					title:{
						type: "string",
						defaultValue: ""
					},
					useRoomAsTitle: {
						type: "boolean",
						defaultValue: true
					},
					historyOn: {
						type: "boolean",
						defaultValue: true
					},
					tagUserSource: {
						type: "airbus.ui.comp.chat.ITagUserSource",
					},
					notifyUsersOn: {
						type: "boolean",
						defaultValue: true
					},
					notifTargetName: {
						type: "string",
						defaultValue: "",
					},
					notifTargetAction: {
						type: "string",
						defaultValue: "display&/UNC/",
					},
					notifNavParams: {
						type: "string",
						defaultValue: "",
					},
					notifActionStr: {
						type: "string",
						defaultValue: "%room%///openChat",
					},
					showTitle:{
						type: "boolean",
						defaultValue: true
					},
					showToolbar: {
						type: "boolean",
						defaultValue: false
					},
					showSeparator: {
						type: "sap.m.ListSeparators",
						defaultValue: "None"
					},
					showUnread: {
						type: "boolean",
						defaultValue: true
					},
					showHistorySwitch: {
						type: "boolean",
						defaultValue: false
					},
					showMessages: {
						type: "boolean",
						defaultValue: true
					},
					showInOutComers: {
						type: "boolean",
						defaultValue: false
					},
					showWarningMsg: {
						type: "boolean",
						defaultValue: true
					},
					showCloseButton: {
						type: "boolean",
						defaultValue: true
					}
				},
				events: {
					onReady: {
						parameters : { 
							unreadMsgCount : {type: "int"}
						}
					},
					onClose: {
						parameters : { }
					}
				},
				publicMethods: ["getChat", 
								"exitRoom",
								"enterRoom",
								"reinit",
								"updateButton",
								"removeFromAppBar",
								"openPopover",
								"closePopover",
								"isPopoverOpen"]
			},
/**************************************************************************************
 * Public Methods (Control API)
 */
			getChat: function (){
				if(!this._oChat){
					this._oChat = new Chat({ apcApplication: this.getApcApplication(),
										 channel: this.getChannel(),
										 room: this.getRoom(),
										 title: this.getTitle(),
										 useRoomAsTitle: this.getUseRoomAsTitle(),
										 historyOn: this.getHistoryOn(),
										 notifyUsersOn: this.getNotifyUsersOn(),
										 notifTargetName: this.getNotifTargetName(),
										 notifTargetAction: this.getNotifTargetAction(),
										 notifNavParams: this.getNotifNavParams(),
										 notifActionStr: this.getNotifActionStr(),
										 readOnly: this.getReadOnly(),
										 showTitle: this.getShowTitle(),
										 showToolbar: this.getShowToolbar(),
										 showSeparator: this.getShowSeparator(),
										 showUnread: this.getShowUnread(),
										 showHistorySwitch: this.getShowHistorySwitch(),
										 showMessages: this.getShowMessages(),
										 showInOutComers: this.getShowInOutComers(),
										 showWarningMsg: this.getShowWarningMsg(),
										 showCloseButton: this.getShowCloseButton(),
										 tagUserSource : this.getTagUserSource()});
					//this._oChat.begin(); //Setup and WS connection
				}
				return this._oChat;
			},
			setRoom : function(sRoom){
				if((sRoom === "") || (sRoom === undefined)){
					return;
				}
				if((sRoom !== this.getRoom())){
					this.enterRoom(sRoom);
				}
			},
			enterRoom: function (sRoom) {
				if(sRoom){
					this.reinit();
					this.getChat().enterRoom(sRoom)
						.then(function(){
								this.mProperties["room"] = sRoom;
						}.bind(this));
				}
			},

			exitRoom: function (sRoom) {
				this.reinit();
				if (this._oChat){
					this._oChat.exitRoom(sRoom)
						.then(function(){
						});
				}
			},
			reinit : function(){
				this._newMsgCount = 0;
				this.updateButton();
			},
			updateButton: function(){
				if(!this._oPopover) { return; }
				this.setUnreadMsgCount(this._newMsgCount);
				this._oButton.setFloatingNumber(this._newMsgCount);
			},
			init: function () {
				sap.ui.core.XMLComposite.prototype.init.apply(this, arguments);
				this._oButton = null;
				this._newMsgCount = 0;
				this._iLoadStep = null;
				this._isReady = $.Deferred();
				this._oLaunchPadRE = null;
			},
			exit: function () {
				sap.ui.core.XMLComposite.prototype.exit.apply(this, arguments);
				this.removeFromAppBar();
				this._cleanup();
			},
			destroy: function() {
				sap.ui.core.XMLComposite.prototype.destroy.apply(this, arguments);
				this._cleanup();
			},
			removeFromAppBar: function() {
				try{
					if(this.getAsAppBarHeaderButton() && (this._oLaunchPadRE !== null)){
						if(sap.ui.Device.system.phone){
						this._oLaunchPadRE.hideHeaderItem([this._oButton.getId()], false, [this._oLaunchPadRE.LaunchpadState.App]);	
						}else{
							this._oLaunchPadRE.hideHeaderEndItem([this._oButton.getId()], false, [this._oLaunchPadRE.LaunchpadState.App]);	
						}
						this._cleanup();
					}
				}catch(e){
					
				}
			},
			openPopover : function() {
				this._isReady.done(function(oChatBtn){
					if(oChatBtn._oButton && oChatBtn._oPopover){
						 oChatBtn._oPopover.openBy(oChatBtn._oButton);
					}
				});
			},
			closePopover : function() {
				if(this._oPopover){
					this._oPopover.close();
					this.fireEvent("onClose", {});
				}
			},
			isPopoverOpen: function() {
				if(this._oPopover){
					return this._oPopover.isOpen();
				}
			},
			isReady: function(){
				return (this._isReady.state() === "resolved");
			},
			
/**************************************************************************************
 * Private Methods
 */
			_cleanup: function(){
				if(this._oChat) this._oChat.destroy();
				if(this._oPopover) this._oPopover.destroy();
				if(this._oButton) this._oButton.destroy();
				this._oChat = undefined;
				this._oPopover = undefined;
				this._oButton = undefined;
				this._newMsgCount = undefined;
				this._iLoadStep = undefined;
				this._isReady = undefined;
				this._oLaunchPadRE = undefined;
			},
			_Step2_ghostPO : function () {
				this._iLoadStep = 2;
				this._oPopover.setContentHeight("1px");
			    this._oPopover.setContentWidth("1px");
			    this._oPopover.addStyleClass("myGhostControl");
			},
			_Step3_unGhostPO : function (){
				this._iLoadStep = 3;
				this._oPopover.setContentHeight(this._h);
				this._oPopover.setContentWidth(this._w);
				this._oPopover.removeStyleClass("myGhostControl");
				this._oPopover.addStyleClass("myUnGhostControl");
				
				if ((!this.isReady()) && this._oPopover && this._oChat) {
					this._isReady.resolve(this);
					this.fireEvent("onReady", { unreadMsgCount : this._newMsgCount });
				}
			},
			_bindEvents : function( ){
				try{
					this._oChat.attachOnMessage(this._updateCounter, this);
					this._oChat.attachOnCloseButtonPress(this.closePopover, this);
					this._oPopover.attachBeforeClose(this._loader, this);
					this._oPopover.attachAfterClose(this._loader, this);
					this._oPopover.attachBeforeOpen(this._loader, this);
					this._oPopover.attachAfterOpen(this._loader, this);
				}catch(e){}
			},
			_redefinePopoverResize: function(oPopover){
				try{
					if(!oPopover || !sap.ui.Device.system.desktop){
						return;
					}
					//redefine interaction control
					switch(oPopover.getPlacement()){
						case sap.m.PlacementType.Bottom:
							oPopover._getPopup().__proto__.onmousedown = this.__onmousedown_bottom_redefined;
							break;
						default:
					}
					//redefine ui layout
					this.__replaceResizeHandle(oPopover.getPlacement());
				}catch (e){}
			},
			__replaceResizeHandle : function(sPopupPlacement){
				switch(sPopupPlacement){
					case sap.m.PlacementType.Bottom:
						this._oPopover.addStyleClass("myPopoverResizeHandleBottom");
						break;
					default:
				}
			},
			__onmousedown_bottom_redefined : function (oEvent) {
				var bRTL = sap.ui.getCore().getConfiguration().getRTL();
				if (!oEvent.target.classList || !oEvent.target.classList.contains("sapMPopoverResizeHandle")) {
					return;
				}

				var $d = jQuery(document);
				var $popover = this.oContent.$();
				var that = this.oContent;
				$popover.addClass('sapMPopoverResizing');

				oEvent.preventDefault();
				oEvent.stopPropagation();

				var initial = {
					x: oEvent.pageX,
					y: oEvent.pageY,

					width: $popover.width(),
					height: $popover.height()
				};

				$d.on("mousemove.sapMPopover", function (e) {
					var width, height;

					if (bRTL) {
						width = initial.width + e.pageX - initial.x;
						height = initial.height + (initial.y - e.pageY);
					} else {
						width = initial.width + initial.x - e.pageX;
						height = initial.height + (e.pageY - initial.y);
					}

					that.setContentWidth(Math.max(width, that._minDimensions.width) + 'px');
					that.setContentHeight(Math.max(height, that._minDimensions.height) + 'px');
				});

				$d.on("mouseup.sapMPopover", function () {
					$popover.removeClass("sapMPopoverResizing");
					$d.off("mouseup.sapMPopover, mousemove.sapMPopover");
				});
			},
/**************************************************************************************
 * Event Handlers
 */
			onBeforeRendering: function () {
				if (this._iLoadStep !== null) { 
					return; 
				}
				this._iLoadStep = 0;
				
				if(this._isReady.state() !== "pending"){
					return;
				}
				
				this._oButton = this.byId("btnOpenChat");
				
				if(this._oLaunchPadRE === null){
					if(this.getAsAppBarHeaderButton()){
						var pContainer = jQuery.sap.getObject('sap.ushell.Container');
						this._oLaunchPadRE = pContainer ? pContainer.getRenderer("fiori2") || null : null;
					}
					
					if(this.getAsAppBarHeaderButton() && (this._oLaunchPadRE === null)){
						var sErrMsg = oI18n.Bundle.getText("CHATBTN_LCH_ERR");
						Log.error(sErrMsg);
						return;
					}
					
					if(this._oLaunchPadRE !== null){
						if(sap.ui.Device.system.phone){
							this._oLaunchPadRE.addHeaderItem("sap.ushell.ui.shell.ShellHeadItem", {id: this._oButton.getId()}, true, false, [this._oLaunchPadRE.LaunchpadState.App]);
						}else{
							this._oLaunchPadRE.addHeaderEndItem("sap.ushell.ui.shell.ShellHeadItem", {id: this._oButton.getId()}, true, false, [this._oLaunchPadRE.LaunchpadState.App]);
						}
					}
				}
				
				this.getChat().load()
					.done(function(oChat){
						let sPlacement = (this._oLaunchPadRE !== null)? sap.m.PlacementType.Bottom : this.getPopoverPlacement();
						this._oPopover = new ResponsivePopover({title: "",
																placement: sPlacement,
																showHeader : false,
																showArrow: true,
																showCloseButton: false,
																modal : this.getDisplayModal(),
																resizable: true,
																horizontalScrolling: false,
																verticalScrolling: false,
																contentHeight: this.getPopoverHeight(),
																contentWidth: this.getPopoverWidth(),
																content: [this._oChat]});
			    	    this._h = this._oPopover.getContentHeight();
					    this._w = this._oPopover.getContentWidth();
						
						this._redefinePopoverResize(this._oPopover);
						this._iLoadStep = 1;
						this._bindEvents();
						this._isReady.notify(this._iLoadStep);
					}.bind(this))
			},
			onAfterRendering: function () {
				this._isReady.progress(function(iLoadStep) {
					if(iLoadStep === 1){
						this._oPopover.openBy(this._oButton); //to start chat loading in popup
					}
				}.bind(this));
			},
			onOpenChatBtnPress: function (oEvent) {
				if(this.isPopoverOpen()){
					this.closePopover();
				}else{
					this.openPopover();
				}
			},
			onExit: function (oEvent) {
				this.exit(oEvent);
			},
			_updateCounter: function(oEvent){
				if(!this._oPopover) { return; }
					this._newMsgCount = this._oChat.getUnreadMsgCount();
					this.updateButton();
			},
			_loader : function(oEvent){
				try {
					switch(oEvent.sId){
						case "beforeClose": 
							if (this._iLoadStep === 3 ){ //when Ready
								this._updateCounter();
								this._oChat.attachOnMessage(this._updateCounter, this);
							}
							break;
						case "afterClose":
							if (this._iLoadStep === 2 ){ //end of "chat loading"
								this._Step3_unGhostPO();
							}
							break;
						case "beforeOpen" : 
							if (this._iLoadStep === 1 ) { //initialized
								this._Step2_ghostPO();    // to open invisible popup
							}
							if (this._iLoadStep === 3 ) {  //when Ready
								this._oChat.detachOnMessage(this._updateCounter, this);
							}
							break;
						case "afterOpen": 
							if (this._iLoadStep === 2 ) { //begin of "chat loading"
								//after first open, force popup closure after a 800ms delay 
								//for chat loading process... (TO DO: chat event)
								setTimeout(function (){ this._oPopover.close(); }.bind(this),800);
							}
							if (this._iLoadStep === 3 ) {  // when Ready
								this.reinit();
								setTimeout(this._oChat.UpdateChatUI(),400);
							}
							break;
						default:
						//do nothing
					}
				}catch (e) {
					//do nothing
				}
			}
		});
		return oChatButton;

	}, /* bExport= */ true);