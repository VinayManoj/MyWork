sap.ui.define([
		"sap/ui/base/Object",
		"sap/ui/model/Filter",
	],
	/**
	 * Interface ITagUserSource Implementation to use OData Source with Tag User feature.
	 *
	 * @since 1.2.0
	 * @name airbus.ui.comp.chat.TagUserODataSource
	 * @interface
	 * @public
	 */
	function (BaseObject, Interface, Filter) {
		"use strict";
		let TagUserODataSource = BaseObject.extend("airbus.ui.comp.chat.TagUserODataSource", {
				metadata: {
					interfaces: ["airbus.ui.comp.chat.ITagUserSource"],
				},
				/**
			    * Constructor for a TagUserODataSource.
				*
				* @param {string} [sServiceURL] OData Service URL (PATH)
				* @param {string} [sEntity] OData entity name
				* @param {string} [sQueryBy] OData field name to used for query
				*
				* @class
				* ITagUserSource implementation to use OData Source with Tag User feature.
				* @extends sap.ui.base.Object
				*
				* @author LTRC - Alexandre PRIETO (NG7F4F5).
				* @version ${version}
				*
				* @constructor
				* @public
				* @alias airbus.ui.comp.chat.TagUserODataSource
				*/
				constructor: function (sServiceURL, sEntity, sQueryBy, sUserIdField, aFieldsToList) {
					var _sServiceURL = sServiceURL;
					var _sQueryBy = sQueryBy;
					var _sEntity = sEntity;
					
					Object.defineProperty(this, "sServiceURL", {
						value: _sServiceURL,
						writable : false,
						enumerable : true,
						configurable : false
					});
					Object.defineProperty(this, "sQueryBy", {
						value: _sQueryBy,
						writable : false,
						enumerable : true,
						configurable : false
					});
					Object.defineProperty(this, "sEntity", {
						value: _sEntity,
						writable : false,
						enumerable : true,
						configurable : false
					});
					Object.defineProperty(this, "sEntity", {
						value: _sEntity,
						writable : false,
						enumerable : true,
						configurable : false
					});
					this._isReady = false;  
					this._aFilters = [];
					this._oUrlParameter= { "$top" : 100 };
					this._sUserIdField = sUserIdField;
					this._aFieldsToList = aFieldsToList;
					try 
					{
						var _oDataModel = new sap.ui.model.odata.v2.ODataModel({
						serviceUrl: this.sServiceURL,
						mParameters: { synchronizationMode: "None",
								       useBatch: true,
								       defaultCountMode: "Request",
									   defaultOperationMode: "Client"
						}
						});
						Object.defineProperty(this, "oDataModel", {
							value: _oDataModel,
							writable : false,
							enumerable : false,
							configurable : false
						});
						this._isReady = (_oDataModel) ? true : false;
					} catch (e) {
						this._isReady = false; 
					}
				},
				setFilters: function( oFilter ) {
					this._aFilters.push(oFilter);
				},
				/**
				 * To change url Parameters in oData Request.
				 * Note : replace all url Parameters
				 * @param {object} oUrlParameters a new url parameters to be used.
				 * @public
				 */
				setUrlParameters: function( oUrlParameters ) {
					this._oUrlParameters = oUrlParameters;
				},
				/**
				 * Interface function implementation to return oData field to be used in UserID Tag Property.
				 *
				 * @return {string} oData field name used as UserID.
				 * @public
				 */
				getUserIDField : function () {
					return this._sUserIdField;
				},
				/**
				 *Interface function implementation to return oData field name to query.
				 *
				 * @param {string} query string.
				 * @param {function} process callback function called after data reception.
				 * @public
				 */
				getQueryByField : function () {
					return this.sQueryBy;
				},
				/**
				 * Interface function implementation to return array of oData field name to be used in list.
				 *
				 * @return {array} array of field names.
				 * @public
				 */
				getFieldsToList: function () {
					return this._aFieldsToList;
				},
				/**
				 * Interface function implementation to return Ready state.
				 *
				 * @return {boolean} ready state.
				 * @public
				 */
				isReady: function() {
					return this._isReady;
				},
				/**
				 * Interface function implementation to gatData and process it.
				 *
				 * @param {string} query string.
				 * @param {function} process callback function called after data reception.
				 * @public
				 */
				getData : function (query, process) {
					if( !this._isReady ){
						return ;
					}
					var aFilters = [ new sap.ui.model.Filter({ filters: [ new sap.ui.model.Filter(this.sQueryBy, sap.ui.model.FilterOperator.Contains, query)],and: true }) ];
					if(this._aFilters.length > 0){
						aFilters = aFilters[0].aFilters.concat(this._aFilters);
					}
    				this.oDataModel.read("/" + this.sEntity, {
						filters: aFilters,
						urlParameters: this.oUrlParameters,
						success: function (oData) {
							//Limit result by program if Top parameter what not take in account
							if(oData.results.length > this._oUrlParameter.$top){
								oData.results.length = this._oUrlParameter.$top;
							}
							process(oData.results);
						}.bind(this),
						error: function () {
							process([]);
						}
					});
				},
			});
		return TagUserODataSource;
	});