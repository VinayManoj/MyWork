class TagUser extends HTMLElement {
/**
* Constructor
*/
	constructor() {
		super();
			this.prefixId = "__" + this.tagName.replaceAll("-","").toLowerCase() + "-__clone";
			this.contentEditable = false;
		}
/**
 * UI5 Setters/Getters
 */

		/**
		* Convenient function to get attribute Id.
		* @return {string}.
		* @public
		*/
		getId( ) {
			return this.getAttribute("id");
		}
		
		/**
		* Convenient function to set attribute Id.
		* @param {string} value.
		* @public
		*/
		setId( value ) {
			this.setAttribute("id", value);
		}
		
		/**
		* Convenient function to get attribute UserId.
		* @return {string}.
		* @public
		*/
		getUserId( ) {
			return this.getAttribute("userid");
		}
		
		/**
		* Convenient function to set attribute UserId.
		* @param {string} value.
		* @public
		*/
		setUserId( value ) {
			this.setAttribute("userid", value);
		}
		
		/**
		* Convenient function to get attribute Disabled.
		* @return {boolean}
		* @public
		*/
		getDisabled( ) {
			return this.getAttribute("disabled");
		}
		
		/**
		* Convenient function to set attribute Disabled.
		* @param {boolean} value.
		* @public
		*/
		setDisabled( value ) {
			this.setAttribute("disabled", value);
		}

/**
* HTML Dom Getters/Setters
* To reflect the value of the disabled property as an HTML attribute.
*/
		set id(val) {
			if (val) {
				this.setAttribute("id", val);
			} else {
				this.removeAttribute("id");
			}
		}
		get id() {
			return this.hasAttribute("id");
		}
		
		set userid(val) {
			if (val) {
				this.setAttribute("userid", val);
			} else {
				this.removeAttribute("userid");
			}
		}
		get userid() {
			return this.hasAttribute("userid");
		}

		set disabled(val) {
			if (val) {
				this.setAttribute("disabled", val);
			} else {
				this.removeAttribute("disabled");
			}
		}
		get disabled() {
			return this.hasAttribute("disabled");
		}
		
		/**
		* Static Getter used by browser to trig changes on element attributs.
		*
		* @public
		*/
		static get observedAttributes() {
			return ["id", "userid", "disabled"];
		}

/**
 * Custom Element Callbacks of HTMLElement Events
 */
		/**
		* Method called by browser when element was added to DOM and link to graphical context.
		*
		* @public
		*/
		connectedCallback() {
			if (!this.rendered) {
				this.render();
				this.rendered = true;
			}
			//this._generateIds();
		}

		/**
		* Method called by browser when element was removed from DOM.
		*
		* @public
		*/
		// disconnectedCallback() {
		// 	
		// }
		
		/**
		* Callback method called by browser on element attribut changes.
		*
		* @public
		*/
		attributeChangedCallback(name, oldValue, newValue) {
			this.render();
		}

/**
 * Public Methods
 */
		/**
		* Method to customise html element rendering.
		*
		* @public
		*/
		render() {
			// this.innerHTML =
			//do nothing
		}
		
		/**
		* Method to return all same tags of current document.
		*
		* @public
		*/
		getAllTags() {
			return Array.from(document.querySelectorAll(this.localName));
		}
/**
 * Private Methods
 */
 		/**
		* Method to generate Id (selector) of the current tag.
		*
		* @private
		*/
		_generateIds() {
			if(!this.getAttribute("id")){ //if this element have not id, set id considering existing tags
				var aTagList = this.getAllTags();
				var prevId = "";
				var nextIdNum = 0;
				for(var i = 0; i < aTagList.length; i++){ //parse all tags in document
					if(!aTagList[i].getAttribute("id")){
						try{
							nextIdNum = 0;
							if(i>0){ //from the second element check previous Id
								prevId = aTagList[i-1].getAttribute("id");
								if(prevId.indexOf(this.prefixId) >= 0 ){
									prevId = prevId.replace(this.prefixId, "");
									nextIdNum = parseInt(prevId, 10) + 1; //Calc the next free id number
								}
							}
						}catch (e) {
							nextIdNum = i; //on error use directly i value
						}
						aTagList[i].setAttribute("id",this.prefixId + nextIdNum.toString());
					}
				}
			}
		}
	}
	
customElements.define("tag-user", TagUser);
