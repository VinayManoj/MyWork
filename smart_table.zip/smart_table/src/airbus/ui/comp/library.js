/*!
 * ${copyright}
 */

/**
 * Initialization Code and shared classes of library airbus.ui.comp.
 */
sap.ui.define(["sap/ui/core/library", "sap/ui/base/DataType"], // library dependency
	function (lib, DataType) {

		"use strict";
		
		/**
		 * Airbus SAPUI5 components
		 *
		 * @namespace
		 * @name airbus.ui.comp
		 * @author SAP SE
		 * @version 1.2.7
		 * @public
		 */

		// delegate further initialization of this library to the Core
		sap.ui.getCore().initLibrary({
			name: "airbus.ui.comp",
			version: "1.2.7",
			dependencies: ["sap.ui.core"],
			types: ["airbus.ui.comp.chat.ITagUserSource"],
			interfaces: ["airbus.ui.comp.chat.ITagUserSource"],
			controls: ["airbus.ui.comp.smarttable.SmartTable",
            		   "airbus.ui.comp.geomap.GeoMap",
                       "airbus.ui.comp.chat.Chat",
                       "airbus.ui.comp.chat.ChatButton"],
			elements: []
		});
		/* eslint-disable */
		var thisLib = airbus.ui.comp;
		
		thisLib.fnGetI18n = function(sControlPath){
			var oResources = {Model : null, Bundle : null};
			try{
				var sPath = sControlPath + ".i18n";
				oResources.Bundle = sap.ui.getCore().getLibraryResourceBundle(sPath, sap.ui.getCore().getConfiguration().getLanguage(),false);
				oResources.Model = new sap.ui.model.json.JSONModel(oResources.Bundle.aPropertyFiles[0].mProperties);
			}catch(e){
				
			}
			return oResources;
		};
		
		/**
		 * Interface for controls which implement the Tag User Source.
		 *
		 * @since 1.2.0
		 * @name airbus.ui.comp.chat.ITagUserSource
		 * @interface
		 * @public
		 */
		 thisLib.chat.ITagUserSource = DataType.createType("airbus.ui.comp.chat.ITagUserSource", {
			isValid : function (vValue) {
				if(typeof vValue === "object") {
					return  ($.inArray("airbus.ui.comp.chat.ITagUserSource", vValue.getMetadata().getInterfaces()) === 0) ? true : false;
				} else { 
					return false;
				}
			}
		}, DataType.getType("object"));

		return thisLib;
		/* eslint-enable */

	}, /* bExport= */ false);