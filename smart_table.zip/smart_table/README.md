# Z2F97_UI5_LIB

Z2F97_UI5_LIB is a SAPUI5 library to be used in MyLaunchpad SAPUI5 application.

## Versioning

| Version| Date | Changelog |
| -- | -- | -- | 
| v1.0.0 | 01.12.2020 | Add a new component: Airbus SmartTable (possibility to export to Google Sheet)|
| v1.1.0 | 08.12.2020 | Add a new component: Airbus GeoMap |
| v1.1.1 | 11.03.2021 | Fix issue when setUseExportToGSheet(false) |
| v1.1.2 | 24.03.2021 | GSheet export enhancement: export only visible columns |
| v1.1.3 | 31.03.2021 | GSheet export enhancement: Max url length for Chrome browser is 2MB |
| v1.2.0 | 13.04.2021 | Chat: Add a new components: Airbus Chat and ChatButton |
| v1.2.1 | 07.05.2021 | Chat: Add Chat TagUser Source interface and ChatButton option for launchPad usage |
| v1.2.3 | 21.05.2021 | Chat: Add onReady event to the ChatButton component and popover close/open functions |
| v1.2.4 | 11.06.2021 | Chat: Mobile improvements, new ChatButton Loader, new button and events (ref. to integration doc) |
| v1.2.5 | 07.07.2021 | Chat: fixes and improvements |
| v1.2.6 | 19.08.2021 | Chat: launchpad notification fixes and improvements |
| v1.2.7 | 05.10.2021 | Chat: loading improvements, new room closing support with new read only mode |

## Usage

On [WebIDE](https://webidecp-yl4kc7mve3.dispatcher.eu2.hana.ondemand.com/) do a right click on your project and **Add a Reference to Library**
![add_ref_to_lib](./readme/add_ref_to_lib.jpg)

And select **airbus.ui.comp** library in the list
![airbus.ui.comp](./readme/airbus.ui.comp.jpg)

After that you can use components from the library directly in your view
```xml
<mvc:View controllerName="....." 
	xmlns:st="airbus.ui.comp.smarttable" >
	<st:SmartTable .../>
</mvc:View>
```

## Contributing
For any changes, please contact the [UX Squad](DL-ERPSC_Squad_Continuous_Integration_eXperience@airbus.com)