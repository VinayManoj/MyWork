/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.declare("ui.ssuite.s2p.mm.pur.po.manage.st.s1.model.formatter");

ui.ssuite.s2p.mm.pur.po.manage.st.s1.model.formatter = {

	fnReturnAttachmentKey: function (sPurchaseOrder, sDraftUUID) {
		var objectKey = "";
		if (sPurchaseOrder !== undefined && sPurchaseOrder !== null && sPurchaseOrder !== "") {
			objectKey = sPurchaseOrder;
		} else if (sDraftUUID !== undefined && sDraftUUID !== null && sDraftUUID !== "") {
			objectKey = sDraftUUID.replace(/[^a-zA-Z0-9]/g, "");
		}
		return objectKey;
	},

	fnShowCalculatedValues: function (bHasActiveEntity, bHasDraftEntity, bIsActiveEntity) {
		//Active entity without any draft
		if (bHasActiveEntity === false && bHasDraftEntity === false && bIsActiveEntity === true) {
			return true;
		}
		//Own draft on active entity
		if (bHasActiveEntity === true && bHasDraftEntity === false && bIsActiveEntity === false) {
			return true;
		}
		//Unsaved changes by other user on active entity
		if (bHasActiveEntity === false && bHasDraftEntity === true && bIsActiveEntity === true) {
			return true;
		}
		return false;
	},

	/*
	fnMakeValueHelpOnly: function() {
			var poItemInput = sap.ui.getCore().byId("ui.ssuite.s2p.mm.pur.po.manage.st::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderItemTP"
			+ "--GeneralInformationItem::PurchaseOrderItem::Field-input");

			if (poItemInput && poItemInput.setValueHelpOnly) {
				poItemInput.setValueHelpOnly(true);
			}
	},*/

	fnOverdueItemsValueState: function (iNumberOfOverduePurOrdItm) {
		if (parseInt(iNumberOfOverduePurOrdItm, 10) === iNumberOfOverduePurOrdItm) {
			iNumberOfOverduePurOrdItm = parseInt(iNumberOfOverduePurOrdItm, 10); //decimal system radix
			if (iNumberOfOverduePurOrdItm > 0) {
				return sap.ui.core.ValueState.Error;
			} else if (iNumberOfOverduePurOrdItm === 0) {
				return sap.ui.core.ValueState.Success;
			} else if (iNumberOfOverduePurOrdItm < 0) {
				return sap.ui.core.ValueState.None;
			}
		} else {
			return sap.ui.core.ValueState.None;
		}
	},

	fnShowPurchaseOrderAdvancedIcon: function (bIsAdvancedPurchaseOrder) {
		if (bIsAdvancedPurchaseOrder === 'X') {
			return true;
		} else {
			return false;
		}
	},

	fnCalcRelevance: function (sValue) {

		var fValue = parseFloat(sValue).toFixed(6);
		if (fValue > 0 && fValue <= 1) {
			fValue = fValue / 1 * 5;
		} else {
			fValue = 0;
		}
		return fValue;
	},

	nameIdTuple: function (name, id) {
		if (id) {
			return name + ((id) ? " (" + id + ")" : "");
		}
		return "";
	},
	isLinkable: function (id) {
		if (id) {
			if (id !== "") {
				return true;
			} else {
				return false;
			}
		}
		return false;
	},
	isAsText: function (id) {
		if (id) {
			if (id !== "") {
				return false;
			} else {
				return true;
			}
		}
		return true;
	},
	listDocument: function (sPoId, sLineId, sInfoRecordId) {
		if (sPoId === "") {
			return sInfoRecordId;
		} else {
			return sPoId + ((sLineId) ? "/" + sLineId + "" : "");
		}
	},
	listDocumentText: function (sPoId, sLineId, sPurchasingDocumentCategory) {
		var oResourceBundle = this.getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle();
		var sText;
		if (sPurchasingDocumentCategory === "F") {
			sText = oResourceBundle.getText("PURCHASE_ORDER");
		}
		if (sPurchasingDocumentCategory === "K") {
			sText = oResourceBundle.getText("PURCHASE_CONTRACT");
		}
		if (sPurchasingDocumentCategory === "I") {
			sText = oResourceBundle.getText("INFO_RECORD");
		}
		return sText;
	},
	salesOrder: function (hdrId, itmId) {
		if (hdrId === "") {
			return "";
		} else {
			return hdrId + ((itmId) ? "/" + itmId + "" : "");
		}
	},
	nameIdTupleMaterial: function (name, id) {
		if (id) {
			return name + ((id) ? " (" + id + ")" : "");
		} else {
			return name;
		}
		return "";
	},
	pricePer: function (sPriceUnit, sPurchaseOrderPriceUnitName, sPurchaseOrderPriceUnit) {
		function nameIdTupleValidated(name, id) {
			if (id) {
				if (name !== "") {
					return name + ((id) ? " (" + id + ")" : "");
				} else {
					return id;
				}
			}
			return "";
		}
		return this.getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle().getText("PRICEUNIT_SMALL") +
			" " + sPriceUnit + " " + nameIdTupleValidated(sPurchaseOrderPriceUnitName, sPurchaseOrderPriceUnit);
	},

	fnUTCDateToLocal: function (date) {
		if (date) {
			var dateTmp = date.getFullYear() + "-" + ("0" + (date.getMonth() + 1)).slice(-2) + "-" + ("0" + date.getDate()).slice(-2);
			var dateNew = new Date(dateTmp);
			return dateNew;
		}
	},

	fnDeliveryDateColumnVisible: function (sProductType) {
		// Material
		/*if (sProductType === "1") {
			return true;
		} else {
			return false;
		}*/
	},

	fnPerformancePeriodColumnVisible: function (sProductType) {
		// Service
		/*if (sProductType === "2") {
			return true;
		} else {
			return false;
		}*/
	},


	/**
		 * @HJC for US BLM 280 on 31.07.2019
		 * 
		 * @function: getVisibility
		 * @description: Set Indicator Visibility State
		 * @param: sInd
		 * @returns: bState
		 */
	getVisibility: function (sInd) {

		var bState = false;

		if (sInd === "X") {
			bState = true;
		}

		return bState;

	},

	/**
	 * @HJC for US BLM  on 28.11.2019
	 * 
	 * @function: getPOSMisalignmentIcon
	 * @description: Set Misalignment Icon
	 * @param: sColor
	 * @returns: sIcon
	 */
	getPOSMisalignmentIcon : function(sColor)
	{
		var sIcon = "";

		if (sColor === "Orange") {
			sIcon = "sap-icon://project-definition-triangle-2";
		} else if (sColor === "Green") {
			sIcon = "sap-icon://color-fill";
		} else if (sColor === "Red") {
			sIcon = "sap-icon://circle-task-2";
		}

		return sIcon;
	},

	/**
		 * @HJC for US BLM 280 on 31.07.2019
		 * 
		 * @function: getPOSMisalignmentState
		 * @description: Set Misalignment State
		 * @param: sColor
		 * @returns: sState
		 */
	getPOSMisalignmentState: function (sColor) {

		var sIconColor = "";
			if (sColor === "Orange") {
				sIconColor = "#f0c91f";
			} else if (sColor === "Green") {
				sIconColor = "#13ab1f";
			} else if (sColor === "Red") {
				sIconColor = "#db2d21";
			}

			return sIconColor;

		// var sState = "None";

		// if (sColor === "Orange") {
		// 	sState = "Warning";
		// } else if (sColor === "Red") {
		// 	sState = "Error";
		// } else if (sColor === "Green") {
		// 	sState = "Success";
		// }

		// return sState;
	},

	/**
	 * @HJC on 31.07.2019
	 * 
	 * @function: getPOSMisalignmentVisible
	 * @description: Manage visibility of Misalignment State
	 * @param: sColor
	 * @returns: bVisible
	 */
	getPOSMisalignmentVisible: function (sColor) {

		var bVisible = false;

		if (sColor !== "") {
			bVisible = true;
		}

		return bVisible;
	},

	/**
	 * @HJC on 15.11.2019
	 * 
	 * @function: getPricingButtonText
	 * @description: Set Pricing Edit Button Text
	 * @param: bState
	 * @returns: sText
	 */
	getPricingButtonText: function(bState){
		var sText = "";
		if(bState){
			sText = "Display Pricing Info";
		}
		else{
			sText = "Edit Pricing Info";
		}
		return sText;
	},

	/**
	 * 
	 * 
	 * 
	 */
	getDateButtonText: function(bState){
		var sText = "";
		if(bState){
			sText = "Display Dates";
		}
		else{
			sText = "Edit Dates";
		}
		return sText;
	},

	/**
	 * @SSH on 26.11.2019
	 * 
	 * @function: getPubIcon
	 * @description: Set Icon for Publication Status
	 * @param: sStatus
	 * @returns: sIcon
	 */
	getPubIcon : function(sStatus){
		var sIcon = "";

		if (sStatus === "0") {
			sIcon = "sap-icon://project-definition-triangle-2";
		} else if (sStatus === "1") {
			sIcon = "sap-icon://color-fill";
		} else if (sStatus === "2") {
			sIcon = "sap-icon://circle-task-2";
		}

		return sIcon;
	},

	/**
	 * @SSH on 26.11.2019
	 * 
	 * @function: getPubState
	 * @description: Set State for Publication Status
	 * @param: sStatus
	 * @returns: sColor
	 */
	getPubColor : function(sStatus){
		var sColor = "";

		if(sStatus === "0")
			sColor = "#f0c91f";
		else if(sStatus === "1")
			sColor = "#13ab1f";
		else if(sStatus === "2")	
			sColor = "#db2d21";
	
		return sColor;
	}
};