/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */

jQuery.sap.declare("airbus.ui.2j86.disp.po.Component");
sap.ui.getCore().loadLibrary("sap.ui.generic.app");
jQuery.sap.require("sap.ui.generic.app.AppComponent");
jQuery.sap.require("sap.ui.model.odata.AnnotationHelper");
jQuery.sap.require("airbus.ui.2j86.disp.po.model.formatter");
jQuery.sap.require("airbus.ui.2j86.disp.po.util.Common");
sap.ui.generic.app.AppComponent.extend("airbus.ui.2j86.disp.po.Component", {
    metadata: {
        "manifest": "json"
    }

});


