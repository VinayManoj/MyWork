/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.declare("ui.ssuite.s2p.mm.pur.po.manage.st.s1.util.ExcelExportHelper");

ui.ssuite.s2p.mm.pur.po.manage.st.s1.util.ExcelExportHelper = {

    getDownloadUrl : function(oBinding, sFormat, aExclude) {

		var aParams = [],
        sPath = null;
        if (sFormat) {
            aParams.push("$format=" + encodeURIComponent(sFormat));
        }
        if(oBinding){
        	if (oBinding.sSortParams) {
            aParams.push(oBinding.sSortParams);
	        }
	        if (oBinding.sFilterParams) {
	            aParams.push(oBinding.sFilterParams);
	        }
	        if (oBinding.sCustomParams) {
	        	var sCustomParams = oBinding.sCustomParams;
	        	if (aExclude) {
		        	var aCustomParams = sCustomParams.split("=");
		        	if (aCustomParams.length === 2) {
		        		var sCustomParamsTmp = decodeURIComponent(aCustomParams[1]);
		
			        	for (var i = 0; i < aExclude.length; i++) {
			        		sCustomParamsTmp = sCustomParamsTmp.replace(aExclude[i] + ",", ""); //String + Comma
			        		sCustomParamsTmp = sCustomParamsTmp.replace(aExclude[i], ""); //String
			        	}
			
			        	sCustomParamsTmp = encodeURIComponent(sCustomParamsTmp);
			        	sCustomParams = aCustomParams[0] + "=" + sCustomParamsTmp;
		        	}
	        	}
	            aParams.push(sCustomParams);
	        }
	        sPath = oBinding.oModel.resolve(oBinding.sPath, oBinding.oContext);
        }
        
        if (sPath && oBinding) {
            var downloadURL = oBinding.oModel._createRequestUrl(sPath, null, aParams);
            return this.removeURLParameter(downloadURL, "$expand");
        }
        
    },
    
    removeURLParameter : function (url, parameter) {
    //prefer to use l.search if you have a location/link object
	    var urlparts= url.split('?');   
	    if (urlparts.length>=2) {
	
	        var pars= urlparts[1].split(/[&;]/g);
	
	        //reverse iteration as may be destructive
	        for (var i= pars.length; i-- > 0;) {    
	            //idiom for string.startsWith
	            if (pars[i].lastIndexOf(parameter, 0) !== -1) {  
	                pars.splice(i, 1);
	            }
	        }
	
	        url= urlparts[0] + (pars.length > 0 ? '?' + pars.join('&') : "");
	        return url;
	    } else {
	        return url;
    	}
    }
    
};