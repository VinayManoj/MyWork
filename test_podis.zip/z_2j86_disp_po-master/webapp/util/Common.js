/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.declare("ui.ssuite.s2p.mm.pur.po.manage.st.s1.util.Common");

ui.ssuite.s2p.mm.pur.po.manage.st.s1.util.Common = {
	/**
	 * Called to navigate to external factsheet
	 * @param {Object} obj Object which is triggering navigation request on UI side
	 */
	navToFactsheet: function(oEvent) {

		var oCrossAppNav = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService("CrossApplicationNavigation");
		var oData = oEvent.getSource().getBindingContext().getObject();
		var sSemanticObject = oEvent.getSource().data("SemanticObject");

		if (oData && sSemanticObject !== "") {
			var oTarget = new Object();
			Object.defineProperty(oTarget, "semanticObject", {
				value: sSemanticObject,
				enumerable: true
			});
			Object.defineProperty(oTarget, "action", {
				value: "displayFactSheet",
				enumerable: true
			});
			JSON.stringify(oTarget);

			var oParams = new Object();
			var sValue = oData[sSemanticObject];
			Object.defineProperty(oParams, sSemanticObject, {
				value: sValue,
				enumerable: true
			});
			JSON.stringify(oParams);

			var oArgs = new Object();
			Object.defineProperty(oArgs, "target", {
				value: oTarget,
				enumerable: true
			});
			Object.defineProperty(oArgs, "params", {
				value: oParams,
				enumerable: true
			});
			JSON.stringify(oArgs);

			var target = oArgs.target.semanticObject + "-" + oArgs.target.action + "?" + oArgs.target.semanticObject + "=" + oArgs.params[oArgs.target.semanticObject];

			var _that = this;
			var oCrossAppNavigator = sap.ushell && sap.ushell.Container && sap.ushell.Container
				.getService("CrossApplicationNavigation");
			sap.ushell.Container.getService("CrossApplicationNavigation")
				.isIntentSupported([target])
				.done(function(oData) {
					if (oData[target].supported) {
						if (oCrossAppNav) {
							oCrossAppNav.toExternal(oArgs);
						}
					} else {
						var bCompact = !!_that.getView().$().closest(".sapUiSizeCompact").length;
						sap.m.MessageBox.show(
							_that.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle().getText("MESSAGE_NO_NAVIGATION_POSSIBLE"), {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: _that.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle().getText("MESSAGE_SEVERITY_ERROR"),
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function(oAction) {},
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					}
				});
		}
	}
};