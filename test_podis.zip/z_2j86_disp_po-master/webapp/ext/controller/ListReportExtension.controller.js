/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.require("airbus.ui.2j86.disp.po.util.ExcelExportHelper");
jQuery.sap.require("sap.ui.core.util.Export");
jQuery.sap.require("sap.ui.core.util.ExportTypeCSV");

sap.ui.controller("airbus.ui.2j86.disp.po.ext.controller.ListReportExtension", {
	
	onListNavigationExtension: function(oEvent) {
		
		var oNavigationController = this.extensionAPI.getNavigationController();
		var oBindingContext = oEvent.getSource().getBindingContext();
		var oObject = oBindingContext.getObject();
		
		var mParameters = new Object();
		mParameters["PurchaseOrder"] = oObject.PurchaseOrder;
		mParameters["uitype"] = "advanced";
		
		// For Advanced Purchase Orders we trigger external navigation, for Fiori POs we use internal navigation
		if (oObject.IsAdvancedPurchaseOrder === "X") {
			// COMMENTED AV 16-07-19   oNavigationController.navigateExternal("MEPO_WEBGUI", mParameters);
			return false; //Added by AVE 16-07-19
		} else {
			// return false to trigger the default internal navigation
			return false;
		}
		// return true is necessary to prevent further default navigation
		return true;
		
	}
	
});