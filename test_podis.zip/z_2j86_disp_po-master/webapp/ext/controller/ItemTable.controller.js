/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.require("sap.m.MessageBox");

sap.ui.controller("airbus.ui.2j86.disp.po.ext.controller.ItemTable", {
	
	/**
	 * Function will be called on initial view build up
	 * Remark: This will triggered every time the dialog is opneded as the dialog will build up from scratch
	 */
	onInit: function(){
		//Disable SelectAll or at least throw an error in case someone is pressing this button
		var oTable = this.getView().byId("smartPOCreateRefItemsTable");
		var oInnerTable = oTable.getTable();
		if (oInnerTable._getSelectAllCheckbox) { //checking if private SAPUI5 method exist
            oInnerTable._getSelectAllCheckbox().setVisible(false);
        } else {
            oInnerTable.selectAll = function() { //overwrite SAPUI5 method for specific table
                var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
                sap.m.MessageBox.show(
                    this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle().getText(
                        "MESSAGE_NO_SELECT_ALL"), {
                            icon: sap.m.MessageBox.Icon.WARNING,
                            title: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle().getText(
                            "MESSAGE_SEVERITY_WARNING"),
                            actions: [sap.m.MessageBox.Action.OK],
                    onClose: function(oAction) {},
                    styleClass: bCompact ? "sapUiSizeCompact" : ""
        	        }
                );
            };
        }
	},

	/**
	* Function will be called while selection in DropDown "Purchasing Document Type" of Filter Bar is changing
	* @param {Object} oSelectedItem Includes the selection
	*/
	_onChangePurchasingDocumentType: function(oSelectedItem) {
		//Reset selection and set add button enabled=false again
		var oTable = this.getView().byId("smartPOCreateRefItemsTable");
		var oInnerTable = oTable.getTable();
		oInnerTable.removeSelections();
		this.getView().getParent().getBeginButton().setEnabled(false);

		var sKey = oSelectedItem.getParameter("selectedItem").getKey();
		var sEntitySet = this._getEntitySetForCreateWithRef(sKey);
		this.getView().byId("smartFilterBarCreateWithRefDocs").setEntitySet(sEntitySet);
		this.getView().byId("smartPOCreateRefItemsTable").setEntitySet(sEntitySet);

		//For Inforecoreds do not merge cells
		if (sKey !== "IR") {
			this.getView().byId("documentCol").setMergeDuplicates(true);
		}
		else {
			this.getView().byId("documentCol").setMergeDuplicates(false);
		}
	},
	
	/** 
     * Handle change in combo box for document type
     * @param {Object} oEvent Event which is triggering the change event
     */
    handleDocumentTypeChange : function(oEvent) {
    	var oComboBox = oEvent.getSource();
		var aAllItem = oComboBox.getItems();
		var aAllItemText = [];
		var sValue = oComboBox.getValue().trim();
		for (var i = 0; i < aAllItem.length; i++) {
			aAllItemText.push(aAllItem[i].getText());
		}
		if (aAllItemText.indexOf(sValue) < 0) {
			oComboBox.setValueState("Error");
		} else {
			oComboBox.setValueState("None");
		}
    },
	
	/**
	* Determin EntitySet based on selected key - default PO
	* The selection will be different as this will improve performance
	* @param {String} sKey Key of DropDown Selection in FilterBar
	* @return {String} sKey Returns the EntitySet
	*/
	_getEntitySetForCreateWithRef: function(sKey) {
		switch (sKey) {
			case "PO":
				return "C_PurOrdRefDocPO";
			case "IR":
				return "C_PurOrdRefDocIR";
			case "PC":
				return "C_PurOrdRefDocPC";
			default:
				return "C_PurOrdRefDocPO";
		}
	},

	/**
	 * Called if item is selected to avoid selection of different supplier and to hide multiple checkboxes in case of account assignment
	 * @param {string} oListItem Value of selected item in table
	 * @param {Boolean} bListItemSelcted Value of checkbox to see if it is selected or not
	 */
	_changeSelectableOfItems: function(oListItem, bListItemSelcted) {
		var oTable = this.getView().byId("smartPOCreateRefItemsTable");
		var oInnerTable = oTable.getTable();
		var aItems = oInnerTable.getItems();
		var aSelectedItems = oInnerTable.getSelectedItems();
		var sNewSupplier = oListItem ? oListItem.Supplier : this.sCurSupplier;

		this._changeSelectionInCaseOfMultiAccounting(oListItem, bListItemSelcted, aItems, aSelectedItems);
		
		if (aSelectedItems.length === 0) {
			sNewSupplier = "";
			this.sCurSupplier = "";
		}

		//If no item is selected any longer delete it
		if (aSelectedItems.length === 0 && (!this.sCurSupplier || this.sCurSupplier === "")) {
			delete this.sCurSupplier;
		//If a supplier is there, set it globally
		} else if (sNewSupplier !== undefined) {
			this.sCurSupplier = sNewSupplier;
		}

		//Loop through all items and change behavior if needed
		for (var j = 0, len = aItems.length; j < len; j++) {
			var oTmpItem = aItems[j];

			this._changeSelectableOfSingleItem(j, aItems, oTmpItem);
		}
	},

	/**
	 * Handle the selection chnage of one single item
	 * @param {Integer} j Position in table
	 * @param {Array} aItems Array of all items in table
	 * @param {Object} oTmpItem Current item which should be processed
	*/
	_changeSelectableOfSingleItem: function(j, aItems, oTmpItem) {
		//Compare last row above with current row and merge them in case of multi-accounting
		if (j > 0) {
			var oLastTmpItem = aItems[j - 1].getBindingContext().getObject();
			var oListTmpItem = oTmpItem.getBindingContext().getObject();
			if (oLastTmpItem.PurchaseOrder === oListTmpItem.PurchaseOrder && 
				oLastTmpItem.PurchaseOrderItem === oListTmpItem.PurchaseOrderItem && 
				oLastTmpItem.PurchasingInfoRecord === oListTmpItem.PurchasingInfoRecord &&
				oLastTmpItem.PurchasingInfoRecordCategory === oListTmpItem.PurchasingInfoRecordCategory &&
				oLastTmpItem.PurchasingOrganization === oListTmpItem.PurchasingOrganization &&
				oLastTmpItem.Plant === oListTmpItem.Plant) {
				oTmpItem.getMultiSelectControl().setVisible(false);
				$("#" + oTmpItem.getId()).removeClass("sapMLIBShowSeparator");
			}
			else {
				oTmpItem.getMultiSelectControl().setVisible(true);
				$("#" + oTmpItem.getId()).addClass("sapMLIBShowSeparator");
			}
		}

		if (oTmpItem.getBindingContext() !== undefined) {
			//Multi-Selection should be only possible for the same Supplier
			if (oTmpItem.getBindingContext().getObject().Supplier !== this.sCurSupplier) {
				if (oTmpItem.getMultiSelectControl()) {
					oTmpItem.getMultiSelectControl().setEnabled(true);
				}
			} else {
				if (oTmpItem.getMultiSelectControl()) {
					oTmpItem.getMultiSelectControl().setEnabled(false);
				}
			}
			//Disable checkbox in case of advanced purchase order
			if (oTmpItem.getBindingContext().getObject().IsAdvancedPurchaseOrder) {
				if (oTmpItem.getMultiSelectControl()) {
					oTmpItem.getMultiSelectControl().setEnabled(false);
				}
			}
			else {
				if (oTmpItem.getMultiSelectControl()) {
					oTmpItem.getMultiSelectControl().setEnabled(true);
				}
			}
		}
	},
	
	/**
	 * Called if item is selected to select/deselect additional sub items shown in list as items according to multi accounting
	 * @param {string} oListItem Value of selected item in table
	 * @param {Boolean} bListItemSelcted Value of checkbox to see if it is selected or not
	 * @param {Array} aItems Array of all Items in Table
	 */
	_changeSelectionInCaseOfMultiAccounting: function(oListItem, bListItemSelcted, aItems) {
		if (oListItem && ((typeof bListItemSelcted !== "undefined") && (bListItemSelcted !== null)) && aItems) {
			for (var i = 0, len = aItems.length; i < len; i++) {
				var oTmpItem = aItems[i];
				var oListTmpItem = oTmpItem.getBindingContext().getObject();
				if (oListItem.PurchaseOrder === oListTmpItem.PurchaseOrder && 
					oListItem.PurchaseOrderItem === oListTmpItem.PurchaseOrderItem && 
					oListItem.PurchasingInfoRecord === oListTmpItem.PurchasingInfoRecord &&
					oListItem.PurchasingInfoRecordCategory === oListTmpItem.PurchasingInfoRecordCategory &&
					oListItem.PurchasingOrganization === oListTmpItem.PurchasingOrganization &&
					oListItem.Plant === oListTmpItem.Plant) {
					oTmpItem.setSelected(bListItemSelcted);
					$("#" + oTmpItem.getId()).removeClass("sapMLIBShowSeparator");
				}
			}
		}
	},

	/**
	 * Called if table is fully new loaded (e.g. by sorting) or if paging is finished
	 */
	_handleUpdateFinished: function() {
		this._changeSelectableOfItems();
	}

});