/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("airbus.ui.2j86.disp.po.ext.controller.OutputManagement", {

		_getMode: function(oUiModel) {
			if (oUiModel && oUiModel.createMode === true) {
				return '';
			} else if (oUiModel && oUiModel.editable === true) {
				return 'E';
			} else {
				return 'D';
			}
		},

		onInit: function() {

			var oController = this;
			var oUiModel;
			var sMode = oController._getMode(oUiModel);
			var sObjectType = "PURCHASE_ORDER";
			var sKey = "PurchaseOrder";
			var sCurrentKey = '';

			if (oController.getView().getModel("ui") !== undefined) {
				oUiModel = oController.getView().getModel("ui").getData();
			}

//			oController._oOutputComponent = sap.ui.getCore().createComponent({
//				name: "sap.ssuite.fnd.om.outputcontrol.outputitems",
//				id: "OutputComponent",
//				settings: {
//					mode: sMode,
//					objectKey: sCurrentKey,
//					objectType: sObjectType
//				}
//			});

			oController.byId("idOutputComponentContainer").setComponent(oController._oOutputComponent);

			this.getOwnerComponent().getModel().attachBatchRequestCompleted(function() {

				if (oController.getOwnerComponent().getBindingContext()) {

					sCurrentKey = oController.getOwnerComponent().getBindingContext().getProperty(sKey);
					sMode = oController._getMode(oUiModel);

					if (!oController._oOutputComponent || sCurrentKey !== oController.sDisplayedKey) {
						oController.sDisplayedKey = sCurrentKey;
					}

					//Change OM to old/new, depending on OData parameter
					oController.getView().byId("idOutputComponentContainer").setVisible(false);
					oController.getView().byId("idOldOutputFlexBox").setVisible(false);

//					var sOutputControlType = oController.getOwnerComponent().getBindingContext().getProperty("PurOrdOutputCtrlType");
//					var sOutputStatusNast = oController.getOwnerComponent().getBindingContext().getProperty("PurchaseOrderOutputStatus");
//
//					if (sOutputControlType && sOutputControlType !== "") {
//						//B is new OM
//						if (sOutputControlType === "B") {
//							oController.getView().byId("idOutputComponentContainer").setVisible(true);
//							oController.getView().byId("idOldOutputFlexBox").setVisible(false);
//
//							if (oController._oOutputComponent) {
//								oController._oOutputComponent.setObjectId(sCurrentKey);
//								oController._oOutputComponent.setEditMode(sMode);
//								oController._oOutputComponent.refresh();
//							}
//						}
//						//C is old OM
//						else if (sOutputControlType === "C") {
//							oController.getView().byId("idOutputComponentContainer").setVisible(false);
//							oController.getView().byId("idOldOutputFlexBox").setVisible(true);
//							if (sOutputStatusNast && sOutputStatusNast !== "") {
//								//States: 0 - Not processed, 1 - Processed, 2 - Processed with Errors
//								if (sOutputStatusNast === "0") {
//									oController.getView().byId("idOutputObjectStatus").setState(sap.ui.core.ValueState.Warning);
//								} else if (sOutputStatusNast === "1") {
//									oController.getView().byId("idOutputObjectStatus").setState(sap.ui.core.ValueState.Success);
//								} else if (sOutputStatusNast === "2") {
//									oController.getView().byId("idOutputObjectStatus").setState(sap.ui.core.ValueState.Error);
//								}
//							}
//						}
//					}
					
				}
			});
		},

		//Navigate to old OM in case link is pressed
		onNavToOldOM: function(oEvent) {
			this.oCrossAppNav = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService("CrossApplicationNavigation");

			var _that = this;
			if (_that.sDisplayedKey && _that.sDisplayedKey !== "") {
				var oNav = (_that.oCrossAppNav && _that.oCrossAppNav.toExternal({
					target: {
						semanticObject: "PurchaseOrder",
						action: "processOutputMessages"
					},
					params: {
						"PurchaseOrder": [_that.sDisplayedKey],
						"ProcessingStatus": " "
					}
				}));
			}
		}

	});
});