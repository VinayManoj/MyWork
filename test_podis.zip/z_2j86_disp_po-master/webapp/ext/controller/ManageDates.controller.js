/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (Controller, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("airbus.ui.2j86.disp.po.ext.controller.ManageDates", {

		/**
		 * 
		 * 
		 */
		onInit: function () {

			var _that = this;

			this.getOwnerComponent().getModel().attachEventOnce("batchRequestCompleted", function () {
				var aFilter = [];
				var sPO = sap.ui.getCore().byId(
					"airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--objectPageHeader").getTitleText();
				aFilter.push(new Filter("Po", FilterOperator.EQ, sPO));
				var oTable = _that.getView().byId("idDatesTable");
				oTable.bindRows({
					path: "pricing>/ETDatesSet",
					filters: aFilter
				});

			});
		},

		/**
		 * @function: onEditDates
		 * @description: Change Editable state of Pricing Table Condition Fields 
		 * @CreatedBy : HJC
		 * @CreatedOn :26.11.2019 
		 * @US :DIGITPROP_BLM-396
		 */
		onEditDates: function () {

			var oPricingStateModel = this.getView().getModel("pricingState");
			var bEditable = oPricingStateModel.getProperty("/state/dateEditable");
			oPricingStateModel.setProperty("/state/dateEditable", !bEditable);
		},

		/**
		 * @function: onSaveDates 
		 * @description: Save PO Delivery and Statistical Date 
		 * @CreatedBy : HJC 
		 * @CreatedOn :27.11.2019 
		 * @US :DIGITPROP_BLM-396
		 */
		onSaveDates: function () {
			var that = this;
			var oModel = this.getView().getModel("pricing");
			if (oModel.hasPendingChanges()) {
				sap.ui.core.BusyIndicator.show();
				oModel.submitChanges({
					success: function (oData, oResponse) {
						sap.ui.core.BusyIndicator.hide();
						that.getView().byId("idDatesTable").getBinding().refresh();
						that.getView().getModel().refresh();
						that._manageDateSave(oData, oResponse);
					},
					error: function () {
						sap.ui.core.BusyIndicator.hide();
					}
				});
			} else {
				sap.m.MessageToast.show("No Data Changed");
			}
		},

		/**
		 * @function: _manageDateSave 
		 * @description: Display Dates Update message 
		 * @CreatedBy : HJC 
		 * @CreatedOn :27.11.2019 
		 * @US :DIGITPROP_BLM-396
		 */
		_manageDateSave: function (oData) {
			var aMessages = [],
				oMessage, sMessage = "";
			var aChangeResponds = oData.__batchResponses[0].__changeResponses;

			for (var i = 0; i < aChangeResponds.length; i++) {
				oMessage = this._retrieveMessages(aChangeResponds[i]);
				aMessages = oMessage ? aMessages.concat(oMessage) : aMessages;
			}

			for (var j = 0; j < aMessages.length; j++) {
				if (sMessage === "") {
					sMessage = "-----: " + aMessages[j].type + " :----- \n" + aMessages[j].title;
				} else {
					sMessage = sMessage + "\n -----: " + aMessages[j].type + " :----- \n" + aMessages[j].title;;
				}

			}

			sap.m.MessageToast.show(sMessage, {
				duration: 6000
			});
		},

		/**
		 * @function: _retrieveMessages 
		 * @description: Retrieve Message from different Levels 
		 * @CreatedBy : HJC 
		 * @CreatedOn :21.11.2019 
		 * @US :DIGITPROP_BLM-319
		 */

		_retrieveMessages: function (oChangesResp) {
			var oFirstLevel, aMessages = [],
				sDetailLength, i;
			var oMessage = {
				type: '',
				title: ''
			};
			try {
				oFirstLevel = JSON.parse(oChangesResp.headers["sap-message"]);
				switch (oFirstLevel.severity) {
				case 'error':
					oMessage.type = 'Error';
					break;
				case 'info':
					oMessage.type = 'Success';
					break;

				default:
					oMessage.type = 'Information';
					break;
				}
				oMessage.title = oFirstLevel.message;
				aMessages = aMessages.concat(oMessage);
			} catch (e) {
				if (oChangesResp.message) {
					switch (oChangesResp.severity) {
					case 'error':
						oMessage.type = 'Error';
						break;
					case 'info':
						oMessage.type = 'Success';
						break;

					default:
						oMessage.type = 'Information';
						break;
					}
					oMessage.title = oChangesResp.message;
					return oMessage;
				} else {
					return;
				}
			}

			if (!oFirstLevel.details) {
				return aMessages;
			}
			sDetailLength = oFirstLevel.details.length;
			if (sDetailLength > -1) {
				for (i = 0; i < sDetailLength; i++) {
					aMessages = aMessages.concat(this._retrieveMessages(oFirstLevel.details[i]));
				}
			}

			return aMessages;
		},

		onAfterRendering: function () {

			var oDateTable = this.getView().byId("idDatesHBox");
			oDateTable.bindElement("pricing>/ETUserActionSet('myId')");
		},

		/**
		 * @function: onDuplicateDate 
		 * @description: Duplicate Date for PO Card
		 * @CreatedBy : SSH
		 * @CreatedOn :17.02.2020
		 * @US :DIGITPROP_BLM-444
		 */
		onDuplicateDate: function (oEvent) {
			var oModel = this.getView().getModel("pricing");
			var oTable = oEvent.getSource().getParent().getParent().getParent().getItems()[1];
			var aItems = oTable._getContexts();
			var oBindingModel = aItems[0].oModel;
			// var sBindingPath = aItems[0].sPath;
			var oFirstStatDate, oFirstPoDate, bDuplicate = false;

			var oFirstRowBinding,sFirstBindingPath;
			// var oFirstRowBinding = oTable.getRows()[0].getBindingContext("pricing");
			// var sFirstBindingPath = oFirstRowBinding.sPath.substr(1);
			var oPendingChange = oModel.getPendingChanges();
			var bStatDate = false;
			var bDelDate = false;
			
			for(var item = 0; item < oTable.getRows().length; item++){
				
				if(oTable.getRows()[item].getCells()[7].getEditable()){
					oFirstRowBinding = oTable.getRows()[item].getBindingContext("pricing");
					sFirstBindingPath = oFirstRowBinding.sPath.substr(1);
					break;
				}
			}

			for (var k in oPendingChange) {


				if (k === sFirstBindingPath) {
					var oChangedData = oPendingChange[sFirstBindingPath];
					if (oChangedData.Podeliverydate !== undefined) {
						bDelDate = true;
					}

					if (oChangedData.Statdeliverydate !== undefined) {
						bStatDate = true;
					}
				}

			}

			for (var i = 0; i < aItems.length; i++) {

				if (bDuplicate === false) {
					if (oBindingModel.getProperty(aItems[i].sPath).Deletionindicator === "") {
						oFirstStatDate = oBindingModel.getProperty(aItems[i].sPath).Statdeliverydate;
						oFirstPoDate = oBindingModel.getProperty(aItems[i].sPath).Podeliverydate;
						bDuplicate = true;
					}
					continue;
				}

				if (oFirstStatDate && oBindingModel.getProperty(aItems[i].sPath).Deletionindicator === "" && bStatDate) {
					oBindingModel.setProperty(aItems[i].sPath + "/Statdeliverydate", oFirstStatDate);
				}
				if (oFirstPoDate && oBindingModel.getProperty(aItems[i].sPath).Deletionindicator === "" && bDelDate) {
					oBindingModel.setProperty(aItems[i].sPath + "/Podeliverydate", oFirstPoDate);
				}
			}
		}

	});
});