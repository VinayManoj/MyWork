/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/suite/ui/generic/template/extensionAPI/extensionAPI"
], function(Controller, ExtensionAPI) {
	"use strict";

	return Controller.extend("airbus.ui.2j86.disp.po.ext.controller.Pricing", {

		bIsFieldChangeOfItem: undefined,
		bIsFieldChangeOfPricing: undefined,
		bIsNewCondition: undefined,
		bIsDeletedCondition: undefined,
		bIsValidation: undefined,
		
		aSideEffectItemFields: ["Material", "Plant", "OrderQuantity", "PurchaseOrderQuantityUnit", "NetPriceAmount", "DocumentCurrency", "NetPriceQuantity"],
		aSideEffectPricingFields: ["ConditionRateValue", "ConditionRateValueUnit", "ConditionQuantity", "ConditionQuantityUnit", "ConditionAmount"],
		
		fnGetSideEffectItemFields: function() {
			return this.aSideEffectItemFields;
		},
		
		fnGetSideEffectPricingFields: function() {
			return this.aSideEffectPricingFields;
		},

		fnIsPricingRelevantRequest: function(aRequests) {
			var i;
			for (i = 0; i < aRequests.length; i++) {

				var vMethod = aRequests[i].method;
				var vUrl = aRequests[i].url;

				if (vMethod === "MERGE") {
				    if ((vUrl.indexOf("C_PurchaseOrderItemTP(", 0) >= 0) || (vUrl.indexOf("C_PurOrdPricingElementTP(", 0) >= 0)) {
				        return true;
				    }
				} else if (vMethod === "POST") {
				    if ((vUrl.indexOf("C_PurchaseOrderItemTP(", 0) >= 0) && (vUrl.indexOf("/to_PurOrdPricingElementTP") !== -1)) {
				        this.bIsNewCondition = true;
				        return true;
				    }
				} else if (vMethod === "DELETE") {
				    if (vUrl.indexOf("C_PurOrdPricingElementTP(", 0) >= 0) {
				        this.bIsDeletedCondition = true;
				        return true;
				    }
				} else if (vMethod === "GET") {
				    if ((vUrl.indexOf("C_ConditionRateValueUnit_VH", 0) >= 0) || (vUrl.indexOf("C_ConditionQuantityUnit_VH", 0) >= 0)) {
				        this.bIsValidation = true;
				        return false;
				    }
				}
			}
		},

		onInit: function() {

			var _that = this;

			this.getOwnerComponent().getModel().attachBatchRequestCompleted(function(oEvent) {

				if (!_that._oPricingComponent) {

					var oUiModel = _that.getView().getModel("ui").getData();
					var sMode;
					var sPath;

					if (oUiModel.createMode === true && oUiModel.editable === true) {
						sMode = 'H';
					} else if (oUiModel.createMode === false && oUiModel.editable === true) {
						sMode = 'V';
					} else {
						// sMode = 'A'; 
						sMode = null;
					}

					if (_that.getOwnerComponent().getBindingContext()) {
						sPath = _that.getOwnerComponent().getBindingContext().getPath();
					}

					if (sPath !== '') {

						_that._oPricingComponent = sap.ui.getCore().createComponent({
							name: "sap.cus.sd.lib.pricing.pricingelements",
							id: "PricingComponent",
							settings: {
								model: _that.getOwnerComponent().getModel(),
								modelPath: sPath + "/to_PurOrdPricingElementTP",
								showTableTitle: false,
								modelEntityName: "C_PurOrdPricingElementTPType",
								editMode: sMode,
								popover: null,
								smartTemplateConsumption: true
							}
						});
						_that.byId("idPricingComponentContainer").setComponent(_that._oPricingComponent);

					}

				} 
				
				if (_that._oPricingComponent && _that.fnIsPricingRelevantRequest(oEvent.getParameters().requests) && _that.bIsFieldChangeOfItem === true) {
					_that._oPricingComponent.refresh();
				}
				
				if (_that._oPricingComponent && _that.fnIsPricingRelevantRequest(oEvent.getParameters().requests) && (_that.bIsFieldChangeOfPricing === true || _that.bIsNewCondition === true || _that.bIsDeletedCondition === true)) {
					
					var oExtensionAPIPromise = ExtensionAPI.getExtensionAPIPromise(_that.getView());
					oExtensionAPIPromise.then(function(oExtensionAPI){
						oExtensionAPI.getTransactionController().executeSideEffects({sourceEntities : ['to_PurOrdPricingElementTP']});
					});
					
					_that._oPricingComponent.refresh();
					
				}

				if (_that.bIsValidation) {
				    _that.bIsValidation = false;
				} else {
				    _that.bIsFieldChangeOfItem = false;
				    _that.bIsFieldChangeOfPricing = false;
				    _that.bIsNewCondition = false;
				    _that.bIsDeletedCondition = false;
				}
			});

			this.getOwnerComponent().getModel().attachPropertyChange(function(oEvent) {
				
				var sChangedProperty = oEvent.getParameter('path');
				
				if (_that.fnGetSideEffectItemFields().indexOf(sChangedProperty) !== -1){
					_that.bIsFieldChangeOfItem = true;
					return;
				}
				
				if (_that.fnGetSideEffectPricingFields().indexOf(sChangedProperty) !== -1){
					_that.bIsFieldChangeOfPricing = true;
					return;
				}
				
			});

		}
	});
});