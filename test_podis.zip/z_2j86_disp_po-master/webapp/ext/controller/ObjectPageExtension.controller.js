/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
jQuery.sap.require("sap.m.MessageBox");

sap.ui.controller("airbus.ui.2j86.disp.po.ext.controller.ObjectPageExtension", {

	onInit: function() {

		var oNavController = this.getOwnerComponent().getAppComponent().getNavigationController();
		var oView = this.getView();

		// Added by SSH to prevent Header Content collapse while scrolling on 09.01.2020
		oView.getContent()[0].setAlwaysShowContentHeader(true);

		// Added by HJC to Hide Copy Action for US 281 
		var oCopyAction = oView.byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--action::MM_PUR_PO_MAINT_V2_SRV.MM_PUR_PO_MAINT_V2_SRV_Entities::C_PurchaseOrderTPCopy_po");
		oView.getContent()[0].getHeaderTitle().removeAction(oCopyAction);

		// Added by HJC to Hide Share button on 22.08.2019
		var oShareAction = oView.byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--template::Share");
		oView.getContent()[0].getHeaderTitle().removeAction(oShareAction);

		// Added by HJC for Hide '+' button in item table US 285

		var oAddButton = oView.byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--ItemsFacet::addEntry");
		var oCopyButton = oView.byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--ItemsFacet::action::MM_PUR_PO_MAINT_V2_SRV.MM_PUR_PO_MAINT_V2_SRV_Entities::C_PurchaseOrderItemTPCopy_po_item");
		var oItemTable = oView.byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--ItemsFacet::Table");
		oItemTable.getCustomToolbar().removeContent(oAddButton);
		oItemTable.getCustomToolbar().removeContent(oCopyButton);


		this.extensionAPI.attachPageDataLoaded(this._executeTrampolin.bind(this, oNavController));
		
		//Check if this is only executed on ObjectPage for C_PurchaseOrderTP
		if (oView.getId() === "airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP") {
			var oItemFacet = this.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--LimitItemsFacet::Table");
			if (oItemFacet) {
				var oTable = this.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--ItemsFacet::Table").getTable();
				if (oTable) {
					oTable.attachSelectionChange(this, this._handleSelectionChangeItemTable);
				}
			}
			var oLimitFacet = this.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--LimitItemsFacet::Table");
			if (oLimitFacet) {
				var oLimitTable = this.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--LimitItemsFacet::Table").getTable();
				if (oLimitTable) {
					oLimitTable.attachSelectionChange(this, this._handleSelectionChangeLimitItemTable);
				}
			}
		}

		// if (oView.getId() === "airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderItemTP") {
		// 	this.extensionAPI.attachPageDataLoaded(this._refreshPricing);
		// }

	},
	
	onAfterRendering: function() {
		// Added by HJC on 27.09.2019
		var oTable = this.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--ItemsFacet::gridTable");
		oTable.setSelectionMode("Single");  //MultiToggle
		oTable.setSelectionBehavior("Row");
		oTable.setRowActionCount(0);
		// Commented by HJC on 27.09.2019
		// var oTable = this.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--ItemsFacet::responsiveTable");


		// Added by SSH to	manage 'Edit' button Visibility
		var oView = this.getView();

		//Read User authorization for PO Card Edit Mode
		this.getView().getModel("pricing").read("/ETUserActionSet('myId')",{
			async : false,
			success: function(data,oRes){
				if(!data.bPOCardEdit){
					var oEditButton = oView.byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--edit");
					oView.getContent()[0].getHeaderTitle().removeAction(oEditButton);
				}
			},
			error: function(){
				
			}
		
		});			


		if (oTable !== undefined) {
			oTable.attachEvent("updateFinished", $.proxy(function() {
				this._validateItemCategory(oTable);
			}, this));
		}


		var oModel = this.getView().getModel();
		oModel.attachRequestCompleted(function(oEvent){
			this._validateItemCategoryNew(oTable);
		}, this);
	},
	
	_validateItemCategory: function(oTable) {
		var aColumns = oTable.getColumns(), nIndex;
		
		aColumns.forEach(function(oColumn, nColumn) {
			if (oColumn.getId() === "airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--ItemsFacet::Table-PurOrdExternalItemCategory") {
				nIndex = nColumn;
			}
		});

		var aItems = oTable.getItems();
		aItems.forEach(function(oItem) {
			var aCells = oItem.getCells();

			// Added by HJC to Deactivate the Item Selection 
			oItem.setType("Inactive");
			
			aCells.forEach(function(oCell, nCell) {
				if (nIndex === nCell && oCell.getEdit) {
					if (oCell.getEdit() instanceof sap.ui.comp.smartfield.SmartField) {
						var oContent = oCell.getEdit().getAggregation("_content");
						if (oContent && oContent.setValueHelpOnly) {
							oContent.setValueHelpOnly(true);
						}
					}
				}
			});
		});
	},


	// Added by HJC 

	_validateItemCategoryNew: function(oTable) {
		var aColumns = oTable.getColumns(), nIndex;
		
		aColumns.forEach(function(oColumn, nColumn) {
			if (oColumn.getId() === "airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--ItemsFacet::Table-PurOrdExternalItemCategory") {
				nIndex = nColumn;
			}
		});

		var aItems = oTable.getRows();
		aItems.forEach(function(oItem) {
			var aCells = oItem.getCells();

		
			aCells.forEach(function(oCell, nCell) {
				if (nIndex === nCell && oCell.getEdit) {
					if (oCell.getEdit() instanceof sap.ui.comp.smartfield.SmartField) {
						var oContent = oCell.getEdit().getAggregation("_content");
						if (oContent && oContent.setValueHelpOnly) {
							oContent.setValueHelpOnly(true);
						}
					}
				}
			});
		});
	},
	
	_refreshPricing: function(oEvent) {
		var sPath = oEvent.context.getPath();
		var sEntitySet = sPath.substring(1, sPath.indexOf("("));
		if (sEntitySet === "C_PurchaseOrderItemTP") {
			var oPricingComp = sap.ui.getCore().getComponent("PricingComponent");
			if (oPricingComp) {
				if (sPath + "/to_PurOrdPricingElementTP" !== oPricingComp.getModelPath()) {
					oPricingComp.setModelPath(sPath + "/to_PurOrdPricingElementTP");
				}
				var oUiModel = oPricingComp.getModel("ui").getData();
				var sMode;
				if (oUiModel.createMode === true && oUiModel.editable === true) {
					sMode = 'H';
				} else if (oUiModel.createMode === false && oUiModel.editable === true) {
					sMode = 'V';
				} else {
					// sMode = 'A'; 
					sMode = null;
				}
				oPricingComp.setEditMode(sMode);
				oPricingComp.refresh();
			}
		}
	},

	/**
	 * Function to handle restoring of marked as deleted item
	 * @param {Object} oEvent Event which is triggering the function (Selection-Change in Item Table)
	 * @param {Object} oData Data which should be provided in the handler, we are using the this-context of the caller to access the view
	 */
	_handleSelectionChangeItemTable: function(oEvent, oData) {
		var _that = oData;
		var oDataOfItem = _that.getView().getModel().getData(oEvent.getParameter("listItem").getBindingContextPath());
		var oDeleteButton = _that.byId("deleteBut");
		var oRestoreButton = _that.byId("restoreBut");
		if (oDataOfItem && oDeleteButton && oRestoreButton) {
			var sDeletionCode = oDataOfItem.PurchasingDocumentDeletionCode;
			if (typeof sDeletionCode !== "undefined" && sDeletionCode !== "") {
				oDeleteButton.setEnabled(false);
				oRestoreButton.setEnabled(true);
			} else if (typeof sDeletionCode !== "undefined" && sDeletionCode === "") {
				oDeleteButton.setEnabled(true);
				oRestoreButton.setEnabled(false);
			}
		}
	},
	
	/**
	 * Function to handle restoring of marked as deleted limit item
	 * @param {Object} oEvent Event which is triggering the function (Selection-Change in Limit Item Table)
	 * @param {Object} oData Data which should be provided in the handler, we are using the this-context of the caller to access the view
	 */
	_handleSelectionChangeLimitItemTable: function(oEvent, oData) {
		var _that = oData;
		var oDataOfItem = _that.getView().getModel().getData(oEvent.getParameter("listItem").getBindingContextPath());
		var oDeleteButton = _that.byId("deleteLimitBut");
		var oRestoreButton = _that.byId("restoreLimitBut");
		if (oDataOfItem && oDeleteButton && oRestoreButton) {
			var sDeletionCode = oDataOfItem.PurchasingDocumentDeletionCode;
			if (typeof sDeletionCode !== "undefined" && sDeletionCode !== "") {
				oDeleteButton.setEnabled(false);
				oRestoreButton.setEnabled(true);
			} else if (typeof sDeletionCode !== "undefined" && sDeletionCode === "") {
				oDeleteButton.setEnabled(true);
				oRestoreButton.setEnabled(false);
			}
		}
	},
	
	onRestoreItem: function(oEvent){
		this._onRestoreItem(oEvent, "airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--ItemsFacet::Table");
	},
	
	onRestoreLimitItem: function(oEvent){
		this._onRestoreItem(oEvent, "airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--LimitItemsFacet::Table");
	},
	/**
	 * Function to handle restoring of marked as deleted item
	 * @param {Object} oEvent Event which is triggering the function (Restore-Button)
	 */
	_onRestoreItem: function(oEvent, tableId) {
		var _that = this;
		var oTable = this.getView().byId(tableId).getTable();
		
		// Added by HJC on 27.09.2019 for Grid Table Change

		var sIndex = oTable.getSelectedIndex();

		if (sIndex > -1){
			var oContext = oTable.getContextByIndex(sIndex);
			var sPath = oContext.sPath;

			var oDataOfItem = this.getView().getModel().getData(sPath);
			if (oDataOfItem) {
				var sDeletionCode = oDataOfItem.PurchasingDocumentDeletionCode;
				if (typeof sDeletionCode !== "undefined" && sDeletionCode !== "") {
					this.getView().getModel().callFunction("/POItemUndoDelete", {
						urlParameters: {
							DraftUUID: oDataOfItem.DraftUUID
						},
						method: "POST",
						success: _that._onRestoreSuccess(_that, tableId)
					});
				}
			}

		} else {
			sap.m.MessageBox.show(this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle().getText(
				"SELECT_ITEM"), {
				icon: sap.m.MessageBox.Icon.ERROR,
				title: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle().getText(
					"MESSAGE_SEVERITY_ERROR"),
				actions: [sap.m.MessageBox.Action.OK],
				onClose: null
			});
		}
		
		// End of Grid Table Change	



		// Commented By HJC on 27.09.2019

		// if (oTable.getSelectedItem()) {
		// 	var oDataOfItem = this.getView().getModel().getData(oTable.getSelectedItem().getBindingContextPath());
		// 	if (oDataOfItem) {
		// 		var sDeletionCode = oDataOfItem.PurchasingDocumentDeletionCode;
		// 		if (typeof sDeletionCode !== "undefined" && sDeletionCode !== "") {
		// 			this.getView().getModel().callFunction("/POItemUndoDelete", {
		// 				urlParameters: {
		// 					DraftUUID: oDataOfItem.DraftUUID
		// 				},
		// 				method: "POST",
		// 				success: _that._onRestoreSuccess(_that, tableId)
		// 			});
		// 		}
		// 	}
		// } else {
		// 	sap.m.MessageBox.show(this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle().getText(
		// 		"SELECT_ITEM"), {
		// 		icon: sap.m.MessageBox.Icon.ERROR,
		// 		title: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle().getText(
		// 			"MESSAGE_SEVERITY_ERROR"),
		// 		actions: [sap.m.MessageBox.Action.OK],
		// 		onClose: null
		// 	});
		// }

		// Comment end on 27.09.2019
	},
	
	_onRestoreSuccess: function(_that, tableId) {
		_that.extensionAPI.refresh(tableId);
		if(tableId.includes("Limit")){
			_that.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--restoreLimitBut").setEnabled(false);
			_that.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--deleteLimitBut").setEnabled(true);
		}
		else{
			_that.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--restoreBut").setEnabled(false);
			_that.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--deleteBut").setEnabled(true);
		}
		_that.getOwnerComponent().getModel().read(_that.getView().getBindingContext().getPath(), {
			urlParameters: "$expand=to_Language%2cto_DocumentCurrency%2cto_Supplier%2cto_PurchasingGroup%2cto_CompanyCode%2cto_PurchasingOrganization%2cto_PaymentTerms%2cto_InvoicingParty%2cto_IncotermsVersion%2cto_IncotermsClassification%2cto_PurOrdSupplierAddressTP"
		});
	},
	
	onDeleteItem: function(oEvent){
		this._onDeleteItem(oEvent, "airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--ItemsFacet::Table");
	},
	
	onDeleteLimitItem: function(oEvent){
		this._onDeleteItem(oEvent, "airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--LimitItemsFacet::Table");
	},
	/**
	 * Function to handle item deletion
	 * @param {Object} oEvent Event which is triggering the function (Delete-Button)
	 */
	_onDeleteItem: function(oEvent, tableId) {
		var _that = this;
		var oTable = this.getView().byId(tableId).getTable();


		// Added by HJC on 27.09.2019 for Grid Table Change

		var sIndex = oTable.getSelectedIndex();

		if (sIndex > -1){
			var oContext = oTable.getContextByIndex(sIndex);
			var sPath = oContext.sPath;

			var oDataOfItem = this.getView().getModel().getData(sPath);
			if (oDataOfItem) {
				var sDeletionCode = oDataOfItem.PurchasingDocumentDeletionCode;
				if (typeof sDeletionCode !== "undefined" && sDeletionCode === "") {
					this.getView().getModel().callFunction("/POItemDelete", {
						urlParameters: {
							DraftUUID: oDataOfItem.DraftUUID
						},
						method: "POST",
						success: function(oResponse) {
							_that._onDeleteSuccess(_that, tableId, oResponse);
						}
					});
				}
			}

		} else {
			sap.m.MessageBox.show(this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle().getText(
				"SELECT_ITEM"), {
				icon: sap.m.MessageBox.Icon.ERROR,
				title: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle().getText(
					"MESSAGE_SEVERITY_ERROR"),
				actions: [sap.m.MessageBox.Action.OK],
				onClose: null
			});
		}
		
		// End of Grid Table Change	




		// Commented By HJC on 27.09.2019

		// if (oTable.getSelectedItem()) {
		// 	var oDataOfItem = this.getView().getModel().getData(oTable.getSelectedItem().getBindingContextPath());
		// 	if (oDataOfItem) {
		// 		var sDeletionCode = oDataOfItem.PurchasingDocumentDeletionCode;
		// 		if (typeof sDeletionCode !== "undefined" && sDeletionCode === "") {
		// 			this.getView().getModel().callFunction("/POItemDelete", {
		// 				urlParameters: {
		// 					DraftUUID: oDataOfItem.DraftUUID
		// 				},
		// 				method: "POST",
		// 				success: function(oResponse) {
		// 					_that._onDeleteSuccess(_that, tableId, oResponse);
		// 				}
		// 			});
		// 		}
		// 	}
		// } else {
		// 	sap.m.MessageBox.show(this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle().getText(
		// 		"SELECT_ITEM"), {
		// 		icon: sap.m.MessageBox.Icon.ERROR,
		// 		title: this.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle().getText(
		// 			"MESSAGE_SEVERITY_ERROR"),
		// 		actions: [sap.m.MessageBox.Action.OK],
		// 		onClose: null
		// 	});
		// }

		// End of Comment 
	},

	_onDeleteSuccess: function(_that, tableId, oResponse) {
		_that.extensionAPI.refresh(tableId);
		if(oResponse.ActiveEntityDeleted === true) {
			if(tableId.includes("Limit")){
				_that.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--restoreLimitBut").setEnabled(true);
				_that.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--deleteLimitBut").setEnabled(false);
			}
			else{
				_that.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--restoreBut").setEnabled(true);
				_that.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--deleteBut").setEnabled(false);
			}
		}
		else{
			if(tableId.includes("Limit")){
				_that.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--restoreLimitBut").setEnabled(false);
				_that.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--deleteLimitBut").setEnabled(false);
			}
			else{
				_that.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--restoreBut").setEnabled(false);
				_that.getView().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--deleteBut").setEnabled(false);
			}			
		}
		_that.getOwnerComponent().getModel().read(_that.getView().getBindingContext().getPath(), {
			urlParameters: "$expand=to_Language%2cto_DocumentCurrency%2cto_Supplier%2cto_PurchasingGroup%2cto_CompanyCode%2cto_PurchasingOrganization%2cto_PaymentTerms%2cto_InvoicingParty%2cto_IncotermsVersion%2cto_IncotermsClassification%2cto_PurOrdSupplierAddressTP"
		});
	},
	//Eventhandler for Trampolin (Dynamic Feature Check)
	_executeTrampolin: function(oNavController, oEvent) {

		var oContext = oEvent.context;
		var sActivePO = oContext.getProperty("PurchaseOrder");
		var bIsAdvancedPurchaseOrder = oContext.getProperty("IsAdvancedPurchaseOrder");
		var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");

//		if (bIsAdvancedPurchaseOrder === "X") {
//
//			oNavController.navigateToRoot(true);
//			setTimeout(function() {
//
//				oCrossAppNav.toExternal({
//					target: {
//						semanticObject: "PurchaseOrder",
//						action: "display"
//					},
//					params: {
//						"PurchaseOrder": [sActivePO],
//						"uitype": "advanced"
//					}
//				});
//
//			}, 0);
//
//		}

	},

	//////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////
	//            IMPLEMENTATION OF CREATE WITH REF BREAKOUT            //
	//////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////////////////////
	//Function for button "Create with Ref"
	onCustomActionCreateWithRef: function() {

		var oModel = this.getView().getModel();
		var oMetaModel = this.getView().getModel().getMetaModel();
		var sPath = "/C_PurOrdRefDocPO";
		var oViewContainer = new sap.m.VBox();
		var that = this;

		var oTemplateView = sap.ui.view({
			preprocessors: {
				xml: {
					bindingContexts: {
						meta: oMetaModel.getMetaContext(sPath)
					},
					models: {
						meta: oMetaModel
					}
				}
			},
			type: sap.ui.core.mvc.ViewType.XML,
			viewName: "airbus.ui.2j86.disp.po.ext.view.ItemTable"
		});

		oTemplateView.setModel(oModel);
		//oTemplateView.bindElement(sPath);
		oViewContainer.addItem(oTemplateView);

		this._oDialog = new sap.m.Dialog({
			title: "{i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP>VALUE_HELP_REFERENCE_TITLE}",
			contentWidth: "100%",
			contentHeight: "100%",
			stretchOnPhone: true,
			showCloseButton: true,
			beginButton: new sap.m.Button({
				text: "{i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP>ADDREFITEMS}",
				press: function() {
					var oResult = that.extensionAPI.securedExecution(that._addRefItemsToPO.bind(that));
					oResult.then(function() {
						that._oDialog.close();
					}, function(sErrorText) {
						that._oDialog.close();
						var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
						sap.m.MessageBox.show(
							sErrorText, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: that.getView().getModel("i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP").getResourceBundle().getText(
									"MESSAGE_SEVERITY_ERROR"),
								actions: [sap.m.MessageBox.Action.OK],
								onClose: function(oAction) {},
								styleClass: bCompact ? "sapUiSizeCompact" : ""
							}
						);
					});
				},
				enabled: false
			}),
			endButton: new sap.m.Button({
				text: "{i18n|sap.suite.ui.generic.template.ObjectPage|C_PurchaseOrderTP>CANCEL}",
				press: function() {
					that._cancelRefItemsToPO();
				}
			}),
			//Deactivate variants by making them invisible, due the lack of use-case for it on the breakout.
			//Using the Dev Tools of Chrome exhibits the variant
			beforeOpen: function() {
				var templateView = this.getContent()[0];
				var variant = templateView.getContent()[0].getContent()[0].getContent()[0];
				variant.setVisible(false);
			},
			afterOpen: function() {
				//attachSelectionChange manually after opening the createWithRef dialog, so that items can be selected at all
				var templateView = this.getContent()[0];
				var smartTable = templateView.getContent()[1];
				var smartFilterBar = templateView.getContent()[0];
				smartTable.getTable().attachSelectionChange(that._handleSelectionChangeInRefItems);

				//If Supplier is already set, use it as hard filter criteria
				var sSupplier = that.getView().getBindingContext().getObject().Supplier;
				if (sSupplier && sSupplier !== "") {
					var bTableShowOverlay = smartTable.getTable().getShowOverlay();
					smartFilterBar.setFilterData({
						Supplier: sSupplier
					});
					smartFilterBar.getControlByKey("Supplier").setEnabled(false);
					smartTable.getTable().setShowOverlay(bTableShowOverlay);
				} else {
					smartFilterBar.getControlByKey("Supplier").setEnabled(true);
				}
			}
		});
		this._oDialog.addContent(oTemplateView);
		this.getView().addDependent(this._oDialog);
		jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);

		this._oDialog.open();
	},

	//Function to add ref items to po while closing create with ref dialog
	_addRefItemsToPO: function() {
		var _that = this;

		return new Promise(function(resolve, reject) {
			
			_that._oDialog.setBusy(true);

			var oTable = _that._oDialog.getContent()[0].getContent()[1]; //1 is based on XML Fragment position of smartTable
			var oInnerTable = oTable.getTable();
			var aItems = oInnerTable.getSelectedItems();

			//Ensure that no framework side batch groups are overwritten
			var aDeferredBatchGroups = _that.getView().getModel().getDeferredBatchGroups();
			if ($.inArray("CreateWithReference", aDeferredBatchGroups) === -1) {
				aDeferredBatchGroups.push("CreateWithReference");
				_that.getView().getModel().setDeferredBatchGroups(aDeferredBatchGroups);
			}

			for (var i = 0, len = aItems.length; i < len; i++) {
				var oListItem = aItems[i].getBindingContext().getObject();

				//Compare last row above with current row and merge them in case of multi-accounting
				//Only one call per item should be made, independently from the accounting
				var bAlreadyCalled = false;
				if (i > 0) {
					var oLastTmpItem = aItems[i - 1].getBindingContext().getObject();
					if (oLastTmpItem.PurchaseOrder === oListItem.PurchaseOrder &&
						oLastTmpItem.PurchaseOrderItem === oListItem.PurchaseOrderItem &&
						oLastTmpItem.PurchasingInfoRecord === oListItem.PurchasingInfoRecord &&
						oLastTmpItem.PurchasingInfoRecordCategory === oListItem.PurchasingInfoRecordCategory &&
						oLastTmpItem.PurchasingOrganization === oListItem.PurchasingOrganization &&
						oLastTmpItem.Plant === oListItem.Plant) {
						bAlreadyCalled = true;
					}
				}

				//Items with Multi-Accounting will be only added once to call
				if (!bAlreadyCalled) {
					//add function import in batch group
					_that.getView().getModel().callFunction("/POItemCreateFromReference", {
						groupId: "CreateWithReference",
						urlParameters: {
							DraftUUID: _that.getView().getBindingContext().getObject().DraftUUID,
							PurchasingDocument: oListItem.PurchaseOrder,
							PurchasingDocumentItem: oListItem.PurchaseOrderItem,
							PurchasingInfoRecord: oListItem.PurchasingInfoRecord,
							PurchasingInfoRecordCategory: oListItem.PurchasingInfoRecordCategory,
							PurchasingOrganization: oListItem.PurchasingOrganization,
							Plant: oListItem.Plant
						},
						method: "POST"
					});
				}
			}

			//send batch, on success refresh ui/model
			_that.getView().getModel().submitChanges({
				success: function() {
					oInnerTable.removeSelections(true);
					_that.getOwnerComponent().getModel().read(_that.getView().getBindingContext().getPath(), {
						urlParameters: "$expand=to_Language%2cto_DocumentCurrency%2cto_Supplier%2cto_PurchasingGroup%2cto_CompanyCode%2cto_PurchasingOrganization%2cto_PaymentTerms%2cto_InvoicingParty%2cto_IncotermsVersion%2cto_IncotermsClassification%2cto_PurOrdSupplierAddressTP"
					});
					_that.extensionAPI.refresh(
						"airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--ItemsFacet::Table"
					);
					// _that.extensionAPI.refresh(
					// 	"airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--LimitItemsFacet::Table"
					// );
					
					_that._oDialog.setBusy(false);
					resolve();
				},
				error: function(oData) {
					var oError = (oData && oData.responseText) ? JSON.parse(oData.responseText) : "";
					var sErrorText;
					if ((oError && oError.error && oError.error.message) && (oError.error.message.value)) {
						sErrorText = oError.error.message.value;
					} else {
						sErrorText = oData.statusCode + " " + oData.statusText;
					}
					
					_that._oDialog.setBusy(false);
					reject(sErrorText);
				}
			});

		});

	},

	//Function to cancel adding ref items to po, closing create with ref dialog
	_cancelRefItemsToPO: function() {
		this._oDialog.close();
		this._oDialog.destroy();
	},

	//Handle selection change in PO create with ref item table
	_handleSelectionChangeInRefItems: function(oEvent) {
		var oListItem = oEvent.getParameter("listItem").getBindingContext().getObject();
		var bListItemSelected = oEvent.getParameter("selected");
		var oDialog = this.getParent().getParent().getParent();

		//Call changeSelectableOfItems to disable all checkboxes for items with another supplier
		this.getParent().getParent().getController()._changeSelectableOfItems(oListItem, bListItemSelected);

		var iSelectedItems = this.getSelectedItems().length;

		//Enable action button only in case at least one item is selected
		if (iSelectedItems > 0) {
			oDialog.getBeginButton().setEnabled(true);
		} else {
			oDialog.getBeginButton().setEnabled(false);
		}
	}

});