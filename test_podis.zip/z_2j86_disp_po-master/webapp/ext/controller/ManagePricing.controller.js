/*
 * Copyright (C) 2009-2017 SAP SE or an SAP affiliate company. All rights reserved.
 */
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], function (Controller, Filter, FilterOperator) {
    "use strict";

    return Controller.extend("airbus.ui.2j86.disp.po.ext.controller.ManagePricing", {

        /**
         * 
         * 
         */
        onInit: function () {

            var _that = this;

            this.getOwnerComponent().getModel().attachEvent("batchRequestCompleted",function () {
                var aFilter = [];
                var sPO = sap.ui.getCore().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--objectPageHeader").getTitleText();
                aFilter.push(new Filter("PONumber", FilterOperator.EQ, sPO));
                var oTable = _that.getView().byId("idPricingTable");
                oTable.bindRows({
                    path: "pricing>/ETPOPricingSet",
                    filters: aFilter
                });

            });

            // this.getOwnerComponent().getModel().attachBatchRequestCompleted(function (oEvent) {
            //     var aFilter = [];
            //     var sPO = sap.ui.getCore().byId("airbus.ui.2j86.disp.po::sap.suite.ui.generic.template.ObjectPage.view.Details::C_PurchaseOrderTP--objectPageHeader").getTitleText();
            //     aFilter.push(new Filter("PONumber", FilterOperator.EQ, sPO));
            //     var oTable = _that.getView().byId("idPricingTable");
            //     oTable.bindRows({
            //         path: "pricing>/ETPOPricingSet",
            //         filters: aFilter
            //     });

            // });

        },

        /**
		 * @function: onEditPricingInfo 
		 * @description: Change Editable state of Pricing Table Condition Fields 
		 * @CreatedBy : HJC
		 * @CreatedOn :19.11.2019 
		 * @US :DIGITPROP_BLM-319
         */
        onEditPricingInfo: function () {

            var oPricingStateModel = this.getView().getModel("pricingState");
            var bEditable = oPricingStateModel.getProperty("/state/editable");
            oPricingStateModel.setProperty("/state/editable", !bEditable);
        },

        /**
		 * @function: onPricingValueChange 
		 * @description: Restrict User input to length 12
		 * @CreatedBy : HJC 
		 * @CreatedOn :19.02.2019 
		 * @US :DIGITPROP_BLM-319
         */
        onPricingValueChange: function (oEvent) {
            var oSource = oEvent.getSource();
            var sValueLength = oSource.getValue().length;

            if (sValueLength > 12) {
                var sValue = oSource.getValue().substr(0, 12);
                oSource.setValue("");
                oSource.setValue(sValue);
            }

        },

        /**
		 * @function: onPriceChange 
		 * @description: Display Pricing input value with two Decimal Points
		 * @CreatedBy : HJC 
		 * @CreatedOn :19.11.2019 
		 * @US :DIGITPROP_BLM-319
         */
        onPriceChange: function (oEvent) {
            var sParseValue = "";
            var oSource = oEvent.getSource();

            if (oSource.getValue() === "") {
                oSource.setValue("0.00");
            }
            else {
                sParseValue = parseFloat(oSource.getValue()).toFixed(2);
                oSource.setValue(sParseValue);
            }
        },

        /**
		 * @function: onSavePricingInfo 
		 * @description: Save Pricing Info 
		 * @CreatedBy : HJC 
		 * @CreatedOn :19.11.2019 
		 * @US :DIGITPROP_BLM-319
         */
        onSavePricingInfo: function () {
            var that = this;
            var oModel = this.getView().getModel("pricing");
            if (oModel.hasPendingChanges()) {
                sap.ui.core.BusyIndicator.show();
                oModel.submitChanges({
                    success: function (oData, oResponse) {
                        sap.ui.core.BusyIndicator.hide();
                        that.getView().byId("idPricingTable").getBinding().refresh();
                        that.getView().getModel().refresh();
                        that._managePricingSave(oData, oResponse);
                    },
                    error: function () {
                        sap.ui.core.BusyIndicator.hide();
                    }
                });
            }
            else{
                sap.m.MessageToast.show("No Data Changed");
            }
        },


        /**
		 * @function: _managePricingSave 
		 * @description: Display Pricing Info Update message 
		 * @CreatedBy : HJC 
		 * @CreatedOn :20.11.2019 
		 * @US :DIGITPROP_BLM-319
         */
        _managePricingSave: function (oData) {
            var aMessages = [], oMessage, sMessage = "";
            var aChangeResponds =  oData.__batchResponses[0].__changeResponses;

            for(var i = 0; i < aChangeResponds.length; i++){               
                oMessage = this._retrieveMessages(aChangeResponds[i]);
                aMessages = oMessage ? aMessages.concat(oMessage) : aMessages;
            }

            for(var j = 0; j < aMessages.length; j++){
                if (sMessage === ""){
                    sMessage = aMessages[j].title;
                }
                else{
                    sMessage = sMessage + "\n" +aMessages[j].title;
                }
                
            }
            
            sap.m.MessageToast.show(sMessage, {duration: 6000});
        },

        /**
		 * @function: _retrieveMessages 
		 * @description: Retrieve Message from different Levels 
		 * @CreatedBy : HJC 
		 * @CreatedOn :21.11.2019 
		 * @US :DIGITPROP_BLM-319
         */

        _retrieveMessages: function (oChangesResp) {
            var oFirstLevel, aMessages = [], sDetailLength, i;
            var oMessage = {
                type: '',
                title: ''
            };
            try {
                oFirstLevel = JSON.parse(oChangesResp.headers["sap-message"]);
                    switch (oFirstLevel.severity) {
                        case 'error':
                            oMessage.type = 'Error';
                            break;
                        case 'info':
                            oMessage.type = 'Success';
                            break;

                        default:
                            oMessage.type = 'Information';
                            break;
                    }
                    oMessage.title = oFirstLevel.message;
                    aMessages = aMessages.concat(oMessage);
            } catch (e) {
                if (oChangesResp.message) {
                    switch (oChangesResp.severity) {
                        case 'error':
                            oMessage.type = 'Error';
                            break;
                        case 'info':
                            oMessage.type = 'Success';
                            break;

                        default:
                            oMessage.type = 'Information';
                            break;
                    }
                    oMessage.title = oChangesResp.message;
                    return oMessage;
                } else {
                    return;
                }
            }

            if (!oFirstLevel.details) {
                return aMessages;
            }
            sDetailLength = oFirstLevel.details.length;
            if (sDetailLength > -1) {
                for (i = 0; i < sDetailLength; i++) {
                    aMessages = aMessages.concat(this._retrieveMessages(oFirstLevel.details[i]));
                }
            }

            return aMessages;
        },

        onAfterRendering: function () {			
		
            var oDateTable = this.getView().byId("idPricingHBox");
            oDateTable.bindElement("pricing>/ETUserActionSet('myId')");
        }

    });
});