sap.ui.require([ "sap/ui/test/opaQunit" ], function(opaTest) {
  "use strict";

  QUnit.module("Testing Home page");

  opaTest("Check tile display", function(Given, When, Then) {
    Given.iStartMyAppInAFrame("../../index.html");
    // Then.onThePage.iShouldSeeTile("Home", "idTestTile");
  });
});