sap.ui.require(["sap/ui/test/opaQunit"], function (opaTest) {
  "use strict";

  QUnit.module("Test Create PO Tab");

  opaTest("Check Create PO Content Display", function (Given, When, Then) {
    Given.iStartMyAppInAFrame("../../index.html");
    Then.onThePage.iShouldSeeIconTabFilter("ManageProgram", "idManageCreatePOCDS", "Create PO");

    //Check Smart Table Display
    When.onThePage.iPressAnIconTabFilter("sap-icon://form", "Create PO");
    Then.onThePage.iShouldSeeSmartFilterBar("ManageProgram.ManageCreatePOCDS", "idSmartCreatePOCDS");
    Then.onThePage.iShouldSeeSmartTable("ManageProgram.ManageCreatePOCDS", "idSmartCreatePOTableCDS");

    Then.onThePage.iSeeButtonbyID("ManageProgram","idCreatePO","Create PO");

    //Check Information Bubble
    When.onThePage.iPressInformationButton("ManageProgram", "informationButtonPO");
    Then.onThePage.iShouldSeeInformation("ManageProgram", "informationButtonPO");
    When.onThePage.iPressAButtonWithIconAndText("", "OK");

    // Create PO Operation
    When.onThePage.iSelectSmartTableItem("ManageProgram.ManageCreatePOCDS", "idSmartCreatePOTableCDS");
    When.onThePage.iPressAButtonWithIconAndText("sap-icon://save","Create PO");
    Then.onThePage.iSeeButtonbyID("ManageProgram","idMessageCreatePO");
    Then.onThePage.iShouldSeeMessagePopOver("ManageProgram", "idPOCreationPopover");
    Then.onThePage.iSeeErrorSuccessMessagePopOver("ManageProgram", "idPOCreationPopover");
    // Then.onThePage.iCloseMessagePOPOver("ManageProgram", "idPOCreationPopover");
  })

  // opaTest("Check Filters", function(Given, When, Then) {
  //   Then.onThePage.iShouldSeeSmartFilterByKey("ManageProgram.ManageCreatePOCDS", "idSmartCreatePOCDS", "CAC");
  //   // Then.onThePage.iLoadFilterItemId("ManageProgram.ManageCreatePOCDS", "idSmartCreatePOCDS", "CAC");
  //   When.onThePage.inAFilterBarItemEnter("ManageProgram.ManageCreatePOCDS", sap.ui.test.Opa5.getContext().sFilterId , "90184");
  //   Then.onThePage.iShouldSeeSmartFilterByKey("ManageProgram.ManageCreatePOCDS", "idSmartCreatePOCDS", "Customer");

  //   //When.onThePage.inAControlIEnter("ManageIssue", "IDSARITitle", sap.ui.test.Opa5.getContext().GeneralText.Titre);
  //   //Then.onThePage.iShouldSeeIconTabFilter("ManageProgram", "idManageCreatePOCDS", "Create PO");
  // });


});