sap.ui.require([ "sap/ui/test/opaQunit" ], function(opaTest) {
  "use strict";

  QUnit.module("Testing GR Validation Page");

  opaTest("Check GR Validation Content display", function(Given, When, Then) {
    Given.iStartMyAppInAFrame("../../index.html");
    When.onThePage.iPressAnIconTabFilter("sap-icon://form", "GR Validation");
    Then.onThePage.iShouldSeeSmartFilterBar("ManageProgram.ManageGRvalidation", "idSmartGRVal");
    Then.onThePage.iShouldSeeSmartTable("ManageProgram.ManageGRvalidation","idSmartGRValTable");
    
    
    When.onThePage.iPressAnIconTabbyID("ManageProgram", "idManageGRVal");

    Then.onThePage.iSeeButtonbyID("ManageProgram","idGRValidation","Validate GR");

    //Check SmartTable and record count
    Then.onThePage.iSeeTableAndContent("ManageProgram.ManageGRvalidation","idSmartGRValTable");

    //Check PO Update Information Bubble
    When.onThePage.iPressInformationButton("ManageProgram","informationButtonGR");
    Then.onThePage.iShouldSeeInformation("ManageProgram","informationButtonGR");
    
    When.onThePage.iPressAButtonWithIconAndText("","OK");
    
    
    
  });
});