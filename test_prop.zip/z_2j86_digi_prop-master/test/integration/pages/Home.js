sap.ui.require([ "sap/ui/test/opaQunit" ], function(opaTest) {
  "use strict";

  QUnit.module("Testing Home page");

  opaTest("Check Main View and Tiles", function(Given, When, Then) {
    Given.iStartMyAppInAFrame("../../index.html");
    Then.onThePage.iCheckTheI18NText("title");
    Then.onThePage.iShouldSeeIconTabFilter("ManageProgram", "idMyOverviewCDS", "My Overview");
    Then.onThePage.iShouldSeeIconTabFilter("ManageProgram", "idManageCreatePOCDS", "Create PO");
    Then.onThePage.iShouldSeeIconTabFilter("ManageProgram", "idManagePOsched", "PO Scheduling");
    Then.onThePage.iShouldSeeIconTabFilter("ManageProgram", "idManageGRVal", "GR Validation");
	  Then.onThePage.iShouldSeeIconTabFilter("ManageProgram", "idIconTabFiltePOUpdate", "PO Conf Upd");
//	When.onThePage.iPressATile("A320");
	  When.onThePage.iPressAnIconTabFilter("sap-icon://form", "Create PO");
//	Then.onThePage.iShouldSeeSmartTable("ManageProgram://PoUpdate","idSmartPOUpdateTable");
	
  });
});