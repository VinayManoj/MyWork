sap.ui.require([ "sap/ui/test/opaQunit" ], function(opaTest) {
  "use strict";

  QUnit.module("Testing PO Scheduling Page");

  opaTest("Check PO Scheduling Content display", function(Given, When, Then) {
    Given.iStartMyAppInAFrame("../../index.html");
    When.onThePage.iPressAnIconTabFilter("sap-icon://form", "PO Scheduling");
    Then.onThePage.iShouldSeeSmartFilterBar("ManageProgram.ManagePOScheduling", "idSmartPOSchedule");
    Then.onThePage.iShouldSeeSmartTable("ManageProgram.ManagePOScheduling","idSmartPOScheduleTable");
    
    
    When.onThePage.iPressAnIconTabbyID("ManageProgram", "idManagePOsched");

    Then.onThePage.iSeeButtonbyID("ManageProgram","idPOSAlign","Align Dates");
    Then.onThePage.iSeeButtonbyID("ManageProgram","idSchedulePOSave","Save Comment");

    //Check SmartTable and record count
    Then.onThePage.iSeeTableAndContent("ManageProgram.ManagePOScheduling","idSmartPOScheduleTable");

    //Check PO Update Information Bubble
    When.onThePage.iPressInformationButton("ManageProgram","informationButtonPOS");
    Then.onThePage.iShouldSeeInformation("ManageProgram","informationButtonPOS");
    
    When.onThePage.iPressAButtonWithIconAndText("","OK");
    
    
    
  });
});