sap.ui.require([ "sap/ui/test/opaQunit" ], function(opaTest) {
    "use strict";
  
    QUnit.module("Testing PO Publication Page");
  
    opaTest("Check PO Publication Content display", function(Given, When, Then) {
      Given.iStartMyAppInAFrame("../../index.html");
        When.onThePage.iPressAnIconTabFilter("sap-icon://form", "PO Publication");
        Then.onThePage.iShouldSeeSmartFilterBar("ManageProgram.ManagePOPublice", "idSmartPOPublic");
      Then.onThePage.iShouldSeeSmartTable("ManageProgram.ManagePOPublice","idSmartPOPubliceTable");
      
      
      When.onThePage.iPressAnIconTabbyID("ManageProgram", "idManagePOPublice");

      Then.onThePage.iSeeButtonbyID("ManageProgram","idPOPublicPublication","PO Publication");
  
      //Check SmartTable and record count
      Then.onThePage.iSeeTableAndContent("ManageProgram.ManagePOPublice","idSmartPOPubliceTable");
  
      //Check PO Update Information Bubble
      When.onThePage.iPressInformationButton("ManageProgram","informationButtonPOP");
      Then.onThePage.iShouldSeeInformation("ManageProgram","informationButtonPOP");
      
      When.onThePage.iPressAButtonWithIconAndText("","OK");

      When.onThePage.iSelectSmartTableItem("ManageProgram.ManagePOPublice", "idSmartPOPubliceTable");
      When.onThePage.iPressAButtonWithIconAndText("sap-icon://outbox","PO Publication");
      
      
      
    });
  });