sap.ui.require([ "sap/ui/test/opaQunit" ], function(opaTest) {
  "use strict";

  QUnit.module("Testing PO Update Page");

  opaTest("Check PO Update Content display", function(Given, When, Then) {
    Given.iStartMyAppInAFrame("../../index.html");
  When.onThePage.iPressAnIconTabFilter("sap-icon://form", "PO Conf Upd");
  Then.onThePage.iShouldSeeSmartFilterBar("ManageProgram.POUpdate", "idSmartPOUpdate");
	Then.onThePage.iShouldSeeSmartTable("ManageProgram.POUpdate","idSmartPOUpdateTable");
//    When.onThePage.iPressACheckBox("ManageProgram", "idPOUpdate", false);
    
   
//    Then.onThePage.allCheckBoxShouldBeSelected();
	
	
	
	
    When.onThePage.iPressAnIconTabbyID("ManageProgram", "idIconTabFiltePOUpdate");

    //Check availability of Buttons for PO Update   
    // Then.onThePage.iSeeButtonbyID("ManageProgram","idMessageCreatePO");
    // Then.onThePage.iSeeButtonbyID("ManageProgram","idUpdatePOCreation","PO Creation");
    Then.onThePage.iSeeButtonbyID("ManageProgram","idUpdatePOUpdate","PO Update");
    Then.onThePage.iSeeButtonbyID("ManageProgram","idUpdatePODeletion","PO Deletion");

    //Check SmartTable and record count
    Then.onThePage.iSeeTableAndContent("ManageProgram.POUpdate","idSmartPOUpdateTable");

    //Check PO Update Information Bubble
    When.onThePage.iPressInformationButton("ManageProgram","informationButtonPOU");
    Then.onThePage.iShouldSeeInformation("ManageProgram","informationButtonPOU");
    When.onThePage.iPressAButtonWithIconAndText("","OK");
    // Then.iTeardownMyApp();   
    
    
    
  });
});