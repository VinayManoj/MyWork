sap.ui.require([ 'sap/ui/test/Opa5', 'sap/m/Token', 'sap/ui/test/matchers/AggregationLengthEquals', 'sap/ui/test/matchers/AggregationContainsPropertyEqual', 'sap/ui/test/matchers/AggregationFilled', 'sap/ui/test/matchers/Ancestor',
    'sap/ui/test/matchers/Properties', 'sap/ui/test/matchers/I18NText', 'sap/ui/test/matchers/BindingPath', 'sap/ui/test/actions/Press', 'sap/ui/test/actions/EnterText' ], function(Opa5, Token, AggregationLengthEquals,
    AggregationContainsPropertyEqual, AggregationFilled, Ancestor, Properties, I18NText, BindingPath, Press, EnterText) {
  "use strict";

  // Add configuration to test framework
  Opa5.extendConfig({
    viewNamespace : "airbus.ui.digital_propulsion.view.",
    autoWait : true,
    timeout : 15,
    pollingInterval : 100
  });

  // Creation of the test page
  Opa5.createPageObjects({
    onThePage : {
      /***************************************************************************************************************************************************************************************************************************************************
       * ************************************************* ACTION FUNCTIONS USED TO SIMULATE USER ACTION ON CONTROLS *********************************************
       **************************************************************************************************************************************************************************************************************************************************/
      actions : {
    	  
    	  /* Press a tile using its title */
			iPressATile : function(sTitle) {
				return this.waitFor({
					controlType : "sap.m.StandardTile",
					matchers : new Properties({
						title : sTitle
					}),
					actions : new Press(),
					errorMessage : "Did not find the " + sTitle + " entitled tile"
				});
			},
			/* Press on an icon tab filter*/
			iPressAnIconTabFilter : function(sIcon, sText) {
				if (typeof (sText) === "undefined") {
					return this.waitFor({
						controlType : "sap.m.IconTabFilter",
						matchers : new Properties({
							icon : sIcon
						}),
						actions : new Press(),
						errorMessage : "Did not find the IconTabFilter"
					});
				}
				else {
					return this.waitFor({
						controlType : "sap.m.IconTabFilter",
						matchers : new Properties({
							icon : sIcon,
							text : sText
						}),
						actions : new Press(),
						errorMessage : "Did not find the IconTabFilter"
					});
				}
			},
			
//			
    	  
    	  
    	  
        /* Press on a control using its ID */
        iPressAControlWithID : function(sView, sId) {
          return this.waitFor({
            viewName : sView,
            id : sId,
            action : new Press(),
            errorMessage : "Did not find the " + sId + " control"
          });
        },

        /* Press on a checkbox using its ID */
        iPressACheckBox : function(sView, sId, sBool) {
          return this.waitFor({
            viewName : sView,
            controlType : "sap.m.CheckBox",
            id : sId,
            success : function(oCheckBox) {
              oCheckBox.setSelected(sBool);
            },
            errorMessage : "Did not find the " + sId + " checkbox"
          });
        },

        /* Enter text in a control using its ID */
        inAControlIEnter : function(sView, sId, sText) {
          return this.waitFor({
            viewName : sView,
            id : sId,
            actions : new EnterText({
              clearTextFirst : true,
              text : sText
            }),
            errorMessage : "Did not find the " + sId + " control"
          });
        },

        /* Enter text in a control using its ID */
        iChangeASwitch : function(sView, sId, bPosition) {
          return this.waitFor({
            viewName : sView,
            controlType : "sap.m.Switch",
            id : sId,
            success : function(oSwitch) {
              if (oSwitch.getState() != bPosition) {
                oSwitch.setState(bPosition);
                oSwitch.fireChange();
              }
            },
            errorMessage : "Did not find the " + sId + " switch"
          });
        },

        // Press a button which has a specified icon
        iPressAButtonWithIconAndText : function(sIcon, sText) {
          return this.waitFor({
            controlType : "sap.m.Button",
            matchers : new Properties({
              icon : sIcon,
              text : sText
            }),
            actions : new Press(),
            errorMessage : "The button with " + sIcon + " icon and " + sText + " text could not be found"
          });
        },

        /* Press an Icon Tab Filter - Second parameter not mandatory */
				iPressAnIconTabFilter : function(sIcon, sText) {
					if (typeof (sText) === "undefined") {
						return this.waitFor({
							controlType : "sap.m.IconTabFilter",
							matchers : new Properties({
								icon : sIcon
							}),
							actions : new Press(),
							errorMessage : "Did not find the IconTabFilter"
						});
					}
					else {
						return this.waitFor({
							controlType : "sap.m.IconTabFilter",
							matchers : new Properties({
								icon : sIcon,
								text : sText
							}),
							actions : new Press(),
							errorMessage : "Did not find the IconTabFilter"
						});
					}
        },
        
        /* Enter Value in Smart FilterBar Item */
        inAFilterBarItemEnter: function (sView, sId, sText) {
          return this.waitFor({
            viewName: sView,
            id: sId,
            actions: new EnterText({
              clearTextFirst : true,
              text : sText
            }),
            errorMessage: "Did not find the " + sId + " control"
          });
        },
        // Press Information Button
        iPressInformationButton: function (sView, sID) {
					return this.waitFor({
						id: sID,
						viewName: sView,
						actions: new Press(),
						errorMessage: "Did not find the " + sID +" button related to view" + sView
					});
        },
        
        // Press an Icon tab with specific id
        iPressAnIconTabbyID : function(sView, sID) {
          return this.waitFor({
            controlType : "sap.m.IconTabFilter",
            id: sID,
						viewName: sView,
						actions: new Press(),
            errorMessage : "The Icon tab with ID" + sID + " could not be found"
          });
        },

        // Select Line Item of Smart Table
        iSelectSmartTableItem : function(sView, sId){
          return this.waitFor({
            controlType: "sap.ui.comp.smarttable.SmartTable",
            viewName: sView,
            id: sId,
            actions : function(oItem){
              oItem.getTable().setSelectedIndex(0);
            },
            success: function (oFilter) {
              Opa5.assert.ok(true, "The Line Selected");
            },
            errorMessage: "Error"
          });
        }


        
     },

      /***************************************************************************************************************************************************************************************************************************************************
       * *************************************** ACTION FUNCTIONS USED TO CHECK CONTROLS PROPERTY AND SAVE DATA IN OPA CONTEXT ***********************************
       **************************************************************************************************************************************************************************************************************************************************/
      assertions : {
        /* Check the display of a Tile */
        iShouldSeeTile : function(sView, sId) {
          return this.waitFor({
            // controlType : "sap.m.StandardTile",
            // matchers : new Properties({
            // title : sTitle
            // }),

            viewName : sView,
            id : sId,
            success : function() {
              Opa5.assert.ok(true, "The " + sId + " tile is displayed");
            },
            errorMessage : "The " + sId + " tile is not displayed"
          });
        },
        
        /* Check the display of a SmartTable */
		iShouldSeeSmartTable : function(sView, sId) {
			return this.waitFor({
				controlType : "sap.ui.comp.smarttable.SmartTable",
				viewName : sView,
				id : sId,
				success : function() {
					Opa5.assert.ok(true, "The smartTable with ' " + sId + " ' as id is displayed");
				},
				errorMessage : "The samrtTable with ' " + sId + " ' as id is not displayed"
			});
		},
		
        /* Check the display of an IconTabFilter */
        iShouldSeeIconTabFilter : function(sView, sId, sText) {
          return this.waitFor({
            controlType : "sap.m.IconTabFilter",        
            matchers : new Properties({
                 text : sText
            }),
            viewName : sView,
            id : sId,
            success : function() {
              Opa5.assert.ok(true, "The " + sId + " iconTabFilter is displayed with the good text");
            },
            errorMessage : "The " + sId + " iconTabFilter is not displayed with the good text"
          });
        },

        // Checks if a control as the specified text
        iCheckControlText : function(sView, sId, sText) {
          return this.waitFor({
            viewName : sView,
            id : sId,
            matchers : new Properties({
              text : sText,
            }),
            success : function() {
              Opa5.assert.ok(true, "The " + sId + " control is filled with " + sText);
            },
            errorMessage : "The " + sId + " control is not filled with " + sText
          });
        },

        // Checks page's title
        iCheckPageTitle : function(sText) {
          return this.waitFor({
            controlType : "sap.m.Page",
            matchers : new Properties({
              title : sText,
            }),
            success : function() {
              Opa5.assert.ok(true, "The " + sText + " page has been found");
            },
            errorMessage : "The " + sText + " page could not been found"
          });
        },

        iCheckDisplayedInformation : function(sText) {
          return this.waitFor({
            controlType : "sap.m.Text",
            matchers : new Properties({
              text : sText,
            }),
            success : function() {
              Opa5.assert.ok(true, "The " + sText + " text has been found");
            },
            errorMessage : "The " + sText + " text has not been found"
          });
        },

        // Check that checkbox are all (de)selected
        allCheckBoxShouldBeSelected : function(sView, sId, bSelected) {
          return this.waitFor({
            viewName : sView,
            id : sId,
            matchers : function(oControl) {
              if (oControl.getSelected() != bSelected) {
                return false;
              } else {
                return true;
              }
            },
            success : function() {
              Opa5.assert.ok(true, "The control has selected property set to " + bSelected);
            },
            errorMessage : "The control doesn't have selected property set to " + bSelected
          });
        },

        /* Check the display of a control using its ID */
        iCheckControlDisplayWithId : function(sView, sId, bVisible) {
          return this.waitFor({
            viewName : sView,
            id : sId,
            visible : false,
            matchers : new Properties({
              visible : bVisible,
            }),
            success : function() {
              Opa5.assert.ok(true, "The " + sId + " control is displayed");
            },
            errorMessage : "The " + sId + " control is not displayed"
          });
        },

        /* Check text value of a control */
        iCheckValue : function(sView, sId, sText) {
          return this.waitFor({
            viewName : sView,
            id : sId,
            matchers : new Properties({
              value : new RegExp(sText),
            }),
            success : function(aTitle) {
              Opa5.assert.ok(true, "The '" + sText + "' message is displayed");
            },
            errorMessage : "The " + sText + "  is not displayed"
          });
        },

        /* Check the enable property of a control using its ID */
        iCheckEnabledProperty : function(sId, bEnabled) {
          return this.waitFor({
            id : new RegExp(sId + "$"),
            visible : false,
            matchers : function(oControl) {
              return oControl.getEnabled() == bEnabled;
            },
            success : function() {
              Opa5.assert.ok(true, "The " + sId + " control has enabled property set to " + bEnabled);
            },
            errorMessage : "The " + sId + " control doesn't have enabled property set to " + bEnabled
          });
        },

        /* Check dialog display */
        iShouldSeeDialog : function(sText) {
          return this.waitFor({
            controlType : "sap.m.Dialog",
            matchers : new Properties({
              title : sText,
            }),
            success : function(aTitle) {
              Opa5.assert.ok(true, "The " + sText + " entitled dialog is displayed");
            },
            errorMessage : "The " + sText + " entitled dialog is not displayed"
          });
        },

        /* Check binding path */
        iCheckBindingPath : function(sControl, sPath) {
          return this.waitFor({
            controlType : sControl,
            matchers : new BindingPath({
              path : sPath,
            }),
            success : function(aTitle) {
              Opa5.assert.ok(true, "The " + sControl + " control is binded with " + sPath);
            },
            errorMessage : "The " + sControl + " control is not binded with " + sPath
          });
        },
        
        /* Check the I18N properties */
        iCheckTheI18NText: function(sI18NText){
        	return this.waitFor({
        		controlType : "sap.m.Title",
        		matchers : new I18NText({
        			propertyName : "text",
        			key: sI18NText
        		}),
        		success : function(){
        			Opa5.assert.ok(true, "The Title with i18N property " + sI18NText + " is well displayed");
        		},
        	errorMessage: "The Title " + sI18NText + " is not well displayed"
        	});
        },

        /* Check the display of a control using its ID */
				iShouldSeeAControlWithID : function(sView, sId) {
					return this.waitFor({
						viewName : sView,
						id : sId,
						success : function() {
							Opa5.assert.ok(true, "The control with ' " + sId + " ' as ID is displayed");
						},
						errorMessage : "The control with ' " + sId + " ' as ID is not displayed"
					});
        },
        
        /* Check the display of a SmartFilterBar */
				iShouldSeeSmartFilterBar : function(sView, sId) {
					return this.waitFor({
						controlType : "sap.ui.comp.smartfilterbar.SmartFilterBar",
						viewName : sView,
						id : sId,
						success : function() {
							Opa5.assert.ok(true, "The smartFilterBar with ' " + sId + " ' as id is displayed");
						},
						errorMessage : "The samrtFilterBar with ' " + sId + " ' as id is not displayed"
					});
        },
        
        /* Check the display of a SmartTable */
				iShouldSeeSmartTable : function(sView, sId) {
					return this.waitFor({
						controlType : "sap.ui.comp.smarttable.SmartTable",
						viewName : sView,
						id : sId,
						success : function() {
							Opa5.assert.ok(true, "The smartTable with ' " + sId + " ' as id is displayed");
						},
						errorMessage : "The samrtTable with ' " + sId + " ' as id is not displayed"
					});
        },
        
        /*I should see the SmartFilter key  */
        iShouldSeeSmartFilterByKey: function (sView, sId, sKey) {
          return this.waitFor({
            controlType: "sap.ui.comp.smartfilterbar.SmartFilterBar",
            viewName: sView,
            id: sId,
            matchers: function (oFilter) {
              var aFilters = oFilter.getContent()[1].getContent();
              var aFilterNames = [];

              for (var i=1; i < aFilters.length; i++){
                aFilterNames.push(aFilters[i].getContent()[0].getText());
              }

              
              if (aFilterNames.indexOf(sKey) > -1) {
              var iIndex = aFilterNames.indexOf(sKey) + 1;
              sap.ui.test.Opa5.getContext().sFilterId = aFilters[iIndex].getContent()[1].getId();
                return true;
              }
              else {
                return false;
              }
            },
            success: function (oFilter) {
              Opa5.assert.ok(true, "The FilterBar control key ' " + sKey + " ' is displayed");
            },
            errorMessage: "The FilterBar control key ' " + sKey + " ' is not displayed"
          });
        },

        /* Save Smart FilterBar Item Id */
        iLoadFilterItemId: function (sView, sId, sKey) {
          return this.waitFor({
            viewName: sView,
            id: sId,
            success: function (oFilter) {
              var aFilters = oFilter.getContent()[1].getContent();
              var aFilterNames = [];

              for (var i=1; i < aFilters.length; i++){
                aFilterNames.push(aFilters[i].getContent()[0].getText());
              }
              
              var iIndex = aFilterNames.indexOf(sKey) + 1;
              sap.ui.test.Opa5.getContext().sFilterId = aFilters[iIndex].getContent()[1].getId();
            },
            errorMessage: "Did not find the " + sId + " control"
          });
        },

        //Check the Information Dialog
        iShouldSeeInformation: function (sView, sId) {
					return this.waitFor({
						controlType: "sap.m.Dialog",
						success: function () {
							// we set the view busy, so we need to query the parent of the app
							Opa5.assert.ok(true, "The Information dialog is working fine");
						},
						errorMessage: "Did not find the Information dialog"
          });
          
        },

        // Check the display of given Button by ID 
        iSeeButtonbyID : function(sView, sId, sText) {
          var msg;
          if (sText)
              msg = "The button with ID " + sId + " is not displayed with the good text"
            else
              msg = "The button with ID " + sId + " is not displayed"
          return this.waitFor({
            controlType : "sap.m.IconTabFilter",        
            viewName : sView,
            id : sId,
            success : function() {
              if (sText)
                Opa5.assert.ok(true, "The button with ID " + sId + " is well displayed with the good text");
              else
              Opa5.assert.ok(true, "The button with ID " + sId + " is well displayed");
            },
              errorMessage : msg
          });
        },

        //Check Smart Table
        iSeeTableAndContent: function (sView, sId) {
          return this.waitFor({
            controlType: "sap.ui.comp.smarttable.SmartTable",
            viewName: sView,
            id: sId,
            success: function () {
              Opa5.assert.ok(true, "The Smart Table " + sId + " is visible");
            },
            errorMessage: "The Smart Table " + sId + " is not visible"
          });
        },

        /* Check Message Popover display */
        iShouldSeeMessagePopOver: function (sView,sId) {
          return this.waitFor({
            controlType: "sap.m.MessagePopover",
            viewName: sView,
            matchers: new Properties({
              id: sId,
            }),
            success: function (aTitle) {
              Opa5.assert.ok(true, "The " + sId + " entitled Message Popover is displayed");
            },
            errorMessage: "The " + sId + " entitled Message Popover is not displayed"
          });
        },
        
        // Check Errors and Success in the POPOver
        iSeeErrorSuccessMessagePopOver: function (sView,sId) {
          
          return this.waitFor({
            controlType: "sap.m.MessagePopover",
            viewName: sView,
            matchers: function(oPopover){
              return true;
            },
            success: function (oPopover) {
              var aItems = oPopover[0].getItems();
              var iSuccess=0; var iError=0;

              for (var i=0; i < aItems.length ; i++){
                var sType = aItems[i].getType();
                if (sType === "Error"){
                  iError = iError + 1;
                }
                else{
                  iSuccess = iSuccess + 1;
                }
              }
              iSuccess = iSuccess.toString();
              iError = iError.toString();
              oPopover[0].close();
              Opa5.assert.ok(true, "Operation Successful for "+ iSuccess + " items and failed for " + iError +" items");
            },
            errorMessage: "The " + sId + " entitled Message Popover is not displayed"
          });
        }

      
      }
    },
  });
});