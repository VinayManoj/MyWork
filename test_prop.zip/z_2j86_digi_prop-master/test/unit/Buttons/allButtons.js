sap.ui.require([ "sap/ui/test/opaQunit" ], function(opaTest) {
    "use strict";

    QUnit.module("Check all available Buttons per Icon Tab");
  
    opaTest("Overview", function(Given, When, Then) {
      Given.iStartMyAppInAFrame("../../index.html");
      
      //Navigate to Icon Tab 'My Overview'
      When.onThePage.iPressAnIconTabbyID("ManageProgram", "idMyOverviewCDS");
      //Check availability of Buttons for My Overview 
      Then.onThePage.iSeeButtonbyID("ManageProgram","idMessageCreatePO");
      
    });

    opaTest("Create PO", function(Given, When, Then) {
        
      //Navigate to Icon Tab 'Create PO'
      When.onThePage.iPressAnIconTabbyID("ManageProgram", "idManageCreatePOCDS");
      //Check availability of Buttons for Create PO
      Then.onThePage.iSeeButtonbyID("ManageProgram","idMessageCreatePO");
      Then.onThePage.iSeeButtonbyID("ManageProgram","idCreatePO","Create PO");
      
    });
    
    opaTest("PO Update", function(Given, When, Then) {

      //Navigate to Icon Tab 'PO Update'
      When.onThePage.iPressAnIconTabbyID("ManageProgram", "idIconTabFiltePOUpdate")
      //Check availability of Buttons for PO Update   
      Then.onThePage.iSeeButtonbyID("ManageProgram","idMessageCreatePO");
      Then.onThePage.iSeeButtonbyID("ManageProgram","idUpdatePOCreation","PO Creation");
      Then.onThePage.iSeeButtonbyID("ManageProgram","idUpdatePOUpdate","PO Update");
      Then.onThePage.iSeeButtonbyID("ManageProgram","idUpdatePODeletion","PO Deletion");
      
    });

    opaTest("PO Scheduling", function(Given, When, Then) {

      //Navigate to Icon Tab 'PO Scheduling'
      When.onThePage.iPressAnIconTabbyID("ManageProgram", "idManagePOsched")
      //Check availability of Buttons for PO Scheduling 
      Then.onThePage.iSeeButtonbyID("ManageProgram","idMessageCreatePO");
      Then.onThePage.iSeeButtonbyID("ManageProgram","idPOSAlign","Align Dates");
      Then.onThePage.iSeeButtonbyID("ManageProgram","idSchedulePOSave","Save Comment");
      
    });

    opaTest("GR Validation", function(Given, When, Then) {

      //Navigate to Icon Tab 'GR Validation'
      When.onThePage.iPressAnIconTabbyID("ManageProgram", "idManageGRVal")
      //Check availability of Buttons for GR Validation 
      Then.onThePage.iSeeButtonbyID("ManageProgram","idMessageCreatePO");
      Then.onThePage.iSeeButtonbyID("ManageProgram","idGRValidation","Validate GR");
     
    });
    
    opaTest("PO Publication", function(Given, When, Then) {

      //Navigate to Icon Tab 'PO Publication'
      When.onThePage.iPressAnIconTabbyID("ManageProgram", "idManagePOPublice")
      //Check availability of Buttons for PO Publication
      Then.onThePage.iSeeButtonbyID("ManageProgram","idMessageCreatePO");
      Then.onThePage.iSeeButtonbyID("ManageProgram","idPOPublicPublication","PO Publication");

      Then.iTeardownMyApp();   
    });
  });
