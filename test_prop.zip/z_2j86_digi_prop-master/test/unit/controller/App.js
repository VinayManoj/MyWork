sap.ui.require([ "sap/ui/model/json/JSONModel", "sap/ui/model/resource/ResourceModel", "sap/ui/thirdparty/sinon", "sap/ui/thirdparty/sinon-qunit" ],
function(JSONModel, ResourceModel) {

  // Declare the tested file as a variable in order to use it in QUnit tests
  var appController = airbus.ui.yourapplication.controller.App;

  
//  QUnit.module("Your module name", {
//
//  });
//
//  QUnit.test("Your function name", function(assert) {
//
//  });
});