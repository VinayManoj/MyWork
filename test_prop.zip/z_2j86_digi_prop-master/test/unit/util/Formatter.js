sap.ui.require([ "sap/ui/model/json/JSONModel", "sap/ui/model/resource/ResourceModel" ], function(JSONModel, ResourceModel) {

  // Declare the tested file as a variable in order to use it in QUnit tests
  var templateFormatter = airbus.ui.yourapplication.util.Formatter;

  // Try to create as many module as main function topic (text, date, icon,etc...)

  // Give your test module a name to understand easily the kind of function are tested inside
  QUnit.module("Test module for visible/enable property", {

  });

  QUnit.test("Set home tile enable", function(assert) {
    assert.strictEqual(templateFormatter.setHomeTileEnable(2), "Loaded", "Value 2 should return 'Loaded'");
    assert.strictEqual(templateFormatter.setHomeTileEnable(true), "Disabled", "True should return 'Disabled'");
  });

  QUnit.module("Test module for date function", {

  });

  QUnit.test("Set date time", function(assert) {
    var testDate = new Date();
    assert.strictEqual(templateFormatter.setDateTime(testDate), "0 seconds ago", "Should return a difference of 0 second");
    assert.strictEqual(templateFormatter.setDateTime(new Date(testDate.getTime() - 60000)), "1 minute(s) ago", "Should return 1 minute(s) ago'");
  });

  // Testing a function using a stub to specify a new getModel method
  QUnit.test("Name of your function", function(assert) {

    // Create a local model and bind it to the tested function
    var oAuditModel = new JSONModel();
    var oViewStub = {
      getModel : this.stub().withArgs("Model").returns(oAuditModel)
    };
    var fnSetIconEnable = templateFormatter.setIconEnable.bind(oViewStub);

    // Set model data
    oAuditModel.setData({
      "Status" : "Draft"
    });
    assert.strictEqual(fnSetIconEnable("Test"), true, "Enter Test with Initial audit should return true");
    assert.strictEqual(fnSetIconEnable(""), false, "Enter nothing with Initial audit should return true");

    oAuditModel.setData({
      "Status" : "Initial"
    });
    assert.strictEqual(fnSetIconEnable("Test"), true, "Enter Test with Draft audit should return true");
    assert.strictEqual(fnSetIconEnable(""), true, "Enter nothing with Draft audit should return true");

    oAuditModel.destroy();
  });
});