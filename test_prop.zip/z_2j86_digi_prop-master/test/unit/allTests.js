// Use this file to load the tests files that you wrote
sap.ui.define([ "test/unit/Buttons/allButtons" ], function() {
});
