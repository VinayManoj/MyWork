sap.ui.define(["sap/ui/core/UIComponent", "sap/ui/Device"], function (UIComponent, Device) {
	"use strict";

	return UIComponent.extend("airbus.ui.digital_propulsion.Component", {

		metadata: {
			manifest: "json",
			config: { fullWidth: true }
		},

		/**
		 * The component is initialized by UI5 automatically during the startup
		 * of the app and calls the init method once.
		 * 
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			// var oRouter = this.getRouter();
			// if (oRouter) {
			// 	oRouter.initialize();
			// }

			// deprecated after version 1.58 => sap/base/util/ObjectPath
			jQuery.sap.getObject("airbus.ui.digital_propulsion.GLOBAL", 0);
			// initialize aircraft value in global variable
			if (!this.getComponentData()) {
				//localhost => A320
				jQuery.sap.setObject("airbus.ui.digital_propulsion.GLOBAL.Aircraft", "A320");
			} else {
				// connected to the fiori launchpad in DFU
				var sACType = this.getComponentData().startupParameters.Aircraft[0];
				jQuery.sap.setObject("airbus.ui.digital_propulsion.GLOBAL.Aircraft", this.getComponentData().startupParameters.Aircraft[0]);
				// Change dynamically title of the App (depending on the
				// Aircraft
				// Type)
				this.getService("ShellUIService").then(
					// promise is returned
					function (oService) {
						oService.setTitle(sACType);
						// oService.setTitle(airbus.ui.digital_propulsion.GLOBAL.Aircraft);
					}, function (oError) {
						// in this case let initial title defined in i18n files
					});
			}

			// Initialize userData model
			var oDefaultModel = new sap.ui.model.json.JSONModel();
			this.setModel(oDefaultModel, "default");

			// Initialize Date Filter Model
			var oDateModel = new sap.ui.model.json.JSONModel();
			this.setModel(oDateModel, "date");

			var sProgram = "";

			var sSelectedProgram = jQuery.sap.getObject("airbus.ui.digital_propulsion.GLOBAL.Aircraft");
			switch (sSelectedProgram) {
				case "A320":
					sProgram = "N";
					break;
				case "A330":
					sProgram = "L";
					break;
				case "A350":
					sProgram = "P";
					break;
				case "A380":
					sProgram = "R";
					break;
				default:
					break;
			}

			var oModel = this.getModel("digital");
			var aFilters = [];
			var oFilter = new sap.ui.model.Filter("Zprogram", sap.ui.model.FilterOperator.EQ, sProgram);
			aFilters.push(oFilter);
			oModel.read("/ETDefaultSelectionSet", {
				filters: aFilters,
				success: this._readDefaultSelectionSuccess.bind(this),
				error: this._readDefaultSelectionError.bind(this)
			});


			oModel.read("/ETUserActionSet('myId')", {

				success: this._manageRoleSuccess.bind(this),
				error: this._manageRoleError.bind(this)
			});


			// Set Deferred Groups and Change Groups for oData Model
			// for every batch request when submitting data to SAP backend 
			// we will specify which changes group has to be sent, in order to avoid sending data 
			// that has not to be sent when calling method submitChanges of oData model
			oModel.setDeferredGroups(["POCreation", "GRValidation", "POSchedule", "POUpdate", "POPublish", "GRCancellation", "POCancel"]);
			oModel.setChangeGroups({
				"ETPossiblePO": {
					groupId: "POCreation",
					changeSetId: "POCreation",
					single: false
				},
				"ETGRValidation": {
					groupId: "GRValidation",
					changeSetId: "GRValidation",
					single: false
				},
				"ETPOScheduling": {
					groupId: "POSchedule",
					changeSetId: "POSchedule",
					single: false
				},
				"ETPOUpdate": {
					groupId: "POUpdate",
					changeSetId: "POUpdate",
					single: false
				},
				"ETPOPublish": {
					groupId: "POPublish",
					changeSetId: "POPublish",
					single: false
				},
				"ETGRCancallation": {
					groupId: "GRCancellation",
					changeSetId: "GRCancellation",
					single: false
				},
				"ETPOCancel": {
					groupId: "POCancel",
					changeSetId: "POCancel",
					single: false
				}
			});

		},

		_readDefaultSelectionSuccess: function (data) {
			var oDefaultModel = this.getModel("default");
			var aPlant = [];
			var aSalesorg = [];
			var aDivision = [];
			var aDischannel = [];
			var aPurorg = [];
			if (data.results) {
				var aModelData = data.results;
				for (var i = 0; i < aModelData.length; i++) {
					aPlant.push(aModelData[i].Plant);
					aSalesorg.push(aModelData[i].Salesorg);
					aDivision.push(aModelData[i].Division);
					aDischannel.push(aModelData[i].Dischannel);
					aPurorg.push(aModelData[i].Purorg);
				}
				oDefaultModel.setProperty("/plant", aPlant);
				oDefaultModel.setProperty("/Salesorg", aSalesorg);
				oDefaultModel.setProperty("/Division", aDivision);
				oDefaultModel.setProperty("/Dischannel", aDischannel);
				oDefaultModel.setProperty("/Purorg", aPurorg);
			}

		},

		_readDefaultSelectionError: function () {
			sap.m.MessageToast.show("Error raised");
		},



		_manageRoleSuccess: function (oData) {
			var oRoleModel = this.getModel("role");
			oRoleModel.setProperty("/Overview", oData.bOverview);
			oRoleModel.setProperty("/POCreation", oData.bCreatePO);
			oRoleModel.setProperty("/POUpdate", oData.bPOUpdate);
			oRoleModel.setProperty("/GRValidation", oData.bGRValidate);
			oRoleModel.setProperty("/POScheduling", oData.bPOSchedule);
			oRoleModel.setProperty("/POPublication", oData.bPOPublish);
			oRoleModel.setProperty("/GRCancelation", oData.bGRCancel);
			oRoleModel.setProperty("/POCancel", oData.bPOCancel);

			var oRouter = this.getRouter();
			if (oRouter) {
				oRouter.initialize();
			}

			var oActionTypeModel = this.getModel("actionType");
			for(var sProperty in oRoleModel.getData()){
				if(oRoleModel.getProperty("/" + sProperty)){
					oActionTypeModel.setProperty("/iconTabBar/0/" + sProperty , true);
					break;
				}
			}

		},


		_manageRoleError: function () {
			sap.m.MessageToast.show("Error raised");
		}
	});

});