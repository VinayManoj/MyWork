/*******************************************************************************
 * Project : Digital Propulsion Module : Functional document : ... Technical
 * document : ...
 * -------------------------------------------------------------------------------------------------------------------------------------
 * File name : ManageGRvalidation.controller.js Written by : SOPARA Team Company :
 * Sopra Steria Creation date : 04.02.2019
 * --------------------------------------------------------------------------------------------------------------------------------------
 * File description : This controller contains the functions that are supposed
 * to be called inside several screens in the application
 * --------------------------------------------------------------------------------------------------------------------------------------
 * Last modification date : Author : Description : Transport order :
 ******************************************************************************/

sap.ui.define(["airbus/ui/digital_propulsion/controller/ManageProgram.controller", 'sap/ui/model/Sorter', 'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator', "sap/m/MessageBox",
	"airbus/ui/digital_propulsion/util/Formatter", "sap/m/MessageToast"
], function (ManageProgram, Sorter, Filter, FilterOperator, MessageBox, Formatter, MessageToast) {
	"use strict";

	return ManageProgram.extend("airbus.ui.digital_propulsion.controller.ManageProgram.ManagePOCancel", {

		formatter: Formatter,

		onInit: function () {

			var oView = this.getView();
			var oModel = this.getOwnerComponent().getModel("digital");

			oView.setModel(oModel);

			this.oProgramController = jQuery.sap.getObject("airbus.global.digital.ManageProgram");

			// MessageManager initialization and set errorMessage model
			var oMessageManager = sap.ui.getCore().getMessageManager();
			this.getView().setModel(oMessageManager.getMessageModel(), "errorMsgModel");
			// activate automatic message generation for complete view
			oMessageManager.registerObject(this.getView(), true);
		},

		/**
		 * @function: onBeforeBind
		 * @description: Before the binding of smart Table happen
		 * @HJC on 04.02.2019 for US
		 */
		onBeforeBind: function (oEvent) {
			var oACModel = this.getView().getModel("aircraft");
			var sAircraft = "";

			var mBindingParams = oEvent.getParameter("bindingParams");


			var sSelectedProgram = jQuery.sap.getObject("airbus.ui.digital_propulsion.GLOBAL.Aircraft");
			switch (sSelectedProgram) {
			case "A320":
				sAircraft = oACModel.getProperty("/Type/A320"); // "N"
				break;
			case "A330":
				sAircraft = oACModel.getProperty("/Type/A330"); // "L"
				break;
			case "A350":
				sAircraft = oACModel.getProperty("/Type/A350"); // "P"
				break;
			case "A380":
				sAircraft = oACModel.getProperty("/Type/A380"); // "R"
				break;
			default:
				break;
			}
			

			mBindingParams.filters.push(new Filter({
				path: "Zprogram",
				operator: FilterOperator.EQ,
				value1: sAircraft
			}));

			
		},

		/*
		 * @function: onRowSelect @description: When selecting a row of GR
		 * smarttable @CreatedBy : KSD @CreatedOn : 14.02.2019 @US:
		 * DIGITPROP_BLM-59
		 */
		onRowSelect: function onRowSelect(oEvent) {

		},


		/**
		 * @SSH for US DP 338 on 10.10.2019
		 * 
		 * @function: onClearGRVFilter
		 * @description: Clear custom filters and variant on click of 'Clear'.
		 * @param: 
		 */
		onClearPOCnFilter: function (oEvent) {
			//Custom filter clearance
			// this.getView().byId("idGRPublicationstatus").setSelectedKey("");

			//Variant de-selection
			// this.getView().byId("idSmartGRVal").clearVariantSelection();
		},

		/**
		 * @SSH for US BLM 307 on 10.010.2019
		 * 
		 * @function: onGRVVariantLoad
		 * @description: Manage Custom fields when Varient is Loaded
		 * @param: 
		 */

		onPOCnVariantLoad: function (oEvent) {
			// var oSource = oEvent.getSource();
			// var oCustomData = oSource.getFilterData(true)["_CUSTOM"];
			// if (oCustomData) {
			// 	this.getView().byId("idGRPublicationstatus").setSelectedKey(oCustomData.Publicationstatus);
			// } else {
			// 	this.getView().byId("idGRPublicationstatus").setSelectedKey("0");
			// }
		},

		/**
		 * @SSH for US BLM 307 on 10.10.2019
		 * 
		 * @function: onGRVVariantSave
		 * @description: Manage Custom fields when Varient is Saved
		 * @param: 
		 */

		onPOCnVariantSave: function (oEvent) {
			// var oSource = oEvent.getSource();
			// var sPubStat = this.getView().byId("idGRPublicationstatus").getSelectedKey();
			// oSource.setFilterData({
			// 	_CUSTOM: {
			// 		Publicationstatus: sPubStat
			// 	}
			// });
		},

		/**
		 * 
		 * 
		 * 
		 */
		onAfterRendering: function () {
			var oFilterBar = this.getView().byId("idSmartPOCancelFilter");
			var aGroupItems = oFilterBar.getFilterGroupItems();

			for (var i = 0; i < aGroupItems.length; i++) {

				if (aGroupItems[i].getName() === "Material" || aGroupItems[i].getName() === "Materialdescription") {
					var oControl = aGroupItems[i].getControl();
					oControl.attachEvent("valueHelpRequest", function () {
						setTimeout(function () {
							var sControlName = oControl.getId().slice(oControl.getId().lastIndexOf("-") + 1);
							var sNewControlName, oTable;
							if (sControlName === "Material") {
								sNewControlName = "Materialdescription";
							} else {
								sNewControlName = "Material";
							}

							var sValueHelpId = oControl.getId() + "-valueHelpDialog";
							if (sap.ui.getCore().byId(sValueHelpId) !== undefined) {
								oTable = sap.ui.getCore().byId(sValueHelpId).getContent()[0].getItems()[1].getItems()[1];
								oTable.setThreshold(1000);
							} else {
								sValueHelpId = sValueHelpId.replace(sControlName, sNewControlName);
								oTable = sap.ui.getCore().byId(sValueHelpId).getContent()[0].getItems()[1].getItems()[1];
								oTable.setThreshold(1000);
							}

						}, 2000);
					});
				}
			}
		}

	});

});