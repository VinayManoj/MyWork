/*******************************************************************************
 * Project : Digital Propulsion Module : Functional document : ... Technical
 * document : ...
 * -------------------------------------------------------------------------------------------------------------------------------------
 * File name : ManagePOScheduling.controller.js Written by : SOPRA Team Company :
 * Sopra Steria Creation date : 06.03.2019
 * --------------------------------------------------------------------------------------------------------------------------------------
 * File description : This controller contains the functions that are supposed
 * to be called inside several screens in the application
 * --------------------------------------------------------------------------------------------------------------------------------------
 * Last modification date : Author : Description : Transport order :
 ******************************************************************************/

sap.ui.define(["airbus/ui/digital_propulsion/controller/ManageProgram.controller", 'sap/ui/model/Sorter', 'sap/ui/model/Filter',
		'sap/ui/model/FilterOperator', "airbus/ui/digital_propulsion/util/Formatter", "sap/m/MessageToast"
	],

	function (ManageProgram, Sorter, Filter, FilterOperator, Formatter, MessageToast) {
		"use strict";

		return ManageProgram.extend("airbus.ui.digital_propulsion.controller.ManageProgram.ManagePOScheduling", {

			formatter: Formatter,

			onInit: function () {

				var oView = this.getView();
				var oModel = this.getOwnerComponent().getModel("digital");

				oView.setModel(oModel);

				this.oProgramController = jQuery.sap.getObject("airbus.global.digital.ManageProgram");

			},

			/**
			 * @function: onBeforeBind
			 * @description: Before the binding of smart Table happen
			 * @HJC on 07.03.2019 for US
			 */
			onBeforeBind: function (oEvent) {
				var oView = this.getView();
				var oACModel = oView.getModel("aircraft");
				// var oDefaultFilter = this.getView().getModel("default");
				var sAircraft = "";
				var sPOPadLock = oView.byId("idPOpadlock").getSelectedKey();
				var sPRPadLock = oView.byId("idPrpadlock").getSelectedKey();
				var sStatPadLock = oView.byId("idStatpadlock").getSelectedKey();
				var oIsPoCommentItem = oView.byId("idIsPoComment").getSelectedItem();
				var oMisalignmentindicator = oView.byId("idMisalignmentindicator").getSelectedItem();

				var mBindingParams = oEvent.getParameter("bindingParams");

				var sSelectedProgram = jQuery.sap.getObject("airbus.ui.digital_propulsion.GLOBAL.Aircraft");
				switch (sSelectedProgram) {
				case "A320":
					sAircraft = oACModel.getProperty("/Type/A320"); // "N"
					break;
				case "A330":
					sAircraft = oACModel.getProperty("/Type/A330"); // "L"
					break;
				case "A350":
					sAircraft = oACModel.getProperty("/Type/A350"); // "P"
					break;
				case "A380":
					sAircraft = oACModel.getProperty("/Type/A380"); // "R"
					break;
				default:
					break;
				}
				// initial sorter on PO delivery Date ascending
				// if (!mBindingParams.sorter.length) {
				// mBindingParams.sorter.push(new Sorter("Deliverydate", false))
				// }

				mBindingParams.filters.push(new Filter({
					path: "Zprogram",
					operator: FilterOperator.EQ,
					value1: sAircraft
				}));

				if (sPOPadLock === "2") {
					mBindingParams.filters.push(new Filter({
						path: "Popadlock",
						operator: FilterOperator.EQ,
						value1: "lock" // updated by LEI on 09.05.2019 to get good label for padlock in excell export
					}));
				} else if (sPOPadLock === "3") {
					mBindingParams.filters.push(new Filter({
						path: "Popadlock",
						operator: FilterOperator.NE,
						value1: "lock" // updated by LEI on 09.05.2019 to get good label for padlock in excell export
					}));
				}

				if (sPRPadLock === "2") {
					mBindingParams.filters.push(new Filter({
						path: "Prpadlock",
						operator: FilterOperator.EQ,
						value1: "lock" // updated by LEI on 09.05.2019 to get good label for padlock in excell export
					}));
				} else if (sPRPadLock === "3") {
					mBindingParams.filters.push(new Filter({
						path: "Prpadlock",
						operator: FilterOperator.NE,
						value1: "lock" // updated by LEI on 09.05.2019 to get good label for padlock in excell export
					}));
				}

				if (sStatPadLock === "2") {
					mBindingParams.filters.push(new Filter({
						path: "Statpadlock",
						operator: FilterOperator.EQ,
						value1: "lock" // updated by LEI on 09.05.2019 to get good label for padlock in excell export
					}));
				} else if (sStatPadLock === "3") {
					mBindingParams.filters.push(new Filter({
						path: "Statpadlock",
						operator: FilterOperator.NE,
						value1: "lock" // updated by LEI on 09.05.2019 to get good label for padlock in excell export
					}));
				}

				// Filter on PO Comment Y/N
				//If selected key is 2 or 3, filter on the corresponding text (cf xml file) 
				if (oIsPoCommentItem) {
					if (oIsPoCommentItem.getKey() === "2") {
						mBindingParams.filters.push(new Filter({
							path: "IsPoComment",
							operator: FilterOperator.EQ,
							value1: oIsPoCommentItem.getText()
						}));
					} else if (oIsPoCommentItem.getKey() === "3") {
						mBindingParams.filters.push(new Filter({
							path: "IsPoComment",
							operator: FilterOperator.EQ,
							value1: oIsPoCommentItem.getText()
						}));
					}
				}

				//Filter on Dates <> (Misalignment indicator)
				if (oMisalignmentindicator) {
					if (oMisalignmentindicator.getKey() !== "") {
						mBindingParams.filters.push(new Filter({
							path: "Misalignmentindicator",
							operator: FilterOperator.EQ,
							value1: oMisalignmentindicator.getKey()
						}));
					}
				}
			},

			/**
			 * @HJC for US BLM 87 on 12.03.2019
			 * 
			 * @function: onCommentMorePress
			 * @description: Open dialog to manage the comment
			 * @param: 
			 */

			onCommentMorePress: function (oEvent) {

				var oSource = oEvent.getSource();
				var oText = oSource.getParent().getItems()[0];
				this._sPOCommentBindingPath = oText.getBindingContext().sPath;

				if (!this._oPOScheduleCommentDialog) {
					this._oPOScheduleCommentDialog = sap.ui.xmlfragment("airbus.ui.digital_propulsion.fragment.POScheduleComment", this);
					this.getView().addDependent(this._oPOScheduleCommentDialog);
				}

				this._oPOScheduleCommentDialog.bindElement({
					path: this._sPOCommentBindingPath
				});

				this._oPOScheduleCommentDialog.open();

			},

			/**
			 * @HJC for US BLM 87 on 14.03.2019
			 * 
			 * @function: onCommentUpdate
			 * @description: When user add comments
			 * @param: 
			 */

			onCommentUpdate: function (oEvent) {

				var oSource = oEvent.getSource();
				var oIcon = oSource.getParent().getItems()[1];

				if (oSource.getValue().length > 0) {
					oIcon.setVisible(true);
				} else {
					oIcon.setVisible(false);
				}

			},

			/**
			 * @HJC for US BLM 87 on 12.03.2019
			 * 
			 * @function: onPressOk
			 * @description: On PO Comment Save
			 * @param: 
			 */

			onPressOk: function () {
				// var that = this;
				// var oModel = this.getView().getModel("digital");
				// oModel.setProperty(this._sPOCommentBindingPath +"/Actiontype", "COM")

				// if (oModel.getPendingChanges()) {

				// 	oModel.submitChanges(({
				// 		groupId: "POSchedule", success: function (oData, oResponse) {

				// 			that._oPOScheduleCommentDialog.close();
				// 			// to manage error messages and show them in messageToast
				// 			try {
				// 				if (oResponse.data.__batchResponses[0].response !== undefined) {
				// 					var oMessageObject = JSON.parse(oResponse.data.__batchResponses[0].response.body);
				// 					var sMessageText = oMessageObject.error.message.value;
				// 					MessageToast.show(sMessageText);
				// 				}
				// 			} catch (e) {
				// 				// Handle Error
				// 			}
				// 		}, error: that.myErrorHandler
				// 	}));
				// }

				this.onPressCancel();
			},

			/**
			 * @HJC for US BLM 87 on 12.03.2019
			 * 
			 * @function: onPressCancel
			 * @description: On PO Comment Cancel Press
			 * @param: 
			 */

			onPressCancel: function () {
				if (this._oPOScheduleCommentDialog) {
					this._oPOScheduleCommentDialog.close();
				}
			},

			/**
			 * @function: myErrorHandler @description: When receiving error
			 * message from backend after Batch @CreatedBy : KSD
			 * @CreatedOn:20.02.2019 @US: DIGITPROP_BLM-59
			 */
			myErrorHandler: function myErrorHandler(oEvent) {
				// console.log('Error');
				// to manage
			},

			/**
			 * @HJC for US BLM  on 23.07.2019
			 * 
			 * @function: onVariantLoad
			 * @description: Manage Custom fields when Varient is Loaded
			 * @param: 
			 */

			onVariantLoad: function (oEvent) {
				var oSource = oEvent.getSource();
				var oCustomData = oSource.getFilterData(true)["_CUSTOM"];
				if (oCustomData) {
					this.getView().byId("idIsPoComment").setSelectedKey(oCustomData.IsPoComment);
					this.getView().byId("idPOpadlock").setSelectedKey(oCustomData.Popadlock);
					this.getView().byId("idPrpadlock").setSelectedKey(oCustomData.Prpadlock);
					this.getView().byId("idStatpadlock").setSelectedKey(oCustomData.Statpadlock);
					this.getView().byId("idMisalignmentindicator").setSelectedKey(oCustomData.Misalignmentindicator);
				} else {
					this.getView().byId("idIsPoComment").setSelectedKey("1");
					this.getView().byId("idPOpadlock").setSelectedKey("1");
					this.getView().byId("idPrpadlock").setSelectedKey("1");
					this.getView().byId("idStatpadlock").setSelectedKey("1");
					this.getView().byId("idMisalignmentindicator").setSelectedKey("");
				}
			},

			/**
			 * @HJC for US BLM 307 on 23.07.2019
			 * 
			 * @function: onVariantSave
			 * @description: Manage Custom fields when Varient is Saved
			 * @param: 
			 */

			onVariantSave: function (oEvent) {
				var oSource = oEvent.getSource();
				var sPOPadLock = this.getView().byId("idPOpadlock").getSelectedKey();
				var sPRPadLock = this.getView().byId("idPrpadlock").getSelectedKey();
				var sStatPadLock = this.getView().byId("idStatpadlock").getSelectedKey();
				var sComment = this.getView().byId("idIsPoComment").getSelectedKey();
				var sMisalignmentindicator = this.getView().byId("idMisalignmentindicator").getSelectedKey();

				oSource.setFilterData({
					_CUSTOM: {
						IsPoComment: sComment,
						Popadlock: sPOPadLock,
						Prpadlock: sPRPadLock,
						Statpadlock: sStatPadLock,
						Misalignmentindicator: sMisalignmentindicator

					}
				});
			},

			/**
			 * @SSH for US DP 338 on 17.09.2019
			 * 
			 * @function: onClearPOSFilter
			 * @description: Clear custom filters and variant on click of 'Clear'.
			 * @param: 
			 */
			onClearPOSFilter: function (oEvent) {
				//Custom filter clearance
				this.getView().byId("idPOpadlock").setSelectedKey("");
				this.getView().byId("idPrpadlock").setSelectedKey("");
				this.getView().byId("idStatpadlock").setSelectedKey("");
				this.getView().byId("idIsPoComment").setSelectedKey("");
				this.getView().byId("idMisalignmentindicator").setSelectedKey("");

				//Variant de-selection
				this.getView().byId("idSmartPOSchedule").clearVariantSelection();
			},

			/**
			 * 
			 * 
			 * 
			 */
			onAfterRendering: function () {
				var oFilterBar = this.getView().byId("idSmartPOSchedule");
				var aGroupItems = oFilterBar.getFilterGroupItems();

				for (var i = 0; i < aGroupItems.length; i++) {

					if (aGroupItems[i].getName() === "Materialnumber" || aGroupItems[i].getName() === "Materialdescription") {
						var oControl = aGroupItems[i].getControl();
						oControl.attachEvent("valueHelpRequest", function () {
							setTimeout(function () {
								var sControlName = oControl.getId().slice(oControl.getId().lastIndexOf("-") + 1);
								var sNewControlName;
								if (sControlName === "Materialnumber") {
									sNewControlName = "Materialdescription";
								} else {
									sNewControlName = "Materialnumber";
								}

								var sValueHelpId = oControl.getId() + "-valueHelpDialog";
								if (sap.ui.getCore().byId(sValueHelpId) !== undefined) {
									var oTable = sap.ui.getCore().byId(sValueHelpId).getContent()[0].getItems()[1].getItems()[1];
									oTable.setThreshold(1000);
								} else {
									sValueHelpId = sValueHelpId.replace(sControlName, sNewControlName);
									var oTable = sap.ui.getCore().byId(sValueHelpId).getContent()[0].getItems()[1].getItems()[1];
									oTable.setThreshold(1000);
								}

							}, 2000);
						});
					}

				}
			}

		});

	});