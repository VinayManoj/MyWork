/*******************************************************************************
 * Project : Digital Propulsion Module : Functional document : ... Technical
 * document : ...
 * -------------------------------------------------------------------------------------------------------------------------------------
 * File name : ManageGRvalidation.controller.js Written by : SOPARA Team Company :
 * Sopra Steria Creation date : 04.02.2019
 * --------------------------------------------------------------------------------------------------------------------------------------
 * File description : This controller contains the functions that are supposed
 * to be called inside several screens in the application
 * --------------------------------------------------------------------------------------------------------------------------------------
 * Last modification date : Author : Description : Transport order :
 ******************************************************************************/

sap.ui.define(["airbus/ui/digital_propulsion/controller/ManageProgram.controller", 'sap/ui/model/Sorter', 'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator', "sap/m/MessageBox",
	"airbus/ui/digital_propulsion/util/Formatter", "sap/m/MessageToast"
], function (ManageProgram, Sorter, Filter, FilterOperator, MessageBox, Formatter, MessageToast) {
	"use strict";

	return ManageProgram.extend("airbus.ui.digital_propulsion.controller.ManageProgram.ManageGRCancelation", {

		formatter: Formatter,

		onInit: function () {

			var oView = this.getView();
			var oModel = this.getOwnerComponent().getModel("digital");

			oView.setModel(oModel);

			this.oProgramController = jQuery.sap.getObject("airbus.global.digital.ManageProgram");

			// MessageManager initialization and set errorMessage model
			var oMessageManager = sap.ui.getCore().getMessageManager();
			this.getView().setModel(oMessageManager.getMessageModel(), "errorMsgModel");
			// activate automatic message generation for complete view
			oMessageManager.registerObject(this.getView(), true);
		},

		/**
		 * @function: onBeforeBind
		 * @description: Before the binding of smart Table happen
		 * @HJC on 04.02.2019 for US
		 */
		onBeforeBind: function (oEvent) {
			var oACModel = this.getView().getModel("aircraft");
			var sAircraft = "";
			var sPubStat = this.getView().byId("idGRPublicationstatus").getSelectedKey();

			var mBindingParams = oEvent.getParameter("bindingParams");

			//Added by SSH for Publication Status Drop dowm management
			if (sPubStat === "1")
				mBindingParams.filters.push(new Filter({
					path: "Publicationstatus",
					operator: FilterOperator.EQ,
					value1: " "
				}));
			else if (sPubStat === "2")
				mBindingParams.filters.push(new Filter({
					path: "Publicationstatus",
					operator: FilterOperator.EQ,
					value1: "0"
				}));
			else if (sPubStat === "3")
				mBindingParams.filters.push(new Filter({
					path: "Publicationstatus",
					operator: FilterOperator.EQ,
					value1: "1"
				}));
			else if (sPubStat === "4")
				mBindingParams.filters.push(new Filter({
					path: "Publicationstatus",
					operator: FilterOperator.EQ,
					value1: "2"
				}));

			var sSelectedProgram = jQuery.sap.getObject("airbus.ui.digital_propulsion.GLOBAL.Aircraft");
			switch (sSelectedProgram) {
			case "A320":
				sAircraft = oACModel.getProperty("/Type/A320"); // "N"
				break;
			case "A330":
				sAircraft = oACModel.getProperty("/Type/A330"); // "L"
				break;
			case "A350":
				sAircraft = oACModel.getProperty("/Type/A350"); // "P"
				break;
			case "A380":
				sAircraft = oACModel.getProperty("/Type/A380"); // "R"
				break;
			default:
				break;
			}
			// initial sorter on PO delivery Date ascending
			if (!mBindingParams.sorter.length) {
				mBindingParams.sorter.push(new Sorter("Deliverydate", false));
			}

			mBindingParams.filters.push(new Filter({
				path: "Zprogram",
				operator: FilterOperator.EQ,
				value1: sAircraft
			}));

			try {
				var aAppliedFilters = mBindingParams.filters[0].aFilters;

				if (aAppliedFilters.length === 1) {

					if (aAppliedFilters[0].sPath === "Serialnumber" && aAppliedFilters[0].oValue1 === " ") {
						aAppliedFilters[0].oValue1 = null;
					}
				} else {
					for (var n = 0; n < aAppliedFilters.length; n++) {

						var aAppliedFilter = aAppliedFilters[n].aFilters;

						if (aAppliedFilter) {
							var sProperty = aAppliedFilter[0].sPath;

							if (sProperty === "Serialnumber") {

								for (var p in aAppliedFilter) {
									if (aAppliedFilter[p].oValue1 === " ") {
										aAppliedFilter[p].oValue1 = null;
									}
								}
							}
						} else {
							for (var q in aAppliedFilters) {
								if (aAppliedFilters[q].sPath === "Serialnumber" && aAppliedFilters[q].oValue1 === " ") {
									aAppliedFilters[q].oValue1 = null;
								}
							}
						}

					}
				}
			} catch (e) {

			}
		},

		/*
		 * @function: onRowSelect @description: When selecting a row of GR
		 * smarttable @CreatedBy : KSD @CreatedOn : 14.02.2019 @US:
		 * DIGITPROP_BLM-59
		 */
		onRowSelect: function onRowSelect(oEvent) {

		},

		/**
		 * @HJC for US BLM 373 on 01.08.2019
		 * 
		 * @function: onCommentMorePress
		 * @description: Open dialog to manage the comment
		 * @param: 
		 */

		onCommentMorePress: function (oEvent) {

			var oSource = oEvent.getSource();
			var oText = oSource.getParent().getItems()[0];
			this._sPOCommentBindingPath = oText.getBindingContext().sPath;

			if (!this._oGRValidationCommentDialog) {
				this._oGRValidationCommentDialog = sap.ui.xmlfragment("airbus.ui.digital_propulsion.fragment.GRValidationComment", this);
				this.getView().addDependent(this._oGRValidationCommentDialog);
			}

			this._oGRValidationCommentDialog.bindElement({
				path: this._sPOCommentBindingPath
			});

			this._oGRValidationCommentDialog.open();

		},

		/**
		 * @HJC for US BLM 373 on 01.08.2019
		 * 
		 * @function: onCommentUpdate
		 * @description: When user add comments
		 * @param: 
		 */

		onCommentUpdate: function (oEvent) {

			var oSource = oEvent.getSource();
			var oIcon = oSource.getParent().getItems()[1];

			if (oSource.getValue().length > 0) {
				oIcon.setVisible(true);
			} else {
				oIcon.setVisible(false);
			}

		},

		/**
		 * @HJC for US BLM 373 on 01.08.2019
		 * 
		 * @function: onPressOk
		 * @description: On PO Comment Save
		 * @param: 
		 */

		onPressOk: function () {
			this.onPressCancel();
		},

		/**
		 * @HJC for US BLM 373 on 01.08.2019
		 * 
		 * @function: onPressCancel
		 * @description: On PO Comment Cancel Press
		 * @param: 
		 */

		onPressCancel: function () {
			if (this._oGRValidationCommentDialog) {
				this._oGRValidationCommentDialog.close();
			}
		},

		/**
		 * @SSH for US DP 338 on 10.10.2019
		 * 
		 * @function: onClearGRVFilter
		 * @description: Clear custom filters and variant on click of 'Clear'.
		 * @param: 
		 */
		onClearGRVFilter: function (oEvent) {
			//Custom filter clearance
			this.getView().byId("idGRPublicationstatus").setSelectedKey("");

			//Variant de-selection
			this.getView().byId("idSmartGRVal").clearVariantSelection();
		},

		/**
		 * @SSH for US BLM 307 on 10.010.2019
		 * 
		 * @function: onGRVVariantLoad
		 * @description: Manage Custom fields when Varient is Loaded
		 * @param: 
		 */

		onGRVVariantLoad: function (oEvent) {
			var oSource = oEvent.getSource();
			var oCustomData = oSource.getFilterData(true)["_CUSTOM"];
			if (oCustomData) {
				this.getView().byId("idGRPublicationstatus").setSelectedKey(oCustomData.Publicationstatus);
			} else {
				this.getView().byId("idGRPublicationstatus").setSelectedKey("0");
			}
		},

		/**
		 * @SSH for US BLM 307 on 10.10.2019
		 * 
		 * @function: onGRVVariantSave
		 * @description: Manage Custom fields when Varient is Saved
		 * @param: 
		 */

		onGRVVariantSave: function (oEvent) {
			var oSource = oEvent.getSource();
			var sPubStat = this.getView().byId("idGRPublicationstatus").getSelectedKey();
			oSource.setFilterData({
				_CUSTOM: {
					Publicationstatus: sPubStat
				}
			});
		},

		/**
		 * 
		 * 
		 * 
		 */
		onAfterRendering: function () {
			var oFilterBar = this.getView().byId("idSmartGRCancellation");
			var aGroupItems = oFilterBar.getFilterGroupItems();

			for (var i = 0; i < aGroupItems.length; i++) {

				if (aGroupItems[i].getName() === "Materialnumber" || aGroupItems[i].getName() === "Materialdesription") {
					var oControl = aGroupItems[i].getControl();
					oControl.attachEvent("valueHelpRequest", function () {
						setTimeout(function () {
							var sControlName = oControl.getId().slice(oControl.getId().lastIndexOf("-") + 1);
							var sNewControlName;
							if (sControlName === "Materialnumber") {
								sNewControlName = "Materialdescription";
							} else {
								sNewControlName = "Materialnumber";
							}

							var sValueHelpId = oControl.getId() + "-valueHelpDialog";
							if (sap.ui.getCore().byId(sValueHelpId) !== undefined) {
								var oTable = sap.ui.getCore().byId(sValueHelpId).getContent()[0].getItems()[1].getItems()[1];
								oTable.setThreshold(1000);
							} else {
								sValueHelpId = sValueHelpId.replace(sControlName, sNewControlName);
								var oTable = sap.ui.getCore().byId(sValueHelpId).getContent()[0].getItems()[1].getItems()[1];
								oTable.setThreshold(1000);
							}

						}, 2000);
					});
				}
			}
		}

	});

});