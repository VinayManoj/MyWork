/*******************************************************************************
 * Project : Digital Propulsion Module : Functional document : ... Technical
 * document : ...
 * -------------------------------------------------------------------------------------------------------------------------------------
 * File name : ManageCreatePO.controller.js Written by : SOPARA Team Company :
 * Sopra Steria Creation date : 13.11.2018
 * --------------------------------------------------------------------------------------------------------------------------------------
 * File description : This controller contains the functions that are supposed
 * to be called inside several screens in the application
 * --------------------------------------------------------------------------------------------------------------------------------------
 * Last modification date : Author : Description : Transport order :
 ******************************************************************************/

sap.ui.define(["airbus/ui/digital_propulsion/controller/ManageProgram.controller",
	"sap/ui/model/Sorter", "sap/ui/model/Filter", "sap/ui/model/FilterOperator"],
	function (ManageProgram, Sorter, Filter, FilterOperator) {
		"use strict";

		return ManageProgram.extend("airbus.ui.digital_propulsion.controller.ManageProgram.ManageCreatePOCDS", {

			onInit: function () {
				//test

				var oView = this.getView();
				var oModel = this.getOwnerComponent().getModel("digital");

				oView.setModel(oModel);

				jQuery.sap.setObject("airbus.global.digital.ManageCreatePO", this);
			},

			/**
			 * @function: onBeforeBind
			 * @description: Before the binding of smart Table happen
			 * @HJC on 17.12.2018 for US RSK5
			 */
			onBeforeBind: function (oEvent) {
				var mBindingParams = oEvent.getParameter("bindingParams");
				mBindingParams.sorter.push(new Sorter('Deliverydate', true));

				var oACModel = this.getView().getModel("aircraft");
				var oDefaultFilter = this.getView().getModel("default");
				var sAircraft = "";
				
				var sSelectedProgram = jQuery.sap.getObject("airbus.ui.digital_propulsion.GLOBAL.Aircraft");

				switch (sSelectedProgram) {
					case "A320":
						sAircraft = oACModel.getProperty("/Type/A320"); // "N"
						break;
					case "A330":
						sAircraft = oACModel.getProperty("/Type/A330"); // "L"
						break;
					case "A350":
						sAircraft = oACModel.getProperty("/Type/A350"); // "P"
						break;
					case "A380":
						sAircraft = oACModel.getProperty("/Type/A380"); // "R"
						break;
					default:
						break;
				}

				mBindingParams.filters.push(new Filter({
					path: "Zprogram",
					operator: FilterOperator.EQ,
					value1: sAircraft
				}));

				for (var i in oDefaultFilter.oData.plant) {
					mBindingParams.filters.push(new Filter({
						path: "Plant",
						operator: FilterOperator.EQ,
						value1: oDefaultFilter.oData.plant[i]
					}));
				}
				

				for (var j in oDefaultFilter.oData.Salesorg) {
					mBindingParams.filters.push(new Filter({
						path: "Vkorg",
						operator: FilterOperator.EQ,
						value1: oDefaultFilter.oData.Salesorg[j]
						// aSalesOrg[j]
					}));
				}
				

				for (var k in oDefaultFilter.oData.Purorg) {
					mBindingParams.filters.push(new Filter({
						path: "Purchaseorg",
						operator: FilterOperator.EQ,
						value1: oDefaultFilter.oData.Purorg[k]
						// aPurchaseOrg[k]
					}));
				}
				

				for (var l in oDefaultFilter.oData.Dischannel) {
					mBindingParams.filters.push(new Filter({
						path: "Vtweg",
						operator: FilterOperator.EQ,
						value1: oDefaultFilter.oData.Dischannel[l]
						// sChannel
					}));
				}
			},

			/**
			 * @function: onRowSelect
			 * @description: When user Selects a row for PO creation
			 * @HJC on 26.12.2018 for US BLM 21
			 */

			onRowSelect: function (oEvent) {
				var i;
				try {
					var oSource = oEvent.getSource();
					var bMultiSelect = oEvent.getParameter('selectAll');
					var oContext = oEvent.getParameter('rowContext');
					// var oModel = oContext.getModel();
					var oModel = oSource.getBinding().getModel();
					// var sMassCrtPath = oContext.sPath + "/Pomasscrt";
					var bSelect;
					var aRows = oEvent.getParameter('rowIndices');
					var sRowIndex = oEvent.getParameter('rowIndex');

					// if all rows has been ticked
					if (bMultiSelect) {
						bSelect = 'X';
					}
					// if all rows has been unticked
					else if (!bMultiSelect && sRowIndex === -1) {
						bSelect = '';
					}
					// if only one row has been ticked/unticked
					else if (!bMultiSelect && oContext) {
						// modified by KSD on 07/02/2019 for bug on unticked
						if (oSource.getSelectedIndices().indexOf(sRowIndex) > -1) {
							bSelect = 'X';
						} else {
							bSelect = '';
						}
					}
					// loop on all rows to modify and update model with
					// selection/unselection
					for (i = 0; i < aRows.length; i++) {
						oModel.setProperty(oSource.getContextByIndex(aRows[i]).getPath() + "/Pomasscrt", bSelect);
					}
				} catch (e) {
					// TODO: handle exception
				}

			}
		});

	});