/*******************************************************************************
 * Project : Digital Propulsion Module : Functional document : ... Technical
 * document : ...
 * -------------------------------------------------------------------------------------------------------------------------------------
 * File name : MyOverview.controller.js Written by : SOPARA Team Company : Sopra
 * Steria Creation date : 13.11.2018
 * --------------------------------------------------------------------------------------------------------------------------------------
 * File description : This controller contains the functions that are supposed
 * to be called inside several screens in the application
 * --------------------------------------------------------------------------------------------------------------------------------------
 * Last modification date : Author : Description : Transport order :
 ******************************************************************************/

sap.ui.define(["airbus/ui/digital_propulsion/controller/ManageProgram.controller", 'sap/ui/model/Sorter', 'sap/ui/model/Filter',
	'sap/ui/model/FilterOperator',
	"airbus/ui/digital_propulsion/util/Formatter"
], function (ManageProgram, Sorter, Filter, FilterOperator, Formatter) {
	"use strict";

	return ManageProgram.extend("airbus.ui.digital_propulsion.controller.ManageProgram.MyOverviewCDS", {

		formatter: Formatter,

		onInit: function () {

			var oView = this.getView();
			var oModel = this.getOwnerComponent().getModel("digital");

			oView.setModel(oModel);

			this.oProgramController = jQuery.sap.getObject("airbus.global.digital.ManageProgram");
		},

		/**
		 * @function: onBeforeBind
		 * @description: Before the binding of smart Table happen
		 * @HJC on 28.11.2018 for US RSK5
		 */
		onBeforeBind: function (oEvent) {
			var oACModel = this.getView().getModel("aircraft");
			// var oDefaultFilter = this.getView().getModel("default");
			var sAircraft = "";
			var oMisalignmentindicator = this.getView().byId("idMisalignmentindicator").getSelectedItem();
			// var aPlant = ["TLS"];
			// var aSalesOrg = ["2000"];
			// var sChannel = "20";
			// var aPurchaseOrg = ["2000"];
			var mBindingParams = oEvent.getParameter("bindingParams");

			var sSelectedProgram = jQuery.sap.getObject("airbus.ui.digital_propulsion.GLOBAL.Aircraft");
			switch (sSelectedProgram) {
			case "A320":
				sAircraft = oACModel.getProperty("/Type/A320"); // "N"
				// aPlant.push("AFA1");
				// aSalesOrg.push("2070");
				// aPurchaseOrg.push("7000");
				break;
			case "A330":
				sAircraft = oACModel.getProperty("/Type/A330"); // "L"
				break;
			case "A350":
				sAircraft = oACModel.getProperty("/Type/A350"); // "P"
				break;
			case "A380":
				sAircraft = oACModel.getProperty("/Type/A380"); // "R"
				break;
			default:
				break;
			}

			mBindingParams.filters.push(new Filter({
				path: "Zprogram",
				operator: FilterOperator.EQ,
				value1: sAircraft
			}));

			// for (var i in oDefaultFilter.oData.plant) {
			// 	mBindingParams.filters.push(new Filter({
			// 		path: "Plant",
			// 		operator: FilterOperator.EQ,
			// 		value1: oDefaultFilter.oData.plant[i]
			// 	}));
			// }

			// for (var j in oDefaultFilter.oData.Salesorg) {
			// 	mBindingParams.filters.push(new Filter({
			// 		path: "Vkorg",
			// 		operator: FilterOperator.EQ,
			// 		value1: oDefaultFilter.oData.Salesorg[j]
			// 		// aSalesOrg[j]
			// 	}));
			// }

			// for (var k in oDefaultFilter.oData.Purorg) {
			// 	mBindingParams.filters.push(new Filter({
			// 		path: "Purchaseorg",
			// 		operator: FilterOperator.EQ,
			// 		value1: oDefaultFilter.oData.Purorg[k]
			// 		// aPurchaseOrg[k]
			// 	}));
			// }

			// for (var l in oDefaultFilter.oData.Dischannel) {
			// 	mBindingParams.filters.push(new Filter({
			// 		path: "Vtweg",
			// 		operator: FilterOperator.EQ,
			// 		value1: oDefaultFilter.oData.Dischannel[l]
			// 		// sChannel
			// 	}));
			// }

			//added by HJC on 28.03.2019 for Filter on Dates <> (Misalignment indicator)
			if (oMisalignmentindicator) {
				if (oMisalignmentindicator.getKey() !== "") {
					mBindingParams.filters.push(new Filter({
						path: "Misalignmentindicator",
						operator: FilterOperator.EQ,
						value1: oMisalignmentindicator.getKey()
					}));
				}
			}

			var oDateModel = this.getView().getModel("date");
			if (oDateModel.getProperty("/Gr103date/0/isBlank")) {
				mBindingParams.filters.push(new Filter({
					path: "Gr103date",
					operator: FilterOperator.EQ,
					value1: null
				}));
			}

			var aGR103DateToken = this.getView().byId("idGr103date").getTokens();

			if (aGR103DateToken.length > 0) {

				var aRanges = this.getView().byId("idSmartOverviewCDS")._oFilterProvider.getFilterData()._CUSTOM.Gr103date.ranges;
				var oDateValue1, oDateValue2;

				for (var m = 0; m < aRanges.length; m++) {

					var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({
						pattern: "yyyy-MM-dd"
					});

					if (aRanges[m].value1 !== null && aRanges[m].value1) {
						oDateValue1 = dateFormat.format(aRanges[m].value1, false);
					} else {
						oDateValue1 = null;
					}

					if (aRanges[m].value2 !== null && aRanges[m].value2) {
						oDateValue2 = dateFormat.format(aRanges[m].value2, false);
					} else {
						oDateValue2 = null;
					}

					mBindingParams.filters.push(new Filter({
						path: "Gr103date",
						operator: aRanges[m].operation,
						value1: oDateValue1,
						value2: oDateValue2,
						exclude: aRanges[m].exclude,
					}));
				}

			}

			try {
				var aAppliedFilters = mBindingParams.filters[0].aFilters;

				if (aAppliedFilters.length === 1) {

					if (aAppliedFilters[0].sPath === "Serialnumber" && aAppliedFilters[0].oValue1 === " ") {
						aAppliedFilters[0].oValue1 = null;
					}
				} else {
					for (var n = 0; n < aAppliedFilters.length; n++) {

						var aAppliedFilter = aAppliedFilters[n].aFilters;

						if (aAppliedFilter) {
							var sProperty = aAppliedFilter[0].sPath;

							if (sProperty === "Serialnumber") {

								for (var p in aAppliedFilter) {
									if (aAppliedFilter[p].oValue1 === " ") {
										aAppliedFilter[p].oValue1 = null;
									}
								}
							}
						} else {
							for (var q in aAppliedFilters) {
								if (aAppliedFilters[q].sPath === "Serialnumber" && aAppliedFilters[q].oValue1 === " ") {
									aAppliedFilters[q].oValue1 = null;
								}
							}
						}

					}
				}

			} catch (e) {

			}

		},

		/**
		 * @HJC for US BLM 307 on 23.07.2019
		 * 
		 * @function: onVariantLoad
		 * @description: Manage Custom fields when Varient is Loaded
		 * @param: 
		 */

		onVariantLoad: function (oEvent) {
			var oSource = oEvent.getSource();
			var that = this;
			var aTokens = [];
			var oCustomData = oSource.getFilterData(true)["_CUSTOM"];
			if (oCustomData) {
				this.getView().byId("idMisalignmentindicator").setSelectedKey(oCustomData.Misalignmentindicator);
				var oGR103Input = this.getView().byId("idGr103date");

				try {

					if (oCustomData.Gr103date.ranges.length > 0) {

						for (var i = 0; i < oCustomData.Gr103date.ranges.length; i++) {

							if (oCustomData.Gr103date.ranges[i].value1 !== null && oCustomData.Gr103date.ranges[i].value1) {
								oCustomData.Gr103date.ranges[i].value1 = new Date(oCustomData.Gr103date.ranges[i].value1);
							}

							if (oCustomData.Gr103date.ranges[i].value2 !== null && oCustomData.Gr103date.ranges[i].value2) {
								oCustomData.Gr103date.ranges[i].value2 = new Date(oCustomData.Gr103date.ranges[i].value2);
							}

							var oToken = new sap.m.Token({
								key: oCustomData.Gr103date.ranges[i].tokenText,
								text: oCustomData.Gr103date.ranges[i].tokenText,
								delete: function (oEvent) {
									that.onVariantTokenDelete(oEvent);
								}
							});

							aTokens.push(oToken);
						}
						oGR103Input.setTokens(aTokens);

					} else {
						this.getView().byId("idGr103date").removeAllTokens();
					}
				} catch (e) {
					this.getView().byId("idGr103date").removeAllTokens();
				}

			} else {
				this.getView().byId("idMisalignmentindicator").setSelectedKey("");
				this.getView().byId("idGr103date").removeAllTokens();
			}
		},

		/**
		 * @HJC for US BLM 307 on 23.07.2019
		 * 
		 * @function: onVariantSave
		 * @description: Manage Custom fields when Varient is Saved
		 * @param: 
		 */

		onVariantSave: function (oEvent) {
			var aGR103Dates = [];
			var oSource = oEvent.getSource();
			var sMisalignmentindicator = this.getView().byId("idMisalignmentindicator").getSelectedKey();
			var aGR103Date = this.getView().byId("idGr103date").getTokens();

			if (aGR103Date.length > 0) {

				// aGR103Dates = oSource.getFilterData()._CUSTOM.Gr103date.ranges;
				aGR103Dates = oSource.getFilterData()._CUSTOM.Gr103date;
			}

			oSource.setFilterData({
				_CUSTOM: {
					Misalignmentindicator: sMisalignmentindicator,
					Gr103date: aGR103Dates
				}
			});
		},

		/**
		 * @SSH for US DP 338 on 17.09.2019
		 * 
		 * @function: onClearOVWFilter
		 * @description: Clear custom filters and variant on click of 'Clear'.
		 * @param: 
		 */
		onClearOVWFilter: function (oEvent) {
			//Custom filter clearance
			this.getView().byId("idMisalignmentindicator").setSelectedKey("");

			//Variant de-selection
			this.getView().byId("idSmartOverviewCDS").clearVariantSelection();

			//Remove Tokens from GR103 Date
			this.getView().byId("idGr103date").removeAllTokens();
		},

		/**
		 * @HJC for US DP 379 on 07.10.2019
		 * 
		 * @function: onGR103ValueHelp
		 * @description: Value help for GR103 date Filter Open
		 * @param: oEvent
		 */

		onGR103ValueHelp: function (oEvent) {

			this.oInput = oEvent.getSource();
			var oDateModel = this.getView().getModel("date");

			var oACDate = [{
				"Key": "Gr103date",
				"Text": "GR103 Date",
				"isBlank": false
			}];
			oDateModel.setProperty("/Gr103date", oACDate);

			if (!this._oDateDialog) {
				this._oDateDialog = sap.ui.xmlfragment("airbus.ui.digital_propulsion.fragment.DateFilterDialog", this);
				this.getView().addDependent(this._oDateDialog);
			}

			this._oDateDialog.setModel(oDateModel, "data");
			var aExtCondition = this._oDateDialog.getPanels()[0].getConditions();
			var aExtGRDate;
			try {
				aExtGRDate = this.getView().byId("idSmartOverviewCDS")._oFilterProvider.getFilterData()._CUSTOM.Gr103date;
			} catch (e) {
				aExtGRDate = [];
			}
			var aExtRange;

			if (aExtGRDate.length === 0) {
				aExtRange = aExtGRDate;
			} else {
				aExtRange = aExtGRDate.ranges;
			}

			if (aExtCondition.length === 0 && aExtRange.length === 0) {

			} else {

				var bIsVariant = false;
				if (aExtCondition.length === aExtRange.length) {

					for (var m = 0; aExtCondition.length > m; m++) {

						if (aExtCondition[m].value1 !== null &&
							aExtRange[m].value1 !== null &&
							aExtCondition[m].value1.toString() !== aExtRange[m].value1.toString()) {
							bIsVariant = true;
						}
					}
				} else {
					bIsVariant = true;
				}

				if (this.oInput.getTokens().length > 0 && bIsVariant) {

					var aRanges = this.getView().byId("idSmartOverviewCDS")._oFilterProvider.getFilterData()._CUSTOM.Gr103date.ranges;
					var aCondition = [];
					this._oDateDialog.getPanels()[0].removeAllFilterItems();
					for (var i = 0; i < aRanges.length; i++) {
						var oCondition = {};

						oCondition.exclude = aRanges[i].exclude;
						if (aRanges[i].exclude) {
							oCondition.operation = "NE";
						} else {
							oCondition.operation = aRanges[i].operation;
						}
						// oCondition.operation = aRanges[i].operation;
						oCondition.keyField = aRanges[i].keyField;
						oCondition.value1 = aRanges[i].value1;
						oCondition.value2 = aRanges[i].value2;
						oCondition.text = aRanges[i].tokenText;

						aCondition.push(oCondition);

						var oFilteItem = new sap.m.P13nFilterItem({
							columnKey: aRanges[i].keyField,
							operation: aRanges[i].operation,
							exclude: aRanges[i].exclude,
							value1: aRanges[i].value1,
							value2: aRanges[i].value2
						});

						this._oDateDialog.getPanels()[0].addFilterItem(oFilteItem);
					}
					this._oDateDialog.getPanels()[0].setConditions(aCondition);

				}

			}

			this._oDateDialog.open();
		},

		/**
		 * @HJC for US DP 379 on 07.10.2019
		 * 
		 * @function: onDateFilterOK
		 * @description: Apply GR103 Date Filter 
		 * @param: oEvent
		 */

		onDateFilterOK: function (oEvent) {
			var that = this;
			var aConditions = oEvent.getSource().getPanels()[0].getConditions();
			var oFilterProvider = this.getView().byId("idSmartOverviewCDS")._oFilterProvider;
			var oVariant = this.getView().byId("idSmartOverviewCDS").getVariantManagement();
			var aRanges = [];
			var aTokens = [];
			var oBlank, oRange, oToken;

			for (var i = 0; i < aConditions.length; i++) {

				if (aConditions[i].text !== "") {

					oRange = {};
					oRange.exclude = aConditions[i].exclude;
					if (aConditions[i].exclude) {
						oRange.operation = "NE";
					} else {
						oRange.operation = aConditions[i].operation;
					}

					oRange.keyField = aConditions[i].keyField;
					// oRange.value1 = aConditions[i].value1;
					// oRange.value2 = aConditions[i].value2;
					// oRange.tokenText = aConditions[i].text;

					if (aConditions[i].text.length > 30) {
						var sSplit = aConditions[i].text.split(" ");
						if (aConditions[i].operation === "BT") {
							oRange.tokenText = sSplit[1] + " " + sSplit[2] + ", " + sSplit[3] + "..." + sSplit[9] + " " + sSplit[10] + ", " + sSplit[11];
						} else {
							oRange.tokenText = sSplit[0].substr(0, 1) + sSplit[1] + " " + sSplit[2] + ", " + sSplit[3]; // "="
						}

					} else {
						oRange.tokenText = aConditions[i].text;
					}

					if (aConditions[i].value1 && aConditions[i].value1 !== null) {
						oRange.value1 = new Date(aConditions[i].value1);
					}

					if (aConditions[i].value2 && aConditions[i].value2 !== null) {
						oRange.value2 = new Date(aConditions[i].value2);
					}

					aRanges.push(oRange);

					oToken = new sap.m.Token({
						key: aConditions[i].key,
						text: oRange.tokenText, //aConditions[i].text,
						delete: function (oEvent) {
							that.onTokenDelete(oEvent);
						}
					});

					aTokens.push(oToken);
				}

			}

			try {

				var aBlankFilter = oFilterProvider.getFilterData()._CUSTOM.Gr103date.ranges;

				for (var j = 0; j < aBlankFilter.length; j++) {
					if (aBlankFilter[j].value1 === null) {
						oBlank = aBlankFilter[j];

						oToken = new sap.m.Token({
							key: "Gr103date",
							text: "=Blank",
							delete: function (oEvent) {
								that.onBlankTokenDelete(oEvent);
							}
						});

						aTokens.push(oToken);

						aRanges.push(oBlank);
					}
				}

			} catch (e) {

			}

			if (aRanges.length > 0) {
				// oFilterProvider.getFilterData().Gr103date.ranges = aRanges;

				try {
					oFilterProvider.getFilterData()._CUSTOM.Gr103date.ranges = aRanges;
				} catch (e) {
					oFilterProvider.setFilterData({
						_CUSTOM: {
							Gr103date: {
								ranges: aRanges
							}
						}
					});
				}

				this.oInput.setTokens(aTokens);
			} else {
				// oFilterProvider.getFilterData().Gr103date.ranges = [];

				oFilterProvider.setFilterData({
					_CUSTOM: {
						Gr103date: {
							ranges: []
						}
					}
				});

				this.oInput.setTokens(aTokens);
			}

			oVariant.currentVariantSetModified(true);

			this._oDateDialog.close();

		},

		/**
		 * @HJC for US DP 379 on 07.10.2019
		 * 
		 * @function: onDateFilterCancel
		 * @description: Close GR103 date filter Dialog
		 * @param: 
		 */

		onDateFilterCancel: function () {

			if (this._oDateDialog) {
				this._oDateDialog.close();
			}
		},

		/**
		 * @HJC for US DP 379 on 07.10.2019
		 * 
		 * @function: onTokenDelete
		 * @description: Date Token deleted from the Gr103 Date Input
		 * @param: oEvent
		 */

		onTokenDelete: function (oEvent) {
			var oToken = oEvent.getSource();
			var aConditions = this._oDateDialog.getPanels()[0].getConditions();
			var oFilterProvider = this.getView().byId("idSmartOverviewCDS")._oFilterProvider;
			var sDeletedKey = oToken.getKey();
			var aRanges = [];
			var aExistCondition = [];

			for (var i = 0; i < aConditions.length; i++) {

				if (aConditions[i].key !== sDeletedKey) {
					aExistCondition.push(aConditions[i]);
				}
			}

			this._oDateDialog.getPanels()[0].setConditions(aExistCondition);

			// var aGR103Range = oFilterProvider.getFilterData().Gr103date.ranges;
			var aGR103Range = oFilterProvider.getFilterData()._CUSTOM.Gr103date.ranges;

			for (var i = 0; i < aGR103Range.length; i++) {
				if (aGR103Range[i].value1 === null) {
					aExistCondition.push(aGR103Range[i]);
				}
			}

			aConditions = aExistCondition;

			for (var j = 0; j < aConditions.length; j++) {

				var oRange = {};
				oRange.exclude = aConditions[j].exclude;
				if (aConditions[j].exclude) {
					oRange.operation = "NE";
				} else {
					oRange.operation = aConditions[j].operation;
				}
				// oRange.operation = aConditions[j].operation;
				oRange.keyField = aConditions[j].keyField;
				oRange.value1 = aConditions[j].value1;
				oRange.value2 = aConditions[j].value2;
				oRange.tokenText = aConditions[j].text;

				aRanges.push(oRange);
			}

			if (aRanges.length > 0) {
				// oFilterProvider.getFilterData().Gr103date.ranges = aRanges;
				oFilterProvider.setFilterData({
					_CUSTOM: {
						Gr103date: {
							ranges: aRanges
						}
					}
				});

				if (oFilterProvider.getFilterData()._CUSTOM.Gr103date.ranges.length !== aRanges.length) {
					oFilterProvider.getFilterData()._CUSTOM.Gr103date.ranges = aRanges;
				}
			} else {
				// oFilterProvider.getFilterData().Gr103date.ranges = [];

				oFilterProvider.setFilterData({
					_CUSTOM: {
						Gr103date: {
							ranges: []
						}
					}
				});
			}

		},

		/**
		 * @HJC for US DP 379 on 07.10.2019
		 * 
		 * @function: onBlankDatePress
		 * @description: User wants to filter on Blank Date for GR103
		 * @param: 
		 */

		onBlankDatePress: function () {
			var that = this;
			var oFilterProvider = this.getView().byId("idSmartOverviewCDS")._oFilterProvider;
			var oVariant = this.getView().byId("idSmartOverviewCDS").getVariantManagement();
			var aTokens = [];

			var oRange = {};
			oRange.exclude = false;
			oRange.operation = "EQ";
			oRange.keyField = "Gr103date";
			oRange.value1 = null;
			oRange.tokenText = "=Blank";

			var oToken = new sap.m.Token({
				key: "Gr103date",
				text: "=Blank",
				delete: function (oEvent) {
					that.onBlankTokenDelete(oEvent);
				}
			});

			aTokens.push(oToken);

			// oFilterProvider.getFilterData().Gr103date.ranges.push(oRange);

			try {
				oFilterProvider.getFilterData()._CUSTOM.Gr103date.ranges.push(oRange);
			} catch (e) {
				oFilterProvider.setFilterData({
					_CUSTOM: {
						Gr103date: {
							ranges: [oRange]
						}
					}
				});
			}

			this.oInput.addToken(oToken);

			oVariant.currentVariantSetModified(true);
			this._oDateDialog.close();

		},

		/**
		 * @HJC for US DP 379 on 07.10.2019
		 * 
		 * @function: onBlankTokenDelete
		 * @description: Blank Date Token is deleted
		 * @param: 
		 */

		onBlankTokenDelete: function () {
			var oFilterProvider = this.getView().byId("idSmartOverviewCDS")._oFilterProvider;
			// var aGR103Range = oFilterProvider.getFilterData().Gr103date.ranges;
			var aGR103Range = oFilterProvider.getFilterData()._CUSTOM.Gr103date.ranges;

			for (var i = 0; i < aGR103Range.length; i++) {
				if (aGR103Range[i].value1 === null) {
					aGR103Range.pop(aGR103Range[i]);
				}
			}
		},

		/**
		 * @HJC for US DP 379 on 23.12.2019
		 * 
		 * @function: onVariantTokenDelete
		 * @description: 
		 * @param: 
		 */

		onVariantTokenDelete: function (oEvent) {
			var oToken = oEvent.getSource();
			var oFilterProvider = this.getView().byId("idSmartOverviewCDS")._oFilterProvider;
			var aGR103Range = oFilterProvider.getFilterData()._CUSTOM.Gr103date.ranges;

			for (var i = 0; i < aGR103Range.length; i++) {
				if (aGR103Range[i].tokenText === oToken.getText()) {
					aGR103Range.pop(aGR103Range[i]);
				}
			}
		},

		/**
		 * 
		 * 
		 * 
		 */
		onAfterRendering: function () {
			var oFilterBar = this.getView().byId("idSmartOverviewCDS");
			var aGroupItems = oFilterBar.getFilterGroupItems();

			for (var i = 0; i < aGroupItems.length; i++) {

				if (aGroupItems[i].getName() === "Materialnumber" || aGroupItems[i].getName() === "Materialdesription") {
					var oControl = aGroupItems[i].getControl();
					oControl.attachEvent("valueHelpRequest", function () {
						setTimeout(function () {
							var sControlName = oControl.getId().slice(oControl.getId().lastIndexOf("-") + 1);
							var sNewControlName;
							if (sControlName === "Materialnumber") {
								sNewControlName = "Materialdescription";
							} else {
								sNewControlName = "Materialnumber";
							}

							var sValueHelpId = oControl.getId() + "-valueHelpDialog";
							if (sap.ui.getCore().byId(sValueHelpId) !== undefined) {
								var oTable = sap.ui.getCore().byId(sValueHelpId).getContent()[0].getItems()[1].getItems()[1];
								oTable.setThreshold(1000);
							} else {
								sValueHelpId = sValueHelpId.replace(sControlName, sNewControlName);
								var oTable = sap.ui.getCore().byId(sValueHelpId).getContent()[0].getItems()[1].getItems()[1];
								oTable.setThreshold(1000);
							}

						}, 2000);
					});
				}
			}
		}

	});

});