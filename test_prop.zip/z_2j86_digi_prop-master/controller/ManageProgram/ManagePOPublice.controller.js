/*******************************************************************************
 * Project : Digital Propulsion Module : Functional document : ... Technical
 * document : ...
 * -------------------------------------------------------------------------------------------------------------------------------------
 * File name : ManagePOPublice.controller.js Written by : SOPARA Team Company :
 * Sopra Steria Creation date : 01.04.2019
 * --------------------------------------------------------------------------------------------------------------------------------------
 * File description : This controller contains the functions that are supposed
 * to be called inside several screens in the application
 * --------------------------------------------------------------------------------------------------------------------------------------
 * Last modification date : Author : Description : Transport order :
 ******************************************************************************/

sap.ui.define(["airbus/ui/digital_propulsion/controller/ManageProgram.controller",
		"sap/ui/model/Sorter", "sap/ui/model/Filter", "sap/ui/model/FilterOperator", "airbus/ui/digital_propulsion/util/Formatter",
		"airbus/ui/digital_propulsion/util/Utility"
	],
	function (ManageProgram, Sorter, Filter, FilterOperator, Formatter, Utility) {
		"use strict";

		return ManageProgram.extend("airbus.ui.digital_propulsion.controller.ManageProgram.ManagePOPublice", {

			formatter: Formatter,
			utility: Utility,

			onInit: function () {

				var oView = this.getView();
				var oModel = this.getOwnerComponent().getModel("digital");

				oView.setModel(oModel);

				jQuery.sap.setObject("airbus.global.digital.ManagePOPublice", this);
			},

			onBeforeBind: function (oEvent) {
				var mBindingParams = oEvent.getParameter("bindingParams");
				var oACModel = this.getView().getModel("aircraft");
				var sAircraft = "";
				// Note: This example is based on mock data, so defining the number of expended levels in the beforeRebindTable event should be avoided for
				// performance reasons.
				mBindingParams.parameters.numberOfExpandedLevels = 1;
				//Custom filter bind for Padlock
				var sPOPadLock = this.getView().byId("idPOpadlockPOP").getSelectedKey();
				var sChangePODelDate = this.getView().byId("idChangePODelDatePOP").getSelectedKey();
				var sChangeStatDate = this.getView().byId("idChangeStatDatePOP").getSelectedKey();
				var sChangeOption = this.getView().byId("idChangeOptionPOP").getSelectedKey();
				var sChangePricing = this.getView().byId("idChangePricingPOP").getSelectedKey();
				var sChangeFAL = this.getView().byId("idChangeFALPOP").getSelectedKey();
				var sChangeMSN = this.getView().byId("idChangeMSNPOP").getSelectedKey();

				var sSelectedProgram = jQuery.sap.getObject("airbus.ui.digital_propulsion.GLOBAL.Aircraft");
				switch (sSelectedProgram) {
				case "A320":
					sAircraft = oACModel.getProperty("/Type/A320"); // "N"
					break;
				case "A330":
					sAircraft = oACModel.getProperty("/Type/A330"); // "L"
					break;
				case "A350":
					sAircraft = oACModel.getProperty("/Type/A350"); // "P"
					break;
				case "A380":
					sAircraft = oACModel.getProperty("/Type/A380"); // "R"
					break;
				default:
					break;
				}

				mBindingParams.filters.push(new Filter({
					path: "Zprogram",
					operator: FilterOperator.EQ,
					value1: sAircraft
				}));

				var sStatpadlock = this.getView().byId("idStatpadlockPOP").getSelectedKey();

				//Custom filter bind for Padlock - US BLM 163 LEI 10.05.19
				if (sPOPadLock === "2") {
					mBindingParams.filters.push(new Filter({
						path: "POPadlock",
						operator: FilterOperator.EQ,
						value1: "lock"
					}));
				} else if (sPOPadLock === "3") {
					mBindingParams.filters.push(new Filter({
						path: "POPadlock",
						operator: FilterOperator.NE,
						value1: "lock"
					}));
				}

				if (sStatpadlock === "2") {
					mBindingParams.filters.push(new Filter({
						path: "Statpadlock",
						operator: FilterOperator.EQ,
						value1: "lock"
					}));
				} else if (sStatpadlock === "3") {
					mBindingParams.filters.push(new Filter({
						path: "Statpadlock",
						operator: FilterOperator.NE,
						value1: "lock"
					}));
				}

				//Custom filter bind for Deletion Indicator - US BLM 174 LEI 13.05.19
				var sDeletion = this.getView().byId("idDeletionIndicatorPOP").getSelectedKey();

				if (sDeletion === "2") {
					mBindingParams.filters.push(new Filter({
						path: "DeletionIndicator",
						operator: FilterOperator.EQ,
						value1: "Delete"
					}));
				} else if (sDeletion === "3") {
					mBindingParams.filters.push(new Filter({
						path: "DeletionIndicator",
						operator: FilterOperator.EQ,
						value1: "Change"
					}));
				} else if (sDeletion === "4") {
					mBindingParams.filters.push(new Filter({
						path: "DeletionIndicator",
						operator: FilterOperator.EQ,
						value1: "New"
					}));
				}

				//Added by SSH on 17-09-19
				//To add filter binding for six main change columns(DP-190)
				if (sChangePODelDate === "2") {
					mBindingParams.filters.push(new Filter({
						path: "ChangePODelDate",
						operator: FilterOperator.EQ,
						value1: "X"
					}));
				} else if (sChangePODelDate === "3") {
					mBindingParams.filters.push(new Filter({
						path: "ChangePODelDate",
						operator: FilterOperator.NE,
						value1: "X"
					}));
				}

				if (sChangeStatDate === "2") {
					mBindingParams.filters.push(new Filter({
						path: "ChangePOStatDate",
						operator: FilterOperator.EQ,
						value1: "X"
					}));
				} else if (sChangeStatDate === "3") {
					mBindingParams.filters.push(new Filter({
						path: "ChangePOStatDate",
						operator: FilterOperator.NE,
						value1: "X"
					}));
				}

				if (sChangeOption === "2") {
					mBindingParams.filters.push(new Filter({
						path: "ChangeOption",
						operator: FilterOperator.EQ,
						value1: "X"
					}));
				} else if (sChangeOption === "3") {
					mBindingParams.filters.push(new Filter({
						path: "ChangeOption",
						operator: FilterOperator.NE,
						value1: "X"
					}));
				}

				if (sChangePricing === "2") {
					mBindingParams.filters.push(new Filter({
						path: "ChangePricing",
						operator: FilterOperator.EQ,
						value1: "X"
					}));
				} else if (sChangePricing === "3") {
					mBindingParams.filters.push(new Filter({
						path: "ChangePricing",
						operator: FilterOperator.NE,
						value1: "X"
					}));
				}

				if (sChangeFAL === "2") {
					mBindingParams.filters.push(new Filter({
						path: "ChangeFAL",
						operator: FilterOperator.EQ,
						value1: "X"
					}));
				} else if (sChangeFAL === "3") {
					mBindingParams.filters.push(new Filter({
						path: "ChangeFAL",
						operator: FilterOperator.NE,
						value1: "X"
					}));
				}

				if (sChangeMSN === "2") {
					mBindingParams.filters.push(new Filter({
						path: "ChangeMSN",
						operator: FilterOperator.EQ,
						value1: "X"
					}));
				} else if (sChangeMSN === "3") {
					mBindingParams.filters.push(new Filter({
						path: "ChangeMSN",
						operator: FilterOperator.NE,
						value1: "X"
					}));
				}

				// Default sorting with PO Number
				var oSorter = new Sorter({
					path: 'Ponumber',
					descending: false,
					group: function (oContext) {
						return oContext.getProperty('Ponumber');
					}

				});

				// Added by HJC on 26.06.2019 for Sorting default by Po Item
				var oSorterItem = new Sorter({
					path: 'Poitem',
					descending: false,
					group: function (oContext) {
						return oContext.getProperty('Poitem');
					}

				});

				if (!mBindingParams.sorter.length) {
					mBindingParams.sorter.push(oSorter);
					mBindingParams.sorter.push(oSorterItem);
				} else {
					var aSorters = mBindingParams.sorter;
					var sIndicator = "0";

					for (var j in aSorters) {
						if (aSorters[j].sPath === "Ponumber" || aSorters[j].sPath === "Poitem") {
							sIndicator = "1";
						}
					}

					if (sIndicator === "0") {
						mBindingParams.sorter.push(oSorter);
						mBindingParams.sorter.push(oSorterItem);
					}
				}

			},

			/**
			 * @HJC for US BLM 87 on 13.05.2019
			 * 
			 * @function: onPressOk
			 * @description: On PO Comment Save 
			 * @param: 
			 */

			onPressOk: function () {
				this.onPressCancel();
			},

			/**
			 * @HJC for US BLM 87 on 13.05.2019
			 * 
			 * @function: onPressCancel
			 * @description: On PO Comment Cancel Press 
			 * @param: 
			 */

			onPressCancel: function () {
				if (this._oPOCommentDialog) {
					this._oPOCommentDialog.close();
				}

				if (this._oPOChangeDesDialog) {
					this._oPOChangeDesDialog.close();
				}
			},

			/**
			 * @HJC for US BLM 164 on 15.05.2019
			 * 
			 * @function: onRowSelect
			 * @description: Manage selection of one or more PO's for Po Publication 
			 * @param:
			 */

			onRowSelect: function (oEvent) {
				var i;
				try {
					var oSource = oEvent.getSource();
					var bMultiSelect = oEvent.getParameter('selectAll');
					var oContext = oEvent.getParameter('rowContext');
					var oModel = oSource.getBinding().getModel();

					var bSelect;
					var aRows = oEvent.getParameter('rowIndices');
					var sRowIndex = oEvent.getParameter('rowIndex');

					// if all rows has been ticked
					if (bMultiSelect) {
						bSelect = 'X';
					}
					// if all rows has been unticked
					else if (!bMultiSelect && sRowIndex === -1) {
						bSelect = '';
					}
					// if only one row has been ticked/unticked
					else if (!bMultiSelect && oContext) {
						if (oSource.getSelectedIndices().indexOf(sRowIndex) > -1) {
							bSelect = 'X';

							// Added by HJC for All PO Item Selection on 04.06.2019 (Commented on 20.06.2019)

							// var sSelectedPO = oModel.getProperty(oContext.sPath).Ponumber;
							// var aItems = oSource.getRows();
							// var aItemsKeys = oSource.getBinding("rows").aKeys
							// var aSameItemIndex = [];

							// for (var i = 0; i < aItems.length; i++) {
							// 	if(oSource.getRows()[i].getBindingContext()){
							// 		var sItemPO = oModel.getProperty(oSource.getRows()[i].getBindingContext().sPath).Ponumber;
							// 	var sItem = oModel.getProperty(oSource.getRows()[i].getBindingContext().sPath).Poitem;
							// 	if (sSelectedPO === sItemPO) {
							// 		var sKey = "ETPOPublishSet(Ponumber='" + sItemPO + "',Poitem='" + sItem + "')"
							// 		aSameItemIndex.push(aItemsKeys.indexOf(sKey));
							// 	}
							// 	}

							// }
							// oSource.addSelectionInterval(aSameItemIndex[0],aSameItemIndex[aSameItemIndex.length - 1]);
						} else {
							bSelect = '';
						}
					}
					// loop on all rows to modify and update model with
					// selection/unselection
					for (i = 0; i < aRows.length; i++) {
						oModel.setProperty(oSource.getContextByIndex(aRows[i]).getPath() + "/POMassPublish", bSelect);
					}
				} catch (e) {
					// TODO: handle exception
				}

			},

			/**
			 * @HJC for US BLM 307 on 23.07.2019
			 * 
			 * @function: onVariantLoad
			 * @description: Manage Custom fields when Varient is Loaded
			 * @param: 
			 */

			onVariantLoad: function (oEvent) {
				var oSource = oEvent.getSource();
				var oCustomData = oSource.getFilterData(true)["_CUSTOM"];
				if (oCustomData) {
					this.getView().byId("idPOpadlockPOP").setSelectedKey(oCustomData.POPadlock);
					this.getView().byId("idStatpadlockPOP").setSelectedKey(oCustomData.Statpadlock);
					this.getView().byId("idDeletionIndicatorPOP").setSelectedKey(oCustomData.DeletionIndicator);
				} else {
					this.getView().byId("idPOpadlockPOP").setSelectedKey("1");
					this.getView().byId("idStatpadlockPOP").setSelectedKey("1");
					this.getView().byId("idDeletionIndicatorPOP").setSelectedKey("1");
				}
			},

			/**
			 * @HJC for US BLM 307 on 23.07.2019
			 * 
			 * @function: onVariantSave
			 * @description: Manage Custom fields when Varient is Saved
			 * @param: 
			 */

			onVariantSave: function (oEvent) {
				var oSource = oEvent.getSource();
				var sPOPadlock = this.getView().byId("idPOpadlockPOP").getSelectedKey();
				var sStatpadlock = this.getView().byId("idStatpadlockPOP").getSelectedKey();
				var sDeletionIndicator = this.getView().byId("idDeletionIndicatorPOP").getSelectedKey();

				oSource.setFilterData({
					_CUSTOM: {
						POPadlock: sPOPadlock,
						Statpadlock: sStatpadlock,
						DeletionIndicator: sDeletionIndicator
					}
				});
			},

			/**
			 * @SSH for US DP 338 on 17.09.2019
			 * 
			 * @function: onClearPOPFilter
			 * @description: Clear custom filters and variant on click of 'Clear'.
			 * @param: 
			 */
			onClearPOPFilter: function (oEvent) {
				//Custom filter clearance
				this.getView().byId("idPOpadlockPOP").setSelectedKey("");
				this.getView().byId("idStatpadlockPOP").setSelectedKey("");
				this.getView().byId("idDeletionIndicatorPOP").setSelectedKey("");
				this.getView().byId("idChangePODelDatePOP").setSelectedKey("");
				this.getView().byId("idChangeStatDatePOP").setSelectedKey("");
				this.getView().byId("idChangeOptionPOP").setSelectedKey("");
				this.getView().byId("idChangePricingPOP").setSelectedKey("");
				this.getView().byId("idChangeFALPOP").setSelectedKey("");
				this.getView().byId("idChangeMSNPOP").setSelectedKey("");

				//Variant de-selection
				this.getView().byId("idSmartPOPublic").clearVariantSelection();
			},

			/**
			 * 
			 * 
			 * 
			 */
			onAfterRendering: function () {
				var oFilterBar = this.getView().byId("idSmartPOPublic");
				var aGroupItems = oFilterBar.getFilterGroupItems();

				for (var i = 0; i < aGroupItems.length; i++) {

					if (aGroupItems[i].getName() === "Materialnumber" || aGroupItems[i].getName() === "Materialdesription") {
						var oControl = aGroupItems[i].getControl();
						oControl.attachEvent("valueHelpRequest", function () {
							setTimeout(function () {
								var sControlName = oControl.getId().slice(oControl.getId().lastIndexOf("-") + 1);
								var sNewControlName;
								if (sControlName === "Materialnumber") {
									sNewControlName = "Materialdesription";
								} else {
									sNewControlName = "Materialnumber";
								}

								var sValueHelpId = oControl.getId() + "-valueHelpDialog";
								if (sap.ui.getCore().byId(sValueHelpId) !== undefined) {
									var oTable = sap.ui.getCore().byId(sValueHelpId).getContent()[0].getItems()[1].getItems()[1];
									oTable.setThreshold(1000);
								} else {
									sValueHelpId = sValueHelpId.replace(sControlName, sNewControlName);
									var oTable = sap.ui.getCore().byId(sValueHelpId).getContent()[0].getItems()[1].getItems()[1];
									oTable.setThreshold(1000);
								}

							}, 2000);
						});
					}
				}
			}

		});

	});