/*******************************************************************************
 * Project : Digital Propulsion Module : Functional document : ... Technical
 * document : ...
 * -------------------------------------------------------------------------------------------------------------------------------------
 * File name : ManageCreatePO.controller.js Written by : SOPARA Team Company :
 * Sopra Steria Creation date : 01.04.2019
 * --------------------------------------------------------------------------------------------------------------------------------------
 * File description : This controller contains the functions that are supposed
 * to be called inside several screens in the application
 * --------------------------------------------------------------------------------------------------------------------------------------
 * Last modification date : Author : Description : Transport order :
 ******************************************************************************/

sap.ui.define(["airbus/ui/digital_propulsion/controller/ManageProgram.controller",
		"sap/ui/model/Sorter", "sap/ui/model/Filter", "sap/ui/model/FilterOperator", "airbus/ui/digital_propulsion/util/Formatter"
	],
	function (ManageProgram, Sorter, Filter, FilterOperator, Formatter) {
		"use strict";

		return ManageProgram.extend("airbus.ui.digital_propulsion.controller.ManageProgram.POUpdate", {

			formatter: Formatter,

			onInit: function () {

				var oView = this.getView();
				var oModel = this.getOwnerComponent().getModel("digital");

				oView.setModel(oModel);

				jQuery.sap.setObject("airbus.global.digital.ManageCreatePO", this);
			},

			/**
			 * @function: onBeforeBind
			 * @description: Before the binding of smart Table happen
			 * @HJC on 17.12.2018 for US RSK5
			 */
			onBeforeBind: function (oEvent) {
				var mBindingParams = oEvent.getParameter("bindingParams");
				var oACModel = this.getView().getModel("aircraft");
				var sAircraft = "";
				//Custom filter bind for Padlocks
				//@SSH on 04.04.2019 for US-106
				var sPOPadLock = this.getView().byId("idPOpadlock").getSelectedKey();
				var sPRPadLock = this.getView().byId("idPrpadlock").getSelectedKey();
				var sStatPadLock = this.getView().byId("idStatpadlock").getSelectedKey();
				//Custom filter bind for Padlocks

				//Custom filter for Update Indicator
				var sUpdateIndicator = this.getView().byId("idUpdateIndicator").getSelectedKey();
				var sPOUComment = this.getView().byId("idPreqComment").getSelectedKey();

				var sSelectedProgram = jQuery.sap.getObject("airbus.ui.digital_propulsion.GLOBAL.Aircraft");
				switch (sSelectedProgram) {
				case "A320":
					sAircraft = oACModel.getProperty("/Type/A320"); // "N"
					break;
				case "A330":
					sAircraft = oACModel.getProperty("/Type/A330"); // "L"
					break;
				case "A350":
					sAircraft = oACModel.getProperty("/Type/A350"); // "P"
					break;
				case "A380":
					sAircraft = oACModel.getProperty("/Type/A380"); // "R"
					break;
				default:
					break;
				}

				mBindingParams.filters.push(new Filter({
					path: "Zprogram",
					operator: FilterOperator.EQ,
					value1: sAircraft
				}));

				//Custom filter bind for Padlocks
				//@SSH on 04.04.2019 for US-106
				if (sPOPadLock === "2") {
					mBindingParams.filters.push(new Filter({
						path: "Popadlock",
						operator: FilterOperator.EQ,
						value1: "lock" // updated by LEI on 09.05.2019 to get good label for padlock in excell export 
					}));
				} else if (sPOPadLock === "3") {
					mBindingParams.filters.push(new Filter({
						path: "Popadlock",
						operator: FilterOperator.NE,
						value1: "lock" // updated by LEI on 09.05.2019 to get good label for padlock in excell export 
					}));
				}

				if (sPRPadLock === "2") {
					mBindingParams.filters.push(new Filter({
						path: "Prpadlock",
						operator: FilterOperator.EQ,
						value1: "lock" // updated by LEI on 09.05.2019 to get good label for padlock in excell export 
					}));
				} else if (sPRPadLock === "3") {
					mBindingParams.filters.push(new Filter({
						path: "Prpadlock",
						operator: FilterOperator.NE,
						value1: "lock" // updated by LEI on 09.05.2019 to get good label for padlock in excell export 
					}));
				}

				if (sStatPadLock === "2") {
					mBindingParams.filters.push(new Filter({
						path: "Statpadlock",
						operator: FilterOperator.EQ,
						value1: "lock" // updated by LEI on 09.05.2019 to get good label for padlock in excell export 
					}));
				} else if (sStatPadLock === "3") {
					mBindingParams.filters.push(new Filter({
						path: "Statpadlock",
						operator: FilterOperator.NE,
						value1: "lock" // updated by LEI on 09.05.2019 to get good label for padlock in excell export 
					}));
				}
				//Custom filter bind for Padlocks

				//Custom filter for Update Indicator
				//@SSH on 09.04.2019 for US-106
				if (sUpdateIndicator === "2") {
					mBindingParams.filters.push(new Filter({
						path: "Updateindicator",
						operator: FilterOperator.EQ,
						value1: "Upd"
					}));

				} else if (sUpdateIndicator === "3") {
					mBindingParams.filters.push(new Filter({
						path: "Updateindicator",
						operator: FilterOperator.EQ,
						value1: "Del"
					}));
				} else if (sUpdateIndicator === "4") {
					mBindingParams.filters.push(new Filter({
						path: "Updateindicator",
						operator: FilterOperator.EQ,
						value1: "Crt"
					}));
				}

				// Filter on PO Comment Y/N
				if (sPOUComment === "2") {
					mBindingParams.filters.push(new Filter({
						path: "Ispreqcomment",
						operator: FilterOperator.EQ,
						value1: 'Yes'
					}));
				} else if (sPOUComment === "3") {
					mBindingParams.filters.push(new Filter({
						path: "Ispreqcomment",
						operator: FilterOperator.EQ,
						value1: 'No'
					}));
				}

			},

			/**
			 * @function: onRowSelect
			 * @description: When user Selects a row for PO update
			 * 
			 */

			onRowSelect: function (oEvent) {
				var i;
				try {
					var oSource = oEvent.getSource();
					var bMultiSelect = oEvent.getParameter('selectAll');
					var oContext = oEvent.getParameter('rowContext');
					var oModel = oSource.getBinding().getModel();
					var bSelect;
					var aRows = oEvent.getParameter('rowIndices');
					var sRowIndex = oEvent.getParameter('rowIndex');

					// if all rows has been ticked
					if (bMultiSelect) {
						bSelect = 'X';
					}
					// if all rows has been unticked
					else if (!bMultiSelect && sRowIndex === -1) {
						bSelect = '';
					}
					// if only one row has been ticked/unticked
					else if (!bMultiSelect && oContext) {
						if (oSource.getSelectedIndices().indexOf(sRowIndex) > -1) {
							bSelect = 'X';
						} else {
							bSelect = '';
						}
					}
					// loop on all rows to modify and update model with
					// selection/unselection
					for (i = 0; i < aRows.length; i++) {
						oModel.setProperty(oSource.getContextByIndex(aRows[i]).getPath() + "/ActionType", bSelect);
					}
				} catch (e) {
					// TODO: handle exception
				}

			},

			/**
			 * @HJC for US BLM 307 on 23.07.2019
			 * 
			 * @function: onVariantLoad
			 * @description: Manage Custom fields when Varient is Loaded
			 * @param: 
			 */

			onVariantLoad: function (oEvent) {
				var oSource = oEvent.getSource();
				var oCustomData = oSource.getFilterData(true)["_CUSTOM"];
				if (oCustomData) {
					this.getView().byId("idPOpadlock").setSelectedKey(oCustomData.Popadlock);
					this.getView().byId("idPrpadlock").setSelectedKey(oCustomData.Prpadlock);
					this.getView().byId("idStatpadlock").setSelectedKey(oCustomData.Statpadlock);
					this.getView().byId("idUpdateIndicator").setSelectedKey(oCustomData.Updateindicator);
				} else {
					this.getView().byId("idPOpadlock").setSelectedKey("1");
					this.getView().byId("idPrpadlock").setSelectedKey("1");
					this.getView().byId("idStatpadlock").setSelectedKey("1");
					this.getView().byId("idUpdateIndicator").setSelectedKey("1");
				}
			},

			/**
			 * @HJC for US BLM 307 on 23.07.2019
			 * 
			 * @function: onVariantSave
			 * @description: Manage Custom fields when Varient is Saved
			 * @param: 
			 */

			onVariantSave: function (oEvent) {
				var oSource = oEvent.getSource();
				var sPOPadLock = this.getView().byId("idPOpadlock").getSelectedKey();
				var sPRPadLock = this.getView().byId("idPrpadlock").getSelectedKey();
				var sStatPadLock = this.getView().byId("idStatpadlock").getSelectedKey();
				var sUpdateIndicator = this.getView().byId("idUpdateIndicator").getSelectedKey();

				oSource.setFilterData({
					_CUSTOM: {
						Updateindicator: sUpdateIndicator,
						Popadlock: sPOPadLock,
						Prpadlock: sPRPadLock,
						Statpadlock: sStatPadLock
					}
				});
			},

			/**
			 * @SSH for US DP 338 on 17.09.2019
			 * 
			 * @function: onClearPOUFilter
			 * @description: Clear custom filters and variant on click of 'Clear'.
			 * @param: 
			 */
			onClearPOUFilter: function (oEvent) {
				//Variant clearance
				this.getView().byId("idSmartPOUpdate").clearVariantSelection();

				//Custom filter clearance
				this.getView().byId("idPOpadlock").setSelectedKey("");
				this.getView().byId("idPrpadlock").setSelectedKey("");
				this.getView().byId("idStatpadlock").setSelectedKey("");
				this.getView().byId("idUpdateIndicator").setSelectedKey("");
				this.getView().byId("idPreqComment").setSelectedKey("");

			},

			/**
			 * @SSH for US BLM 390 on 21.10.2019
			 * 
			 * @function: onCommentMorePress
			 * @description: Open dialog to manage the comment
			 * @param: 
			 */

			onCommentMorePress: function (oEvent) {

				var oSource = oEvent.getSource();
				var oText = oSource.getParent().getItems()[0];
				this._sPOCommentBindingPath = oText.getBindingContext().sPath;

				if (!this._oPOUCommentDialog) {
					this._oPOUCommentDialog = sap.ui.xmlfragment("airbus.ui.digital_propulsion.fragment.GRValidationComment", this);
					this.getView().addDependent(this._oPOUCommentDialog);
				}

				this._oPOUCommentDialog.bindElement({
					path: this._sPOCommentBindingPath
				});

				this._oPOUCommentDialog.open();

			},

			/**
			 * @SSH for US BLM 390 on 21.10.2019
			 * 
			 * @function: onCommentUpdate
			 * @description: When user add comments
			 * @param: 
			 */

			onCommentUpdate: function (oEvent) {

				var oSource = oEvent.getSource();
				var oIcon = oSource.getParent().getItems()[1];

				if (oSource.getValue().length > 0) {
					oIcon.setVisible(true);
				} else {
					oIcon.setVisible(false);
				}

			},

			/**
			 * @SSH for US BLM 390 on 21.10.2019
			 * 
			 * @function: onPressOk
			 * @description: On PO Comment Save
			 * @param: 
			 */

			onPressOk: function () {
				this.onPressCancel();
			},

			/**
			 * @SSH for US BLM 390 on 21.10.2019
			 * 
			 * @function: onPressCancel
			 * @description: On PO Comment Cancel Press
			 * @param: 
			 */

			onPressCancel: function () {
				if (this._oPOUCommentDialog) {
					this._oPOUCommentDialog.close();
				}
			}

		});

	});