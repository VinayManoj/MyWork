/**************************************************************************************************************************************
* Project                : Digital Propulsion              
* Module                 :                                                                                        
* Functional document    : ...                                
* Technical document     : ...                                    
*-------------------------------------------------------------------------------------------------------------------------------------
* File name              : Home.controller.js                             
* Written by             : SOPARA Team                                       
* Company                : Sopra Steria                                                
* Creation date          : 13.11.2018                                            
*--------------------------------------------------------------------------------------------------------------------------------------
* File description       : This controller contains the functions that are supposed to be called inside several screens in the application
*--------------------------------------------------------------------------------------------------------------------------------------
* Last modification date :                                     
* Author                 :                                                           
* Description            :                                                                                                       
* Transport order        :                                                                          
***************************************************************************************************************************************/


sap.ui.define([
	"airbus/ui/digital_propulsion/controller/BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("airbus.ui.digital_propulsion.controller.HomePage", {
		
		onTilePress : function(){
			var oRouter = this.getRouter();
			oRouter.navTo("manageProgram");
		}

	});

});