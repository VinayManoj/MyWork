/**************************************************************************************************************************************
* Project                : Digital Propulsion              
* Module                 :                                                                                        
* Functional document    : ...                                
* Technical document     : ...                                    
*-------------------------------------------------------------------------------------------------------------------------------------
* File name              : Base.controller.js                             
* Written by             : SOPARA Team                                       
* Company                : Sopra Steria                                                
* Creation date          : 13.11.2018                                            
*--------------------------------------------------------------------------------------------------------------------------------------
* File description       : This controller contains the functions that are supposed to be called inside several screens in the application
*--------------------------------------------------------------------------------------------------------------------------------------
* Last modification date :                                     
* Author                 :                                                           
* Description            :                                                                                                       
* Transport order        :                                                                          
***************************************************************************************************************************************/

sap.ui.define([ "sap/ui/core/mvc/Controller", "sap/ui/core/routing/History"], function(Controller, History) {
	"use strict";
	return Controller.extend("airbus.ui.digital_propulsion.controller.BaseController", {
		
		
		/**
		 * Convenience method for accessing the router in every controller of
		 * the application.
		 * 
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter : function() {
			return this.getOwnerComponent().getRouter();
		},

		/**
		 * Convenience method for getting the view model by name in every
		 * controller of the application.
		 * 
		 * @public
		 * @param {string}
		 *            sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel : function(sName) {
			return this.getView().getModel(sName);
		},
		
		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle : function () {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the master route.
		 * @public
		 */
		onNavBack : function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("home");
			}
		}
	});
});