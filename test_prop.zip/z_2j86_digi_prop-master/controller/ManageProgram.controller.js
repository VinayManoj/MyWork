/*******************************************************************************
 * Project : Digital Propulsion Module : Functional document : ... Technical
 * document : ...
 * -------------------------------------------------------------------------------------------------------------------------------------
 * File name : ManageProgram.controller.js Written by : SOPARA Team Company :
 * Sopra Steria Creation date : 13.11.2018
 * --------------------------------------------------------------------------------------------------------------------------------------
 * File description : This controller contains the functions that are supposed
 * to be called inside several screens in the application
 * --------------------------------------------------------------------------------------------------------------------------------------
 * Last modification date : Author : Description : Transport order :
 ******************************************************************************/

sap.ui.define(["airbus/ui/digital_propulsion/controller/BaseController", 'sap/ui/model/json/JSONModel', "sap/m/MessageBox",
		"airbus/ui/digital_propulsion/util/Formatter", "airbus/ui/digital_propulsion/util/Utility"
	],
	function (BaseController, JSONModel, MessageBox, Formatter, Utility) {

		"use strict";

		return BaseController.extend("airbus.ui.digital_propulsion.controller.ManageProgram", {

			formatter: Formatter,
			utility: Utility,

			/**
			 * 
			 * 
			 */
			onInit: function () {
				// var oView = this.getView();
				// var oModel = this.getOwnerComponent().getModel("digital");

				// Set the controller inside a global variable
				jQuery.sap.setObject("airbus.global.digital.ManageProgram", this);

				var oRouter = this.getOwnerComponent().getRouter();
				oRouter.getRoute("manageProgram").attachPatternMatched(this.onRouteMatched, this);

			},

			/**
			 * 
			 * 
			 * 
			 */
			onRouteMatched: function () {

				// Bind IconTab counters depending on the Aircraft type selected
				var sAircraftType = jQuery.sap.getObject("airbus.ui.digital_propulsion.GLOBAL.Aircraft");

				// var oOverviewTab = this.getView().byId("idMyOverviewCDS");
				// oOverviewTab.bindElement("userAction>/ETUserActionSet('myId')");

				var oPOCreateTab = this.getView().byId("idManageCreatePOCDS");
				oPOCreateTab.bindElement("digital>/ETTabCountSet(Actype='" + sAircraftType + "',Tab='01')");
				// oPOCreateTab.bindElement("userAction>/ETUserActionSet('myId')");

				var oGRValidateTab = this.getView().byId("idManageGRVal");
				oGRValidateTab.bindElement("digital>/ETTabCountSet(Actype='" + sAircraftType + "',Tab='02')");
				// oGRValidateTab.bindElement("userAction>/ETUserActionSet('myId')");

				var oPOScheduleTab = this.getView().byId("idManagePOsched");
				oPOScheduleTab.bindElement("digital>/ETTabCountSet(Actype='" + sAircraftType + "',Tab='03')");
				// oPOScheduleTab.bindElement("userAction>/ETUserActionSet('myId')");

				// Commented to preserve count binding 
				// var oPOUpdateTab = this.getView().byId("idIconTabFiltePOUpdate");
				// oPOScheduleTab.bindElement("digital>/ETTabCountSet(Actype='" + sAircraftType + "',Tab='04')");
				// oPOScheduleTab.bindElement("userAction>/ETUserActionSet('myId')");

				//PO Count for PO Publication US-153
				var oPOPublishTab = this.getView().byId("idManagePOPublice");
				oPOPublishTab.bindElement("digital>/ETTabCountSet(Actype='" + sAircraftType + "',Tab='05')");
				// oPOPublishTab.bindElement("userAction>/ETUserActionSet('myId')");

				var oGRCancelTab = this.getView().byId("idManageGRCancel");
				oGRCancelTab.bindElement("digital>/ETTabCountSet(Actype='" + sAircraftType + "',Tab='06')");
				// oGRCancelTab.bindElement("userAction>/ETUserActionSet('myId')");

				//initialize fragment for po creation popover
				this.oPOCreationPopover = sap.ui.xmlfragment('airbus.ui.digital_propulsion.fragment.PO_Creation_PopUp', this);
				this.getView().addDependent(this.oPOCreationPopover);
				
				/** Logic added by NG5F639 to fix the xFU upgrade related issue - 19/12/2022 **/
				this.getOwnerComponent().getService("ShellUIService").then(
					// promise is returned
					function (oService) {
						oService.setTitle(jQuery.sap.getObject("airbus.ui.digital_propulsion.GLOBAL.Aircraft"));
						// oService.setTitle(airbus.ui.digital_propulsion.GLOBAL.Aircraft);
					}, function (oError) {
						// in this case let initial title defined in i18n files
					});

			},

			/**
			 * @function: onPOCreate
			 * @description: Trigger PO Creation
			 * @KSD for BLM_10
			 */
			onPOCreate: function () {
				var that = this;
				var oi18n = this.getView().getModel("i18n");
				this.managePOCreate = jQuery.sap.getObject("airbus.global.digital.ManageCreatePO");
				var oModel = this.getModel("digital");

				if (oModel.hasPendingChanges()) {
					// only submit Changes for entity PO Creation
					oModel.submitChanges({
						groupId: "POCreation",
						success: function (oData, oRes) {

							// Commented by HJC on 02.05.2019
							// 							try {
							// 								that.managePOCreate.byId("idSmartCreatePOTableCDS").getTable().setSelectedIndex(-1);
							// 							}
							// 							catch (e) {
							// //								that.managePOCreate.byId("idSmartCreatePOTable").getTable().setSelectedIndex(-1);
							// 							}
							// update icontabfilter
							// count
							that.getView().byId("idManageCreatePOCDS").getContent()[0].byId("idSmartCreatePOTableCDS").getTable().setSelectedIndex(-1);
							that.getView().byId("idManageCreatePOCDS").getElementBinding("digital").refresh();
							that.managePOCreateResponse(oData, oRes);
						},
						error: function () {
							sap.m.MessageToast.show(oi18n.getProperty("Error"));
						}
					});
				} else {
					sap.m.MessageToast.show(oi18n.getProperty("manageCreatePO.noSelected"));
				}

			},

			/**
			 * @function: managePOCreateResponse
			 * @description: manage success and error messages after PO Creation
			 * @KSD for BLM_10
			 * 
			 */
			managePOCreateResponse: function managePOCreateResponse(oData, oRes) {
				var sBatchLength, sChangeRespLength, i, j, aChangesResp = [],
					aMessages = [],
					oMessage;
				var oView = this.getView();

				// if there is a batch response, we loop on
				// responses and get the
				// list of changes done
				if (oData.__batchResponses) {
					sBatchLength = oData.__batchResponses.length;
					for (i = 0; i < sBatchLength; i++) {
						if (oData.__batchResponses[i].__changeResponses) {
							aChangesResp = aChangesResp.concat(oData.__batchResponses[i].__changeResponses);
						}
					}
					// if list of changes done is not empty,
					// loop on it to retrieve
					// all information about PO Creation
					if (aChangesResp.length > -1) {
						sChangeRespLength = aChangesResp.length;
						for (j = 0; j < sChangeRespLength; j++) {
							oMessage = this.retrievePOCreationMessages(aChangesResp[j]);
							aMessages = oMessage ? aMessages.concat(oMessage) : aMessages;
						}
					}

					// update JSON Model of Message Popover
					// with new informations

					var oModel = new JSONModel();
					oModel.setData(aMessages);
					this.oPOCreationPopover.setModel(oModel, "POCreation");
					oView.byId("idMessageCreatePO").setText(aMessages.length + "");
					this.oPOCreationPopover.toggle(this.getView().byId('idMessageCreatePO'));

				}

			},

			/**
			 * @function: retrievePOCreationMessages
			 * @description: ..............
			 * @KSD for BLM_10
			 * 
			 */
			retrievePOCreationMessages: function retrievePOCreationMessages(oChangesResp) {
				var oFirstLevel, oSecondLevel, aMessages = [],
					sDetailLength, i;
				var oMessage = {
					type: '',
					title: ''
				};

				// try to add first level message if
				// oChangesResp is for PO Creation
				// or second level
				try {
					oFirstLevel = JSON.parse(oChangesResp.headers["sap-message"]);
					if (oFirstLevel.target === "PO Creation" || oFirstLevel.target === "GR Validation" || oFirstLevel.target === "PO Scheduling" ||
						oFirstLevel.target === "PO Update" || oFirstLevel.target === "PO Publication" || oFirstLevel.target === "GR Cancellation" ||
						oFirstLevel.target === "PO Cancel") {
						switch (oFirstLevel.severity) {
						case 'error':
							oMessage.type = 'Error';
							break;
						case 'info':
							oMessage.type = 'Success';
							break;
						case 'warning':
							oMessage.type = 'Warning';
							break;

						default:
							oMessage.type = 'Information';
							break;
						}
						oMessage.title = oFirstLevel.message;
						aMessages = aMessages.concat(oMessage);
					}
				} catch (e) {
					// in the case of second level, message
					// is not in the header but
					// directly in property message
					if (oChangesResp.message && (oChangesResp.target === "PO Creation" || oChangesResp.target === "GR Validation" || oChangesResp.target ===
							"PO Scheduling" || oChangesResp.target === "PO Update" || oChangesResp.target === "PO Publication" || oChangesResp.target ===
							"GR Cancellation" || oChangesResp.target === "PO Cancel")) {
						switch (oChangesResp.severity) {
						case 'error':
							oMessage.type = 'Error';
							break;
						case 'info':
							oMessage.type = 'Success';
							break;
						case 'warning':
							oMessage.type = 'Warning';
							break;
						default:
							oMessage.type = 'Information';
							break;
						}
						oMessage.title = oChangesResp.message;
						return oMessage;
					} else {
						// if error not coming from
						// level issue, exit the
						// function
						// with no data
						return;
					}
				}

				// if First level is ok, check if there are
				// other levels into
				// the response
				if (!oFirstLevel.details) {
					return aMessages;
				}
				sDetailLength = oFirstLevel.details.length;
				if (sDetailLength > -1) {
					for (i = 0; i < sDetailLength; i++) {
						aMessages = aMessages.concat(this.retrievePOCreationMessages(oFirstLevel.details[i]));
					}
				}

				return aMessages;
			},

			/**
			 * @function: onSelectIconTab
			 * @description: Manage different action on selection of Tab
			 * @HJC
			 */

			onSelectIconTab: function (oEvent) {
				var oView = this.getView();

				// var oSource = oEvent.getSource();
				var oParameters = oEvent.getParameters();
				var sSelected = oParameters.selectedKey;

				// change actionType JSON model according to the tab selected
				var oActionModel = oView.getModel('actionType');
				var aTabs = oActionModel.getData()["iconTabBar"][0];
				for (var property in aTabs) {
					if (sSelected === property) {
						oActionModel.setProperty("/iconTabBar/0/" + property, true);
					} else {
						oActionModel.setProperty("/iconTabBar/0/" + property, false);
					}
				}

			},

			/**
			 * @function: onInfoMessageBoxPress
			 * @description: Information Bubble for Create PO, GR Validation,
			 *               Schedule PO
			 * @HJC for BLM_101
			 */
			onInfoMessageBoxPress: function () {
				var oi18n = this.getView().getModel("i18n");
				var oActionType = this.getView().getModel("actionType");

				if (oActionType.getProperty("/iconTabBar/0/POCreation")) {
					MessageBox.information(oi18n.getProperty("manageCreatePO.information"));
				} else if (oActionType.getProperty("/iconTabBar/0/GRValidation")) {
					MessageBox.information(oi18n.getProperty("manageValidateGR.information"));
				} else if (oActionType.getProperty("/iconTabBar/0/POScheduling")) {
					MessageBox.information(oi18n.getProperty("POSchedule.information"));
				}
				//Added Information Bubble for Update PO
				//@SSH on 02.04.2019 for BLM-121
				else if (oActionType.getProperty("/iconTabBar/0/POUpdate")) {
					MessageBox.information(oi18n.getProperty("POUpdate.information"));
				}
				//Added Information Bubble for PO Publication
				//@SSH on 01.05.2019 for BLM-168
				else if (oActionType.getProperty("/iconTabBar/0/POPublication")) {
					MessageBox.information(oi18n.getProperty("POPublic.information"));
				}

			},

			/**
			 * @function: handleMessagePopoverPress
			 * @description: ..............
			 * @KSD for BLM_10
			 * 
			 */
			handleMessagePopoverPress: function handleMessagePopoverPress(oEvent) {
				// open popover
				this.oPOCreationPopover.toggle(oEvent.getSource());
			},

			/**
			 * @function: onMessageDownload
			 * @description: Export PO Cration Message
			 * @HJC for BLM_9 on 17.01.2019 and BLM 68 on 28.02.2019
			 * 
			 */
			onMessageDownload: function () {
				var oModel = this.oPOCreationPopover.getModel("POCreation");
				var oActionModel = this.getView().getModel('actionType');
				var oi18n = this.getView().getModel("i18n");
				var aMessages = [],
					aColumns;
				var sDocTitle = "";

				if (oActionModel.getProperty("/iconTabBar/0/POCreation")) {

					sDocTitle = oi18n.getProperty("manageCreatePO.fileName");
					aMessages = this.utility.getMessageExcelData(oModel, oi18n, "POC");
					aColumns = this.utility.getMessageExcelColumns("POC");
				} else if (oActionModel.getProperty("/iconTabBar/0/GRValidation")) {

					sDocTitle = oi18n.getProperty("GRValidation.fileName");
					aMessages = this.utility.getMessageExcelData(oModel, oi18n, "GRV");
					aColumns = this.utility.getMessageExcelColumns("GRV");
				} else if (oActionModel.getProperty("/iconTabBar/0/POScheduling")) {

					sDocTitle = oi18n.getProperty("POSchedule.fileName");
					aMessages = this.utility.getMessageExcelData(oModel, oi18n, "POS");
					aColumns = this.utility.getMessageExcelColumns("POS");
				}
				//Added Message download functionality for PO Update
				//@SSH on 12.04.2019 for BLM-118
				else if (oActionModel.getProperty("/iconTabBar/0/POUpdate")) {

					sDocTitle = oi18n.getProperty("POUpdate.fileName");
					aMessages = this.utility.getMessageExcelData(oModel, oi18n, "POU");
					aColumns = this.utility.getMessageExcelColumns("POU");
				} else if (oActionModel.getProperty("/iconTabBar/0/POPublication")) {
					sDocTitle = oi18n.getProperty("POPublic.fileName");
					aMessages = this.utility.getMessageExcelData(oModel, oi18n, "POP");
					aColumns = this.utility.getMessageExcelColumns("POP");
				} else if (oActionModel.getProperty("/iconTabBar/0/GRCancelation")) {

					sDocTitle = oi18n.getProperty("GRCancellation.fileName");
					aMessages = this.utility.getMessageExcelData(oModel, oi18n, "GRC");
					aColumns = this.utility.getMessageExcelColumns("GRC");
				} else if (oActionModel.getProperty("/iconTabBar/0/POCancel")) {

					sDocTitle = oi18n.getProperty("POCancel.fileName");
					aMessages = this.utility.getMessageExcelData(oModel, oi18n, "POCA");
					aColumns = this.utility.getMessageExcelColumns("POCA");
				}

				//Added Message download functionality for PO Update
				this.utility.exportMessageExcel(aMessages, aColumns, sDocTitle, oi18n);
			},

			/**
			 * @function: onMenuGRValidate 
			 * @description: When clicking on menu
			 * button to Validate GR, open popup to validate GR103, GR105 or
			 * both To avoid a request to the backend to retrieve all po items
			 * selected, we bind the table with a JSON model 
			 * @CreatedBy : KSD
			 * @CreatedOn : 14.02.2019 forDIGITPROP_BLM-59
			 */
			onMenuGRValidate: function onMenuGRValidate(oEvent) {
				// var that = this;
				var oView = this.getView(),
					i, aData = {
						'ETGRValidationSet': [],
						'ETWarningMessage': []
					},
					oGRValidationModel, oContext, oData, bAlrdyVal = false,
					oMsg;
				var oModel = oView.getModel('digital');
				var oi18n = oView.getModel("i18n");
				// initialize type of validation
				var bGR103 = false;
				var bGR105 = false;

				// get type of validation (GR103, GR105 or both)
				oGRValidationModel = oView.getModel('grValidation');
				var oItem = oEvent.getParameter("item"),
					sItemPath = "";
				while (oItem instanceof sap.m.MenuItem) {
					sItemPath = oItem.getText() + " > " + sItemPath;
					oItem = oItem.getParent();
				}

				sItemPath = sItemPath.substr(0, sItemPath.lastIndexOf(" > "));

				// update local model to enable or not GR103 and
				// GR105 modification
				if (sItemPath.indexOf('GR 103') > -1) {
					oGRValidationModel.setProperty('/Type/GR103', true);
					bGR103 = true;
				} else {
					oGRValidationModel.setProperty('/Type/GR103', false);
				}
				if (sItemPath.indexOf('GR 105') > -1) {
					oGRValidationModel.setProperty('/Type/GR105', true);
					bGR105 = true;
				} else {
					oGRValidationModel.setProperty('/Type/GR105', false);
				}

				// Get selected items in smarttable we have to retrieve
				// smarttable in child View and update dates

				var oIconTabFilter = oView.byId('idManageGRVal');
				var oChildView = oIconTabFilter.getContent()[0];
				var oTable = oChildView.byId('idSmartGRValTable').getTable();
				var aSelectedIndices = oTable.getSelectedIndices();
				// var sMsg = "";
				var iNoSNCount = 0;
				// loop on items to store data in JSON Model
				// and add date depending on Validation
				// type.
				for (i = 0; i < aSelectedIndices.length; i++) {
					oContext = oTable.getContextByIndex(aSelectedIndices[i]);

					// update dates depending on validation type when validation
					// not already done
					if (bGR103 && !oModel.getProperty(oContext + '/Gr103date')) {
						oModel.setProperty(oContext + '/Gr103date', oModel.getProperty(oContext + '/Deliverydate'));

						// Added by HJC for US 66 on 25.02.2019
						var sPricingGroup = oModel.getProperty(oContext + '/PricingGroup');
						var sSerialNo = oModel.getProperty(oContext + '/Serialnumber');
						if (sSerialNo === "" && (sPricingGroup === "P1" || sPricingGroup === "P2")) {
							iNoSNCount = iNoSNCount + 1;
						}
					} else if (bGR103 && oModel.getProperty(oContext + '/Gr103date')) {
						// if validation already done, add message to alert user
						// that at least one of the items is already validated
						bAlrdyVal = true;
					}

					if (bGR105) {
						oModel.setProperty(oContext + '/Gr105date', new Date());
					}

					oData = oModel.getData(oContext.getPath());
					// update list of objects to show
					aData['ETGRValidationSet'].push(oData);
				}

				// if validation already done, add message to alert user
				// that at least one of the items is already validated
				if (bAlrdyVal) {
					oMsg = {}; // initialize object
					// oMsg.WarningMsg =
					// oi18n.getProperty("GRValidation.GR103AlrdyVal");
					oMsg["WarningMsg"] = oi18n.getProperty("GRValidation.GR103AlrdyVal");
					aData["ETWarningMessage"].push(oMsg);
				}

				if (iNoSNCount > 0) {
					// initialize object with new value and add it to the warnig
					// messages
					oMsg = {
						"WarningMsg": oi18n.getProperty("GRValidation.noSN") + iNoSNCount + " purchase order items"
					};
					aData["ETWarningMessage"] = aData["ETWarningMessage"].concat(oMsg);
				}
				// json model for item list with PO items
				var oJSONModel = new JSONModel();
				oJSONModel.setData(aData);

				// initiate dialog
				if (!this._oDialog) {
					this._oDialog = sap.ui.xmlfragment("airbus.ui.digital_propulsion.fragment.GRValidation", this);
				}

				// set data for PO item to be validated

				this._oDialog.setModel(oJSONModel);
				// for labels coming from gateway
				this._oDialog.setModel(oModel, "digital");
				// modify editable property for 103 and 105
				// dates in dialog
				this._oDialog.setModel(oGRValidationModel, "grValidationType");

				this.getView().addDependent(this._oDialog);

				// toggle compact style
				jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oDialog);

				if (aData.ETWarningMessage.length > 0) {
					this._oDialog.getContent()[0].setVisible(true);
				} else {
					this._oDialog.getContent()[0].setVisible(false);
				}

				// open dialog
				this._oDialog.open();
			},

			/**
			 * @function: onGRValidation 
			 * @description: When clicking on Save button from Validation dialog, update model and save data in backend 
			 * @CreatedBy : KSD 
			 * @CreatedOn :19.02.2019 
			 * @US :DIGITPROP_BLM-59
			 */
			onGRValidation: function onGRValidation(oEvent) {
				var i, sPath, o103Date = null,
					o105Date = null,
					oJSONModel, sJSONPath, sModelURI;
				var oView = this.getView();
				var oModel = oView.getModel('digital');
				var aPOItems = sap.ui.getCore().byId('idGRValidationTable').getItems();
				sModelURI = this.getOwnerComponent().getManifestEntry('sap.app').dataSources['oDataDP'].uri;

				// update oData model with new modification from
				// dialog
				for (i = 0; i < aPOItems.length; i++) {
					oJSONModel = aPOItems[i].getBindingContext().getModel();
					sJSONPath = aPOItems[i].getBindingContext().getPath();
					sPath = '/' + oJSONModel.getProperty(sJSONPath + '/__metadata/uri').split(sModelURI)[1];

					// get new GR103/105 dates if user modified them in dialog
					if (oJSONModel.getProperty(sJSONPath + '/Gr103date')) {
						o103Date = new Date(oJSONModel.getProperty(sJSONPath + '/Gr103date'));
					}
					if (oJSONModel.getProperty(sJSONPath + '/Gr105date')) {
						o105Date = new Date(oJSONModel.getProperty(sJSONPath + '/Gr105date'));
					}

					// update oData model
					oModel.setProperty(sPath + '/Gr103date', o103Date);
					oModel.setProperty(sPath + '/Gr105date', o105Date);

				}
				this.onGRSave();
			},
			/**
			 * @function: onGRSave
			 * @description: Save changes for GR validation part 
			 * @CreatedBy : KSD 
			 * @CreatedOn :19.02.2019
			 * @US :DIGITPROP_BLM-59
			 */
			onGRSave: function onGRSave() {
				var that = this;
				var bBusy = false;
				var oModel = this.getView().getModel('digital');
				// close popup
				this._oDialog.close();
				// add busy dialog if changes to submit for GR Validation
				if (oModel.hasPendingChanges()) {
					var mChanges = oModel.getPendingChanges();

					for (var i in mChanges) {
						// if changes are for entity ETGRValidation, show busy
						// indicator
						if (i.indexOf('GRValidation') > -1 && !bBusy) {
							// add all changes in an array
							sap.ui.core.BusyIndicator.show();
							bBusy = true;
						}
					}
				}
				// update only GRValidation group (for entity ETGRValidation)
				this.getView().getModel('digital').submitChanges({
					groupId: "GRValidation",
					success: function (oData, oResponse) {
						// unselect all items from Smarttable
						that.getView().byId('idManageGRVal').getContent()[0].byId('idSmartGRValTable').getTable().setSelectedIndex(-1);
						// hide busy dialog
						sap.ui.core.BusyIndicator.hide();
						// update icontabfilter
						// count
						that.getView().byId("idManageGRVal").getElementBinding('digital').refresh();
						that.managePOCreateResponse(oData, oResponse);
					},
					error: function (oError) {
						// hide busy dialog
						sap.ui.core.BusyIndicator.hide();
					}
				});

			},

			/** 
			 * @function: onGRCancel 
			 * @description: When clicking on Cancel button from Validation dialog, rollback changes 
			 * @CreatedBy : KSD
			 * @CreatedOn :19.02.2019 for 
			 * @US : DIGITPROP_BLM-59
			 */
			onGRCancel: function onGRCancel() {
				var aChangesToReset = [];
				var oModel = this.getView().getModel('digital');

				if (oModel.hasPendingChanges()) {
					var mChanges = oModel.getPendingChanges();

					for (var i in mChanges) {
						// if changes are for entity ETGRValidation, reset these
						// changes
						if (i.indexOf('GRValidation') > -1) {
							// add all changes in an array
							aChangesToReset = aChangesToReset.concat('/' + i);
						}
					}
					// reset all changes
					oModel.resetChanges(aChangesToReset);
				}
				this._oDialog.close();
			},

			/**
			 * @function: onGRDuplicateDate 
			 * @description: Duplicate Dates 
			 * @CreatedBy : HJC
			 * @CreatedOn :18.09.2019 for 
			 * @US : DIGITPROP_BLM-364
			 */

			onGRDuplicateDate: function (oEvent) {

				var oTable = oEvent.getSource().getParent().getContent()[1];
				var aItems = oTable.getItems();
				var oBindingModel = aItems[0].getBindingContext().oModel;
				var sBindingPath = aItems[0].getBindingContext().sPath;
				var oFirstGR103Date = oBindingModel.getProperty(sBindingPath).Gr103date;
				var oFirstGR105Date = oBindingModel.getProperty(sBindingPath).Gr105date;

				if (oFirstGR103Date && aItems[0].getCells()[4].getEnabled()) {

					for (var i = 1; i < aItems.length; i++) {
						oBindingModel.setProperty(aItems[i].getBindingContext().sPath + "/Gr103date", oFirstGR103Date);
					}

				}
				if (oFirstGR105Date && aItems[0].getCells()[5].getEnabled()) {

					for (var j = 1; j < aItems.length; j++) {
						oBindingModel.setProperty(aItems[j].getBindingContext().sPath + "/Gr105date", oFirstGR105Date);
					}

				}

			},

			/**
			 * @function: onGRCDuplicateDate 
			 * @description: Duplicate Dates 
			 * @CreatedBy : SSH
			 * @CreatedOn :27.03.2020 for 
			 * @US : DIGITPROP_BLM-464
			 */

			onGRCDuplicateDate: function (oEvent) {

				var oTable = oEvent.getSource().getParent().getContent()[1];
				var aItems = oTable.getItems();
				var oModel = oEvent.getSource().getParent().getContent()[1].getModel();
				var aList = oModel.getData()["ETGRCancellationSet"];
				var oBindingModel = aItems[0].getBindingContext().oModel;
				var sBindingPath = aItems[0].getBindingContext().sPath;
				var oFirstGR106DocDate, oFirstGR106PostDate;
				var oFirstGR104DocDate = oBindingModel.getProperty(sBindingPath).Gr104docdate;
				var oFirstGR104PostDate = oBindingModel.getProperty(sBindingPath).Gr104postingdate;
				var oGRCModel = this.getView().getModel("grValidation");
				var currDate = new Date().toDateString();
				var b106dDate, b106pDate, b104dDate, b104pDate;
				b106dDate = b106pDate = b104dDate = b104pDate = false;
				
				//Get very first enabled date for GR106
				for(var item = 0; item < aItems.length; item++){
					if(aList[item].Gr105postingdate !== null ){
						oFirstGR106DocDate = aList[item].Gr106docdate;
						oFirstGR106PostDate = aList[item].Gr106postingdate;
						break;
					}
				}
				
				//Identify the dates that are changed
				if(oFirstGR106DocDate !== undefined && oFirstGR106DocDate !== null){
					if(oFirstGR106DocDate.toDateString() !== currDate && oGRCModel.getProperty('/Type/GR105')){
						b106dDate = true;
					}
					if (oFirstGR106PostDate.toDateString() !== currDate && oGRCModel.getProperty('/Type/GR105')) {
						b106pDate = true;
					}
				}	
				if(oFirstGR104DocDate !== undefined && oFirstGR104DocDate !== null){
					if(oFirstGR104DocDate.toDateString() !== currDate && oGRCModel.getProperty('/Type/GR103')){
						b104dDate = true; 
					}
					if (oFirstGR104PostDate.toDateString() !== currDate && oGRCModel.getProperty('/Type/GR103')) {
						b104pDate = true;
					}
				}	
		
				//Change dates, if enabled and qualified 
				if (oFirstGR106DocDate) {

					for (var i = 1; i < aList.length; i++) {
						if(aList[i].Gr105postingdate !== null ){
							if(b106dDate){
								aList[i].Gr106docdate = oFirstGR106DocDate;
							}
							if(b106pDate){
								aList[i].Gr106postingdate = oFirstGR106PostDate;	
							}
						}
					}

				}
				if (oFirstGR104DocDate) {

					for (var j = 1; j < aList.length; j++) {
						if(b104dDate){
							aList[j].Gr104docdate = oFirstGR104DocDate;
						}
						if(b104pDate){
							aList[j].Gr104postingdate = oFirstGR104PostDate;
						}	
					}

				}
				
				oModel.setData("ETGRCancellationSet",aList);

			},

			/**
			 * @HJC for US BLM 87 on 14.03.2019
			 * 
			 * @function: onPOScheluleSave
			 * @description: Save PO Scheduling Commnets
			 * @param:
			 */

			onPOScheluleSave: function () {
				var that = this;
				var i18n = this.getView().getModel("i18n");
				var oModel = this.getView().getModel("digital");

				if (oModel.getPendingChanges()) {

					oModel.submitChanges(({
						groupId: "POSchedule",
						success: function (oData, oResponse) {
							// Uncheck checkbox after update
							that.getView().byId("idManagePOsched").getContent()[0].byId('idSmartPOScheduleTable').getTable().setSelectedIndex(-1);
							that.getView().byId("idManagePOsched").getElementBinding('digital').refresh();
							that.managePOCreateResponse(oData, oResponse);

						},
						error: that.myErrorHandler
					}));
				}
			},

			/**
			 * @HJC for US BLM 96 on 18.03.2019
			 * 
			 * @function: onMenuPOSAlign
			 * @description: Align all PO dates
			 * @param: oEvent
			 */

			onMenuPOSAlign: function (oEvent) {
				var oi18nModel = this.getView().getModel("i18n");
				var oModel = this.getView().getModel("digital");
				var sSelectedKey = oEvent.getParameter("item").getKey();
				var oPOSIconTab = this.getView().byId("idManagePOsched");
				var oPOSView = oPOSIconTab.getContent()[0];
				var oPOSTable = oPOSView.getContent()[1].getTable();

				if (oPOSTable.getSelectedIndices().length > 0) {

					for (var i = 0; i < oPOSTable.getSelectedIndices().length; i++) {

						var oContext = oPOSTable.getContextByIndex(oPOSTable.getSelectedIndices()[i]);
						var oPreqDeliveryDate = oContext.getProperty("Prdeliverydate");
						var sPath = oContext.sPath;
						oModel.setProperty(sPath + "/Actiontype", "ALIN");
						switch (sSelectedKey) {
						case "PO":
							oModel.setProperty(sPath + "/Podeliverydate", oPreqDeliveryDate);
							break;

						case "STAT":
							oModel.setProperty(sPath + "/Statisticdate", oPreqDeliveryDate);
							break;

						case "ALL":
							oModel.setProperty(sPath + "/Podeliverydate", oPreqDeliveryDate);
							oModel.setProperty(sPath + "/Statisticdate", oPreqDeliveryDate);
							break;

						default:
							break;
						}

					}
					this.onPOScheluleSave();
				} else {
					sap.m.MessageToast.show(oi18nModel.getProperty("POSchedule.NoSelection"));
				}

			},

			/**
			 * @function: myErrorHandler 
			 * @description: When receiving error message from backend after Batch 
			 * @CreatedBy : KSD
			 * @CreatedOn :20.02.2019 
			 * @US : DIGITPROP_BLM-59
			 */
			myErrorHandler: function myErrorHandler(oEvent) {
				// console.log('Error');
				// to manage
			},

			/**
			 * @function: onPOUpdateCreate 
			 * @description: Create a new PO from PO Update tab 
			 * @CreatedBy : KSD
			 * @CreatedOn :20.04.2019 
			 * @US : Sprint 5
			 */
			onPOUpdateCreate: function onPOUpdateCreate() {
				var sType = 'C';
				this.onPOUpdateSave(sType);
			},

			/**
			 * @function: onPOUpdateUpdate 
			 * @description: Update an existing PO from PO Update tab 
			 * @CreatedBy : KSD
			 * @CreatedOn :20.04.2019 
			 * @US : Sprint 5
			 */
			onPOUpdateUpdate: function onPOUpdateUpdate() {
				var sType = 'U';
				this.onPOUpdateSave(sType);
			},

			/**
			 * @function: onPOUpdateDelete 
			 * @description: Delete an existing PO from PO Update tab 
			 * @CreatedBy : KSD
			 * @CreatedOn :20.04.2019 
			 * @US : Sprint 5
			 */
			onPOUpdateDelete: function onPOUpdateDelete() {
				var sType = 'D';
				this.onPOUpdateSave(sType);
			},

			/**
			 * @function: onPOUpdateSave 
			 * @description: Call the 3 functions 
			 * @CreatedBy : KSD
			 * @CreatedOn :20.04.2019 
			 * @US : Sprint 5
			 */
			onPOUpdateSave: function onPOUpdateSave(sType) {
				var that = this;
				var bBusy = false;
				var oModel = this.getView().getModel('digital');
				var aChanges = [];

				//Capture action taken for PO Update
				//Added by SSH on 15.04.19
				jQuery.sap.setObject("airbus.ui.digital_propulsion.GLOBAL.POUAction", sType);

				// add busy dialog if changes to submit for GR Validation
				if (oModel.hasPendingChanges()) {
					var mChanges = oModel.getPendingChanges();

					for (var i in mChanges) {
						i = '/' + i;
						// if changes are for entity ETPOUpdate, show busy
						// indicator
						if (i.indexOf('POUpdate') > -1 && oModel.getProperty(i + '/ActionType') === 'X') {
							//Update ActionType property
							oModel.setProperty(i + '/ActionType', sType);
						}
					}

					// update only POUpdate group (for entity ETPOUpdate)
					this.getView().getModel('digital').submitChanges({
						groupId: "POUpdate",
						success: function (oData, oResponse) {
							//						 unselect all items from Smarttable
							that.getView().byId('idIconTabFiltePOUpdate').getContent()[0].byId('idSmartPOUpdateTable').getTable().setSelectedIndex(-1);
							// update icontabfilter
							// count
							that.getView().byId("idIconTabFiltePOUpdate").getElementBinding('digital').refresh();
							that.managePOCreateResponse(oData, oResponse);
						},
						error: function (oError) {
							// hide busy dialog
							sap.ui.core.BusyIndicator.hide();
						}
					});
				}
			},

			/**
			 * @function: onPOPublish 
			 * @description: On PO Publish Button Click
			 * @CreatedBy : HJC
			 * @CreatedOn : 15.05.2019 
			 * @US : Sprint 6
			 */

			onPOPublish: function () {
				var that = this;
				var i18n = this.getView().getModel("i18n");
				var oModel = this.getView().getModel("digital");

				if (oModel.getPendingChanges()) {

					oModel.submitChanges(({
						groupId: "POPublish",
						success: function (oData, oResponse) {
							// Uncheck checkbox after update
							that.getView().byId("idManagePOPublice").getContent()[0].byId('idSmartPOPubliceTable').getTable().setSelectedIndex(-1);
							that.getView().byId("idManagePOPublice").getElementBinding('digital').refresh();
							that.managePOCreateResponse(oData, oResponse);

						},
						error: that.myErrorHandler
					}));
				}
			},

			/**
			 * @function: submitChanges 
			 * @description: Submit Changes to the Backend
			 * @CreatedBy : KSD
			 * @CreatedOn : 20.04.2019 
			 * @US : Sprint 5
			 */
			submitChanges: function submitChanges(sEntity, sGroupId, sIdIconTab, sIdSmartTableToDeselect) {

			},

			/**
			 * @function: onGRValidateCommentSave 
			 * @description: On GR Validation Comment Save
			 * @CreatedBy : HJC
			 * @CreatedOn : 01.10.2019 
			 * @US : Sprint 10
			 */

			onGRValidateCommentSave: function () {
				var that = this;
				var i18n = this.getView().getModel("i18n");
				var oModel = this.getView().getModel("digital");
				var sModelURI = this.getOwnerComponent().getManifestEntry('sap.app').dataSources['oDataDP'].uri;
				if (oModel.hasPendingChanges()) {

					var aPendingChange = Object.values(oModel.getPendingChanges());
					for (var i = 0; i < aPendingChange.length; i++) {
						var sPath = "/" + aPendingChange[i].__metadata.uri.split(sModelURI)[1];
						oModel.setProperty(sPath + "/Commentupdate", "X");
					}

					oModel.submitChanges(({
						groupId: "GRValidation",
						success: function (oData, oResponse) {
							// Uncheck checkbox after update
							that.getView().byId("idManageGRVal").getContent()[0].byId('idSmartGRValTable').getTable().setSelectedIndex(-1);
							that.getView().byId("idManageGRVal").getElementBinding('digital').refresh();
							that.managePOCreateResponse(oData, oResponse);

						},
						error: that.myErrorHandler
					}));
				}

			},

			/**
			 * 
			 * 
			 */

			onMenuGRCancellation: function (oEvent) {
				var oView = this.getView(),
					i, aData = {
						'ETGRCancellationSet': [],
						'ETWarningMessage': []
					},
					oGRValidationModel, oContext, oData, bNotVal = false,
					oMsg;
				var oModel = oView.getModel('digital');
				var oi18n = oView.getModel("i18n");
				// initialize type of validation
				var bGR103 = false;
				var bGR105 = false;

				// get type of validation (GR103, GR105 or both)
				oGRValidationModel = oView.getModel('grValidation');
				var sItemText = oEvent.getParameter("item").getText();

				if (sItemText.indexOf('103') > -1) {
					oGRValidationModel.setProperty('/Type/GR103', true);
					bGR103 = true;
				} else {
					oGRValidationModel.setProperty('/Type/GR103', false);
				}
				if (sItemText.indexOf('105') > -1) {
					oGRValidationModel.setProperty('/Type/GR105', true);
					bGR105 = true;
				} else {
					oGRValidationModel.setProperty('/Type/GR105', false);
				}

				// Get selected items in smarttable we have to retrieve
				// smarttable in child View and update dates

				var oIconTabFilter = oView.byId('idManageGRCancel');
				var oChildView = oIconTabFilter.getContent()[0];
				var oTable = oChildView.byId('idSmartGRCancelTable').getTable();
				var aSelectedIndices = oTable.getSelectedIndices();

				if (aSelectedIndices.length > 0) {

					for (i = 0; i < aSelectedIndices.length; i++) {
						oContext = oTable.getContextByIndex(aSelectedIndices[i]);

						if (bGR103 && bGR105) {
							oModel.setProperty(oContext + "/Canceltype", "BOTH");
							oModel.setProperty(oContext + '/Gr104docdate', new Date());
							oModel.setProperty(oContext + '/Gr104postingdate', new Date());
							if (oContext.getProperty("Gr105postingdate") !== null) {
								oModel.setProperty(oContext + '/Gr106docdate', new Date());
								oModel.setProperty(oContext + '/Gr106postingdate', new Date());
							} else {
								oModel.setProperty(oContext + '/Gr106docdate', oContext.getProperty("Gr106docdate"));
								oModel.setProperty(oContext + '/Gr106postingdate', oContext.getProperty("Gr106postingdate"));
							}
						} else if (bGR103 && !bGR105 && oContext.getProperty("Gr103postingdate") !== null) {
							oModel.setProperty(oContext + "/Canceltype", "103");
							oModel.setProperty(oContext + '/Gr104docdate', new Date());
							oModel.setProperty(oContext + '/Gr104postingdate', new Date());
						} else if (!bGR103 && bGR105) {
							oModel.setProperty(oContext + "/Canceltype", "105");
							if (oContext.getProperty("Gr105postingdate") !== null) {
								oModel.setProperty(oContext + '/Gr106docdate', new Date());
								oModel.setProperty(oContext + '/Gr106postingdate', new Date());
							} else {
								oModel.setProperty(oContext + '/Gr106docdate', oContext.getProperty("Gr106docdate"));
								oModel.setProperty(oContext + '/Gr106postingdate', oContext.getProperty("Gr106postingdate"));
							}
						} else {
							bNotVal = true;
						}

						oData = oModel.getData(oContext.getPath());
						// update list of objects to show
						aData['ETGRCancellationSet'].push(oData);
					}

					if (bNotVal) {
						oMsg = {};
						oMsg["WarningMsg"] = oi18n.getProperty("GRCancellation.GRNotVal");
						aData["ETWarningMessage"].push(oMsg);
					}

					var oJSONModel = new JSONModel();
					oJSONModel.setData(aData);

					// initiate dialog
					if (!this._oCancelDialog) {
						this._oCancelDialog = sap.ui.xmlfragment("airbus.ui.digital_propulsion.fragment.GRCancellation", this);
					}

					// set data for PO item to be validated

					this._oCancelDialog.setModel(oJSONModel);
					// for labels coming from gateway
					this._oCancelDialog.setModel(oModel, "digital");
					// modify editable property for 103 and 105
					// dates in dialog
					this._oCancelDialog.setModel(oGRValidationModel, "grValidationType");

					this.getView().addDependent(this._oCancelDialog);

					// toggle compact style
					jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._oCancelDialog);

					if (aData.ETWarningMessage.length > 0) {
						this._oCancelDialog.getContent()[0].setVisible(true);
					} else {
						this._oCancelDialog.getContent()[0].setVisible(false);
					}
					this._oCancelDialog.open();
				} else {
					sap.m.MessageToast.show(oi18n.getProperty("GRCancellation.notSelected"));
				}

			},

			/**
			 * 
			 * 
			 * 
			 */

			onGRCancellationSave: function () {
				var that = this;
				var bBusy = false;

				this.onGRCUpdateDate();
				var oModel = this.getView().getModel('digital');

				// close popup
				this._oCancelDialog.close();
				// add busy dialog if changes to submit for GR Validation
				if (oModel.hasPendingChanges()) {
					var mChanges = oModel.getPendingChanges();

					for (var i in mChanges) {
						// if changes are for entity ETGRCancellation, show busy
						// indicator
						if (i.indexOf('GRCancellation') > -1 && !bBusy) {
							// add all changes in an array
							sap.ui.core.BusyIndicator.show();
							bBusy = true;
						}
					}
				}
				// update only GRCancellation group (for entity ETGRCancellation)
				this.getView().getModel('digital').submitChanges({
					groupId: "GRCancellation",
					success: function (oData, oResponse) {
						// unselect all items from Smarttable
						that.getView().byId('idManageGRCancel').getContent()[0].byId('idSmartGRCancelTable').getTable().setSelectedIndex(-1);
						// hide busy dialog
						sap.ui.core.BusyIndicator.hide();
						that.getView().byId("idManageGRCancel").getElementBinding('digital').refresh();
						that.managePOCreateResponse(oData, oResponse);
					},
					error: function (oError) {
						// hide busy dialog
						sap.ui.core.BusyIndicator.hide();
					}
				});
			},

			onGRCUpdateDate: function (oEvent) {
				var i, sPath, o106dDate = null,
					o106pDate = null,
					o104dDate = null,
					o104pDate = null,
					oJSONModel, sJSONPath, sModelURI;
				var oView = this.getView();
				var oModel = oView.getModel('digital');
				var aPOItems = sap.ui.getCore().byId('idGRCancelTable').getItems();
				sModelURI = this.getOwnerComponent().getManifestEntry('sap.app').dataSources['oDataDP'].uri;

				// update oData model with new modification from dialog
				for (i = 0; i < aPOItems.length; i++) {
					oJSONModel = aPOItems[i].getBindingContext().getModel();
					sJSONPath = aPOItems[i].getBindingContext().getPath();
					sPath = '/' + oJSONModel.getProperty(sJSONPath + '/__metadata/uri').split(sModelURI)[1];

					// get new GR104/106 dates if user modified them in dialog
					if (oJSONModel.getProperty(sJSONPath + '/Gr106docdate')) {
						o106dDate = new Date(oJSONModel.getProperty(sJSONPath + '/Gr106docdate'));
					}
					if (oJSONModel.getProperty(sJSONPath + '/Gr106postingdate')) {
						o106pDate = new Date(oJSONModel.getProperty(sJSONPath + '/Gr106postingdate'));
					}
					if (oJSONModel.getProperty(sJSONPath + '/Gr104docdate')) {
						o104dDate = new Date(oJSONModel.getProperty(sJSONPath + '/Gr104docdate'));
					}
					if (oJSONModel.getProperty(sJSONPath + '/Gr104postingdate')) {
						o104pDate = new Date(oJSONModel.getProperty(sJSONPath + '/Gr104postingdate'));
					}

					// update oData model
					oModel.setProperty(sPath + '/Gr106docdate', o106dDate);
					oModel.setProperty(sPath + '/Gr106postingdate', o106pDate);
					oModel.setProperty(sPath + '/Gr104docdate', o104dDate);
					oModel.setProperty(sPath + '/Gr104postingdate', o104pDate);

				}
			},

			/**
			 * 
			 * 
			 * 
			 * 
			 * 
			 */

			onGRCancellationCancel: function () {
				var aChangesToReset = [];
				var oModel = this.getView().getModel('digital');

				if (oModel.hasPendingChanges()) {
					var mChanges = oModel.getPendingChanges();

					for (var i in mChanges) {
						// if changes are for entity ETGRValidation, reset these
						// changes
						if (i.indexOf('GRCancallation') > -1) {
							// add all changes in an array
							aChangesToReset = aChangesToReset.concat('/' + i);
						}
					}
					// reset all changes
					oModel.resetChanges(aChangesToReset);
				}
				this._oCancelDialog.close();
			},

			/* @function: onPOUCommentSave 
			 * @description: On PO Update Comment Save
			 * @CreatedBy : SSH
			 * @CreatedOn : 22.10.2019 
			 * @US : Sprint 11
			 */

			onPOUCommentSave: function () {
				var that = this;
				var i18n = this.getView().getModel("i18n");
				var oModel = this.getView().getModel("digital");
				var sType = 'S';

				//Capture action taken for PO Update
				//Added by SSH on 22.10.19
				jQuery.sap.setObject("airbus.ui.digital_propulsion.GLOBAL.POUAction", sType);

				if (oModel.getPendingChanges()) {
					var mChanges = oModel.getPendingChanges();

					for (var i in mChanges) {
						i = '/' + i;
						if (i.indexOf('POUpdate') > -1) {
							//Update ActionType property
							oModel.setProperty(i + '/ActionType', sType);
						}
					}

					oModel.submitChanges(({
						groupId: "POUpdate",
						success: function (oData, oResponse) {
							// Uncheck checkbox after update
							that.getView().byId("idIconTabFiltePOUpdate").getContent()[0].byId('idSmartPOUpdateTable').getTable().setSelectedIndex(-1);
							that.getView().byId("idIconTabFiltePOUpdate").getElementBinding('digital').refresh();
							that.managePOCreateResponse(oData, oResponse);

						},
						error: that.myErrorHandler
					}));
				}

			},

			/**
			 * @function: onPOCancel 
			 * @description: On PO Cancel or Configuration Cancel
			 * @CreatedBy : HJC
			 * @CreatedOn : 18.03.2020 
			 * @US : PH 2 Sprint 03
			 */

			onPOCancel: function (oEvent) {
				var that = this;
				var oSource = oEvent.getSource();
				var sId = oSource.getId().split("--")[1];
				var oModel = this.getView().getModel("digital");
				var oIconTabFilter = this.getView().byId('idManagePOCancel');
				var oChildView = oIconTabFilter.getContent()[0];
				var oTable = oChildView.byId('idSmartPOCancelTable').getTable();
				var aSelectedIndices = oTable.getSelectedIndices();

				if (aSelectedIndices.length > 0) {
					for (var i = 0; i < aSelectedIndices.length; i++) {
						var oContext = oTable.getContextByIndex(aSelectedIndices[i]);
						if (sId === "idPOConfCancelButton") {
							oModel.setProperty(oContext + "/Actiontype", "CONF");
						} else if (sId === "idPOCancelButton") {
							oModel.setProperty(oContext + "/Actiontype", "CANC");
						}
					}
				}

				if (oModel.hasPendingChanges()) {
					sap.ui.core.BusyIndicator.show();
					oModel.submitChanges({
						groupId: "POCancel",
						success: function (oData, oResponse) {
							// unselect all items from Smarttable
							oTable.setSelectedIndex(-1);
							// hide busy dialog
							sap.ui.core.BusyIndicator.hide();
							// that.getView().byId("idManagePOCancel").getElementBinding('digital').refresh();
							that.managePOCreateResponse(oData, oResponse);
						},
						error: function (oError) {
							// hide busy dialog
							sap.ui.core.BusyIndicator.hide();
						}
					});
				}
			}

		});
	});