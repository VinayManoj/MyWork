sap.ui.define([ "sap/ui/model/json/JSONModel" ], function(JsonModel) {
	"use strict";
	return {

		/**
		 * @HJC for padlock on 29.01.2019
		 * @TO :
		 * 
		 * @function: getLockVisibility
		 * @description: manage visibility of padlock
		 * @params: slock
		 * @returns: bState
		 */
		getLockVisibility : function(slock) {
			var bState = false;

			if (slock === "lock") {
				bState = true;
			}

			return bState;
		},

		/**
		 * @LEI for time indicator on 07.02.2019 (US 56)
		 * @TO :
		 * 
		 * @function: getIndicatorVisibility
		 * @description: manage visibility of time indicator on GR validation
		 * @params: sindicator
		 * @returns: bState
		 */
		getIndicatorVisibility : function(sindicator) {
			var bState = false;
			
			// updated by NG7290B on 19/06/2019 to get good label in excel export (yes or no)			 
			if (sindicator === "yes") {
				bState = true;
			}

			return bState;
		},

		/**
		 * @HJC for Date Misalignment on 13.02.2019 (US 57)
		 * @TO :
		 * 
		 * @function: getMisalignmentState
		 * @description: manage state of date Misalignment on GR validation
		 * @params: sDeliveryDate, sPostingDate, sDocumentDate
		 * @returns: bState
		 */

		getMisalignmentState : function(sDeliveryDate, sPostingDate,
				sDocumentDate) {
			var bState = "None";
			// return nothing if posting date or document date is empty
			if (!sPostingDate || !sDocumentDate) {
				return bState;
			}

			// get time for the three dates
			if (sDeliveryDate) {
				sDeliveryDate = sDeliveryDate.getTime();
			}
			if (sPostingDate) {
				sPostingDate = sPostingDate.getTime();
			}
			if (sDocumentDate) {
				sDocumentDate = sDocumentDate.getTime();
			}

			// compare dates
			if (sDeliveryDate === sPostingDate
					&& sDeliveryDate === sDocumentDate) {
				bState = "None";
			} else {
				bState = "Error";
			}

			return bState;
		},

		/**
		 * NOT USED
		 * 
		 * @KSD for CAC number sort on 01.02.2019
		 * 
		 * @function: removeZerosBegin
		 * @description: remove all 0 at the beginning of the string
		 * @param: str
		 */
		removeZerosBegin : function removeZerosBegin(str) {
			var sReturn;
			if (str) {
				sReturn = str.replace(/^0+/, '');
			}
			return sReturn;
		},

		/**
		 * @HJC for US BLM 70 on 27.02.2019
		 * 
		 * @function: validate103State
		 * @description: Check state of GR 103 date on the basis of 103 Posting
		 *               Date
		 * @param: bGR103state, sPostingDate
		 * @returns: bReturn
		 */
		validate103State : function(bGR103state, sPostingDate) {

			var bReturn = false;

			if (bGR103state && sPostingDate === null) {
				bReturn = true;
			}

			return bReturn;
		},
		
		/**
		 * @SSH for US BLM 464 on 26.03.2020
		 * 
		 * @function: validate105State
		 * @description: Check state of GR 105 date on the basis of 105 Posting
		 *               Date
		 * @param: bGR105state, sPostingDate
		 * @returns: bReturn
		 */
		validate105State : function(bGR105state, sPostingDate) {

			var bReturn = false;

			if (bGR105state && sPostingDate !== null) {
				bReturn = true;
			}

			return bReturn;
		},

		/**
		 * @SSH for US BLM 408 on 27.11.2019
		 * 
		 * @function: getPOSMisalignmentState
		 * @description: Get PO Misalignment Icon
		 * @param: sStatus
		 * @returns: sIcon
		 */

		getPOSMisalignmentIcon : function(sStatus) {
			var sIcon = "";

			if (sStatus === "Yellow") {
				sIcon = "sap-icon://project-definition-triangle-2";
			} else if (sStatus === "Red") {
				sIcon = "sap-icon://circle-task-2";
			} else if (sStatus === "Green") {
				sIcon = "sap-icon://color-fill";
			}

			return sIcon;
		},

		/**
		 * @HJC for US BLM 92 on 07.03.2019
		 * 
		 * @function: getPOSMisalignmentState
		 * @description: Set Misalignment State
		 * @param: sColor
		 * @returns: sState
		 */
		getPOSMisalignmentState : function(sColor) {
			var sIconColor = "";
			if (sColor === "Yellow") {
				sIconColor = "#f0c91f";
			} else if (sColor === "Green") {
				sIconColor = "#13ab1f";
			} else if (sColor === "Red") {
				sIconColor = "#db2d21";
			}

			return sIconColor;
		},

		/**
		 * @HJC on 28.03.2019
		 * 
		 * @function: getPOSMisalignmentVisible
		 * @description: Manage visibility of Misalignment State
		 * @param: sColor
		 * @returns: bVisible
		 */
		getPOSMisalignmentVisible : function(sColor) {

			var bVisible = false;

			if (sColor !== "") {
				bVisible = true;
			}

			return bVisible;
		},

		/**
		 * @HJC for US BLM 87 on 12.03.2019
		 * 
		 * @function: getMoreCommentState
		 * @description: Get More Comment Icon State
		 * @param: sComment
		 * @returns: bState
		 */

		getMoreCommentState : function(sComment) {

			var bState = false;
			// if no comment return false
			if (!sComment) {
				return false;
			}

			if (sComment.length > 0) {
				bState = true;
			}

			return bState;
		},

		/**
		 * @HJC for US BLM 87 on 13.03.2019
		 * 
		 * @function: getCommentIcon
		 * @description: Set Icon on the basis of length of the text
		 * @param: sComment
		 * @returns: sIcon
		 */

		getCommentIcon : function(sComment) {
			var sIcon = "sap-icon://overflow";

			if (sComment.length === 0) {
				sIcon = "sap-icon://add";
			}

			return sIcon;
		},

		/**
		 * @HJC for US BLM 87 on 09.04.2019
		 * 
		 * @function: getActionIcon
		 * @description: Set Action Indicator Icon
		 * @param: sIndicator
		 * @returns: sIcon
		 */

		getActionIcon : function(sIndicator) {
			var sIcon = "";
			if (sIndicator === "Upd") {
				sIcon = "sap-icon://edit";
			} else if (sIndicator === "Del") {
				sIcon = "sap-icon://delete";
			} else if (sIndicator === "Crt") {
				sIcon = "sap-icon://add-document";
			}

			return sIcon;
		},

		/**
		 * @HJC for US BLM 87 on 09.04.2019
		 * 
		 * @function: getActionVisibility
		 * @description: Set Action Indicator Visibility
		 * @param: sIndicator
		 * @returns: bVisible
		 */
		getActionVisibility : function(sIndicator) {
			var bVisible = false;

			if (sIndicator !== "") {
				bVisible = true;
			}

			return bVisible;
		},

		/**
		 * @HJC for US BLM 87 on 09.04.2019
		 * 
		 * @function: getActionState
		 * @description: Set Action Indicator Icon State
		 * @param: sIndicator
		 * @returns: sState
		 */

		getActionState : function(sIndicator) {

			var sState = "None";

			if (sIndicator === "Upd" || sIndicator === "Crt") {
				sState = "Success";
			} else if (sIndicator === "Del") {
				sState = "Error";
			}

			return sState;

		},

		/**
		 * @LEI for US BLM 218 on 17.06.2019
		 * 
		 * @function: getTypeIndicatorIcon
		 * @description: Set Type Indicator Icon
		 * @param: sIndicator
		 * @returns: sIcon
		 */

		getTypeIndicatorIcon : function(sIndicator) {
			var sIcon = "";

			if (sIndicator === "Delete") {
				sIcon = "sap-icon://delete";
			} else if (sIndicator === "Change") {
				sIcon = "sap-icon://edit";
			} 
			// else if (sIndicator === "New") {
			// 	sIcon = "sap-icon://add-favorite";
			// }

			return sIcon;
		},

		/**
		 * @SSH for US BLM 218 on 22.11.2019
		 * 
		 * @function: getPublicationText
		 * @description: Get Publication Text
		 * @param: sIndicator
		 * @returns: sText
		 */
		getPublicationText : function(sIndicator) {
			var sText = "";

			if (sIndicator === "New") {
				sText = "NEW";
			}

			return sText;
		},

		/**
		 * @LEI for US BLM 218 on 17.06.2019
		 * 
		 * @function: getTypeIndicatorVisibility
		 * @description: Set Type Indicator Visibility
		 * @param: sIndicator
		 * @returns: bVisible
		 */

		getTypeIndicatorVisibility : function(sIndicator) {

			var bVisible = false;

			if (sIndicator === "Delete" || sIndicator === "Change"
					|| sIndicator === "New") {
				bVisible = true;
			}

			return bVisible;
		},

		/**
		 * @LEI for US BLM 218 on 17.06.2019
		 * 
		 * @function: getTypeIndicatorState
		 * @description: Set Type Indicator Icon State
		 * @param: sIndicator
		 * @returns: sState
		 */

		getTypeIndicatorState : function(sIndicator) {

			var sState = "None";

			if (sIndicator === "Change") {
				sState = "Success";
			} else if (sIndicator === "Delete") {
				sState = "Error";
			} else if (sIndicator === "New") {
				sState = "None";
			}

			return sState;

		},

		/**
		 * @SSH for US BLM 372 on 24.09.2019
		 * 
		 * @function: getGRPublicationIcon
		 * @description: Get Publication Icon
		 * @param: sStatus
		 * @returns: sIcon
		 */

		getGRPublicationIcon : function(sStatus) {
			var sIcon = "";

			if (sStatus === "0") {
				sIcon = "sap-icon://project-definition-triangle-2";
			} else if (sStatus === "1") {
				sIcon = "sap-icon://color-fill";
			} else if (sStatus === "2") {
				sIcon = "sap-icon://circle-task-2";
			}

			return sIcon;
		},

		/**
		 * @SSH for US BLM 372 on 24.09.2019
		 * 
		 * @function: getGRPublicationColor
		 * @description: Get Publication Icon color
		 * @param: sStatus
		 * @returns: sIcon
		 */

		getGRPublicationColor : function(sValue) {
			var sColor = "";

			if (sValue === "0") {
				sColor = "#f0c91f";
			} else if (sValue === "1") {
				sColor = "#13ab1f";
			} else if (sValue === "2") {
				sColor = "#db2d21";
			}

			return sColor;
		},

		/**
		 * @SSH for US BLM 405 on 21.11.2019
		 * 
		 * @function: getSerialProfile
		 * @description: Get serial profile indicator
		 * @param: sValue
		 * @returns: bProfile
		 */

		getSerialProfile : function(sValue) {
			var bProfile = false;

			if (sValue === "X") {
				bProfile = true;
			}
			return bProfile;
		}


	};
});
