sap.ui.define([ "sap/ui/model/json/JSONModel" ], function(JsonModel) {
	"use strict";
	return {

		/**
		 * @HJC for padlock on 29.01.2019
		 * @TO :
		 * 
		 * @function: getLockVisibility
		 * @description: manage visibility of padlock
		 * @params: slock
		 * @returns: bState
		 */
		getLockVisibility : function(slock) {
			var bState = false;

			if (slock === "lock") {
				bState = true;
			}

			return bState;
		},

		/**
		 * @LEI for time indicator on 07.02.2019 (US 56)
		 * @TO :
		 * 
		 * @function: getIndicatorVisibility
		 * @description: manage visibility of time indicator on GR validation
		 * @params: sindicator
		 * @returns: bState
		 */
		getIndicatorVisibility : function(sindicator) {
			var bState = false;
			
			// updated by NG7290B on 19/06/2019 to get good label in excel export (yes or no)			 
			if (sindicator === "yes") {
				bState = true;
			}

			return bState;
		},

		/**
		 * @HJC for Date Misalignment on 13.02.2019 (US 57)
		 * @TO :
		 * 
		 * @function: getMisalignmentState
		 * @description: manage state of date Misalignment on GR validation
		 * @params: sDeliveryDate, sPostingDate, sDocumentDate
		 * @returns: bState
		 */

		getMisalignmentState : function(sDeliveryDate, sPostingDate,
				sDocumentDate) {
			var bState = "None";
			// return nothing if posting date or document date is empty
			if (!sPostingDate || !sDocumentDate) {
				return bState;
			}

			// get time for the three dates
			if (sDeliveryDate) {
				sDeliveryDate = sDeliveryDate.getTime();
			}
			if (sPostingDate) {
				sPostingDate = sPostingDate.getTime();
			}
			if (sDocumentDate) {
				sDocumentDate = sDocumentDate.getTime();
			}

			// compare dates
			if (sDeliveryDate == sPostingDate
					&& sDeliveryDate === sDocumentDate) {
				bState = "None";
			} else {
				bState = "Error";
			}

			return bState;
		},

		/**
		 * NOT USED
		 * 
		 * @KSD for CAC number sort on 01.02.2019
		 * 
		 * @function: removeZerosBegin
		 * @description: remove all 0 at the beginning of the string
		 * @param: str
		 */
		removeZerosBegin : function removeZerosBegin(str) {
			var sReturn;
			if (str) {
				sReturn = str.replace(/^0+/, '');
			}
			return sReturn;
		},

		/**
		 * @HJC for US BLM 70 on 27.02.2019
		 * 
		 * @function: validate103State
		 * @description: Check state of GR 103 date on the basis of 103 Posting
		 *               Date
		 * @param: bGR103state, sPostingDate
		 * @returns: bReturn
		 */
		validate103State : function(bGR103state, sPostingDate) {

			var bReturn = false;

			if (bGR103state && sPostingDate === null) {
				bReturn = true;
			}

			return bReturn;
		},

		/**
		 * @SSH for US BLM 408 on 27.11.2019
		 * 
		 * @function: getPOSMisalignmentState
		 * @description: Get PO Misalignment Icon
		 * @param: sStatus
		 * @returns: sIcon
		 */

		getPOSMisalignmentIcon : function(sStatus) {
			var sIcon = "";

			if (sStatus === "Yellow") {
				sIcon = "sap-icon://project-definition-triangle-2";
			} else if (sStatus === "Red") {
				sIcon = "sap-icon://circle-task-2";
			} else if (sStatus === "Green") {
				sIcon = "sap-icon://color-fill";
			}

			return sIcon;
		},

		/**
		 * @HJC for US BLM 92 on 07.03.2019
		 * 
		 * @function: getPOSMisalignmentState
		 * @description: Set Misalignment State
		 * @param: sColor
		 * @returns: sState
		 */
		getPOSMisalignmentState : function(sColor) {
			var sIconColor = "";
			if (sColor === "Yellow") {
				sIconColor = "#f0c91f";
			} else if (sColor === "Green") {
				sIconColor = "#13ab1f";
			} else if (sColor === "Red") {
				sIconColor = "#db2d21";
			}

			return sIconColor;
		},

		/**
		 * @HJC on 28.03.2019
		 * 
		 * @function: getPOSMisalignmentVisible
		 * @description: Manage visibility of Misalignment State
		 * @param: sColor
		 * @returns: bVisible
		 */
		getPOSMisalignmentVisible : function(sColor) {

			var bVisible = false;

			if (sColor !== "") {
				bVisible = true;
			}

			return bVisible;
		},


		/**
		 * @LEI for US BLM 218 on 17.06.2019
		 * 
		 * @function: getTypeIndicatorIcon
		 * @description: Set Type Indicator Icon
		 * @param: sIndicator
		 * @returns: sIcon
		 */

		getTypeIndicatorIcon : function(sIndicator) {
			var sIcon = "";

			if (sIndicator === "Delete") {
				sIcon = "sap-icon://delete";
			} else if (sIndicator === "Change") {
				sIcon = "sap-icon://edit";
			} 
			// else if (sIndicator === "New") {
			// 	sIcon = "sap-icon://add-favorite";
			// }

			return sIcon;
		},

		/**
		 * @LEI for US BLM 218 on 17.06.2019
		 * 
		 * @function: getTypeIndicatorVisibility
		 * @description: Set Type Indicator Visibility
		 * @param: sIndicator
		 * @returns: bVisible
		 */

		getTypeIndicatorVisibility : function(sIndicator) {

			var bVisible = false;

			if (sIndicator === "Delete" || sIndicator === "Change"
					|| sIndicator === "New") {
				bVisible = true;
			}

			return bVisible;
		},

		/**
		 * @LEI for US BLM 218 on 17.06.2019
		 * 
		 * @function: getTypeIndicatorState
		 * @description: Set Type Indicator Icon State
		 * @param: sIndicator
		 * @returns: sState
		 */

		getTypeIndicatorState : function(sIndicator) {

			var sState = "None";

			if (sIndicator === "Change") {
				sState = "Success";
			} else if (sIndicator === "Delete") {
				sState = "Error";
			} else if (sIndicator === "New") {
				sState = "None";
			}

			return sState;

		}


	};
});
