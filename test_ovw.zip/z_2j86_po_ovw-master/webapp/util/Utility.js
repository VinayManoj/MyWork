/**************************************************************************************************************************************
* Project                : Digital Propulsion 
* Module                 : V1
* Functional document    : ...
* Technical document     : ...
*-------------------------------------------------------------------------------------------------------------------------------------
* File name              : Utility.js
* Written by             : 
* Company                : Sopra Steria
*--------------------------------------------------------------------------------------------------------------------------------------
* File description       : This file is used to handle all the miscellaneous function
*--------------------------------------------------------------------------------------------------------------------------------------
***************************************************************************************************************************************/
sap.ui.define(["sap/ui/core/mvc/Controller", "sap/ui/model/json/JSONModel", "sap/ui/core/util/Export", "sap/ui/core/util/ExportTypeCSV", "sap/m/MessageBox"], function (Controller, JSONModel, Export, ExportTypeCSV, MessageBox) {
    "use strict";

    return {

        /**
		 * @function: getMessageExcelColumns
		 * @description: Construct message excel Columns
		 * @HJC on 22.03.2019
         */

        getMessageExcelColumns: function (sTab) {

            var aColumns;
            if (sTab === "POC" || sTab === "POU") {
                aColumns = [{
                    name: "Type",
                    template: {
                        content: "{Type}"
                    }
                }, {
                    name: "CAC",
                    template: {
                        content: "{CAC}"
                    }
                }, {
                    name: "Preq",
                    template: {
                        content: "{Preq}"
                    }
                }, {
                    name: "Item",
                    template: {
                        content: "{Item}"
                    }
                }, {
                    name: "Message",
                    template: {
                        content: "{Message}"
                    }
                }];

            }
            else if (sTab === "GRV" || sTab === "GRC") {
                aColumns = [{
                    name: "Type",
                    template: {
                        content: "{Type}"
                    }
                }, {
                    name: "MoveType",
                    template: {
                        content: "{MovType}"
                    }
                }, {
                    name: "CAC",
                    template: {
                        content: "{CAC}"
                    }
                }, {
                    name: "PO",
                    template: {
                        content: "{PO}"
                    }
                }, {
                    name: "Item",
                    template: {
                        content: "{Item}"
                    }
                }, {
                    name: "Message",
                    template: {
                        content: "{Message}"
                    }
                }];
            }
            else if (sTab === "POS") {
                aColumns = [{
                    name: "Type",
                    template: {
                        content: "{Type}"
                    }
                }, {
                    name: "Message",
                    template: {
                        content: "{Message}"
                    }
                }];
            }
            else if (sTab === "POP") {
                aColumns = [{
                    name: "Type",
                    template: {
                        content: "{Type}"
                    }
                }, {
                    name: "CAC",
                    template: {
                        content: "{CAC}"
                    }
                }, {
                    name: "PO",
                    template: {
                        content: "{PO}"
                    }
                }, {
                    name: "Message",
                    template: {
                        content: "{Message}"
                    }
                }];
            }
            return aColumns;
        },

        /**
		 * @function: getMessageExcelData
		 * @description: Construct data for message excel 
		 * @HJC on 22.03.2019
         */
        getMessageExcelData: function (oModel, oi18n, sTab) {

            var aData = oModel.oData;
            var aMessages = [], sMessage;
            if (sTab === "POC" || sTab === "POU") {

                for (var i = 0; i < aData.length; i++) {

                    var oErrors = {};
                    var sTitle = aData[i].title;
                    sMessage = sTitle.split(":")[1];

                    var aDetails = sTitle.match(/\d+/g);
                    if(aDetails.length > 2){
                        var sCAC = aDetails[0];
                        var sPreq = aDetails[1];
                        var sItem = aDetails[2];
                        var sPO = aDetails[3];
                    }
                    else{
                        var sPreq = aDetails[0];
                        var sItem = aDetails[1];
                        if (aData[i].type === "Success") {
                            sMessage = oi18n.getProperty("GRValidate.CommentSuccessMsg");
                        } else {
                            sMessage = oi18n.getProperty("GRValidate.CommentErrorMsg");
                        }

                    }

                    if (sPO && sTab === "POC") {
                        sMessage = "PO " + sPO + " " + oi18n.getProperty("manageCreatePO.successMsg");
                    }
                    //Capture action taken for PO Update
                    //Added by SSH on 15.04.19
                    // if (sTab === "POU" && aData[i].type === "Success")
                    // {
                    //     switch (airbus.ui.digital_propulsion.GLOBAL.POUAction) {
                    //         case "C":
                    //         sMessage = oi18n.getProperty("POUpdate.CreateSuccessMsg");
                    //         break;
                    //         case "U":
                    //         sMessage = oi18n.getProperty("POUpdate.UpdateSuccessMsg");
                    //         break;
                    //         case "D":
                    //         sMessage = oi18n.getProperty("POUpdate.DeleteSuccessMsg");
                    //         break;
                    //         default:
                    //         break;
                    //         }
                    // }

                    oErrors.Type = aData[i].type;
                    oErrors.CAC = sCAC;
                    oErrors.Preq = sPreq;
                    oErrors.Item = sItem;
                    oErrors.Message = sMessage;

                    aMessages.push(oErrors);
                }

            }
            else if (sTab === "GRV") {
                var sType, sMoveType, sCAC, sPO, sItem;
                for (var j = 0; j < aData.length; j++) {

                    var oErrors = {};
                    var sTitle = aData[j].title;

                    if (sTitle.indexOf(':') !== -1) {
                        sMessage = sTitle.split(":")[1].trim();
                    }
                    else {
                        sMessage = '';
                    }

                    var aDetails = sTitle.match(/\d+/g);

                    if (aDetails.length > 3){
                        sType = aData[j].type;
                        sMoveType = aDetails[0];
                        sCAC = aDetails[1];
                        sPO = aDetails[2];
                        sItem = aDetails[3];
    
                        if (sMessage == "") {
                            sMessage = oi18n.getProperty("GRValidation.successMsg");
                        }
                    }
                    else {
                        sType = aData[j].type;
                        sMoveType = "X";
                        sCAC = aDetails[2];
                        sPO = aDetails[0];
                        sItem = aDetails[1];                        

                        if (sType === "Success") {
                            sMessage = oi18n.getProperty("GRValidate.CommentSuccessMsg");
                        } else {
                            sMessage = oi18n.getProperty("GRValidate.CommentErrorMsg");
                        }

                    }

                    oErrors.Type = sType;
                    oErrors.MovType = sMoveType;
                    oErrors.CAC = sCAC;
                    oErrors.PO = sPO;
                    oErrors.Item = sItem;
                    oErrors.Message = sMessage;

                    aMessages.push(oErrors);

                }
            }
            else if (sTab === "POS") {
                for (var k = 0; k < aData.length; k++) {

                    var oErrors = {};
                    oErrors.Type = aData[k].type;
                    oErrors.Message = aData[k].title;

                    aMessages.push(oErrors);
                }
            }
            else if (sTab === "POP") {
                for (var l = 0; l < aData.length; l++) {

                    var oErrors = {};
                    oErrors.Type = aData[l].type;

                    if (oErrors.Type === "Success") {
                        oErrors.Message = oi18n.getProperty("POPublic.successMsg");
                    } else {
                        oErrors.Message = oi18n.getProperty("POPublic.errorMsg");
                    }


                    var aDetails = aData[l].title.match(/\d+/g);

                    if (aDetails.length === 2) {
                        var sCAC = aDetails[0];
                        var sPO = aDetails[1];
                        oErrors.Message = oErrors.Message + " " + sCAC + " " + oi18n.getProperty("POPublic.PO") + " " + sPO;
                    }
                    else {
                        var sPO = aDetails[0];
                        oErrors.Message = oErrors.Message + " " + oi18n.getProperty("POPublic.PO") + " " + sPO;
                    }
                    oErrors.CAC = sCAC;
                    oErrors.PO = sPO;

                    aMessages.push(oErrors);
                }
            }
            else if (sTab === "GRC") {
                var sType, sMoveType, sCAC, sPO, sItem;
                for (var m = 0; m < aData.length; m++) {

                    var oErrors = {};
                    var sTitle = aData[m].title;

                    var aDetails = sTitle.match(/\d+/g);

                    sType = aData[m].type;
                    sMoveType = aDetails[0];
                    sCAC = aDetails[1];
                    sPO = aDetails[2];
                    sItem = aDetails[3];


                    if (sType === "Success") {
                        sMessage = oi18n.getProperty("GRCancellation.SuccessMsg");
                    } else {
                        sMessage = oi18n.getProperty("GRCancellation.ErrorMsg");
                    }

                    oErrors.Type = sType;
                    oErrors.MovType = sMoveType;
                    oErrors.CAC = sCAC;
                    oErrors.PO = sPO;
                    oErrors.Item = sItem;
                    oErrors.Message = sMessage;

                    aMessages.push(oErrors);

                }
            }

            return aMessages;

        },

        /**
		 * @function: exportMessageExcel
		 * @description: Export message excel 
		 * @HJC on 22.03.2019
         */
        exportMessageExcel: function (aMessages, aColumns, sDocTitle, oi18n) {
            var oMessageModel = new JSONModel();
            oMessageModel.setData(aMessages);

            var oExport = new Export({

                // Type that will be used to generate
                // the content. Own
                // ExportType's can be created to
                // support other formats
                exportType: new ExportTypeCSV({
                    separatorChar: ","
                }),

                // Pass in the model created above
                models: oMessageModel,

                // binding information for the rows
                // aggregation
                rows: {
                    path: "/"
                },

                // column definitions with column name
                // and binding info
                // for the content

                columns: aColumns
            });

            var oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
                pattern: "YYYYMMdd"
            });
            var sDateFormatted = oDateFormat.format(new Date());

            // download exported file
            oExport.saveFile(sDocTitle + sDateFormatted).catch(function (oError) {
                MessageBox.error(oi18n.getProperty("exportError") + oError);
            }).then(function () {
                oExport.destroy();
            });
        },

        /**
         * @HJC for US on 13.05.2019
         * 
         * @function: onCommentUpdate
         * @description: When user add comments
         * @param: 
         */

        onCommentUpdate: function (oEvent) {

            var oSource = oEvent.getSource();
            var oIcon = oSource.getParent().getItems()[1];

            if (oSource.getValue().length > 0) {
                oIcon.setVisible(true);
            }
            else {
                oIcon.setVisible(false);
            }
        },

        /**
         * @HJC for US BLM 87 on 12.03.2019
         * 
         * @function: onCommentMorePress
         * @description: Open dialog to manage the comment
         * @param: 
         */

        onCommentMorePress: function (oEvent) {

            var oSource = oEvent.getSource();
            var oText = oSource.getParent().getItems()[0];
            this._sPOCommentBindingPath = oText.getBindingContext().sPath;

            if (!this._oPOCommentDialog) {
                this._oPOCommentDialog = sap.ui.xmlfragment("airbus.ui.digital_propulsion.fragment.POScheduleComment", this);
                this.getView().addDependent(this._oPOCommentDialog);
            }

            this._oPOCommentDialog.bindElement({
                path: this._sPOCommentBindingPath
            });

            this._oPOCommentDialog.open();

        },

        /**
         * @HJC for US BLM  on 14.06.2019
         * 
         * @function: onChangeMorePress
         * @description: Open dialog to See all Change Description for Po Publish
         * @param: 
         */
        onChangeMorePress: function (oEvent) {
            var oSource = oEvent.getSource();
            var oText = oSource.getParent().getItems()[0];
            var sText = oText.mBindingInfos.text.binding.oValue.split(',');
            var sTextLine = sText[0];
            for(var i=1;i<sText.length;i++){
                sTextLine = sTextLine + '\n' +sText[i].trim();
            }
            oText.mBindingInfos.text.binding.setValue(sTextLine);
            this._sPOCommentBindingPath = oText.getBindingContext().sPath;

            if (!this._oPOChangeDesDialog) {
                this._oPOChangeDesDialog = sap.ui.xmlfragment("airbus.ui.digital_propulsion.fragment.ManageChangeDes", this);
                this.getView().addDependent(this._oPOChangeDesDialog);
            }

            this._oPOChangeDesDialog.bindElement({
                path: this._sPOCommentBindingPath
            });

            this._oPOChangeDesDialog.open();
        },

        /**
         * @HJC for US BLM  on 19.07.2019
         * 
         * @function: onListItemPress
         * @description: Open PO Card on click of PO Number only
         * @param: 
         */

        onListItemPress: function (oEvent) {
            var sPonumber;
            var oi18nModel = this.getModel("i18n");
            //Commented by SSH on 08.01.2020 to navigate with PO number only
            // var sPath = oEvent.getParameter("rowBindingContext").getPath();
            // sPonumber = this.getModel().getProperty(sPath).Po;
            sPonumber = oEvent.getSource().getText();
            
            if (!sPonumber && sPonumber !== "") {
                sPonumber = this.getModel().getProperty(sPath).Ponumber;
            }

            if (sPonumber !== "") {

                if (sPonumber.indexOf("67") == 0 || sPonumber.indexOf("70") == 0 || sPonumber.indexOf("65") == 0){
                    var sDisplayPOUrl = window.location.origin + "/sap/bc/ui2/flp#ZSO_2J86_DISP_PO-display&//C_PurchaseOrderTP(PurchaseOrder='" + sPonumber
                    + "',DraftUUID=guid'00000000-0000-0000-0000-000000000000',IsActiveEntity=true)";

                var sWindow = Math.random().toString(36).replace(/[^a-z]+/g, '');
                var oWin = window.open(sDisplayPOUrl, sWindow);
                oWin.focus();
                }
                else{
                    sap.m.MessageToast.show(oi18nModel.getProperty("POCard.wrongPOMsg"));
                }
                
            }
            else {
                sap.m.MessageToast.show(oi18nModel.getProperty("POCard.noPOMsg"));
            }


        }


    };
});