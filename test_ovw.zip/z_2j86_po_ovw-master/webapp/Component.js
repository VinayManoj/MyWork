sap.ui.define([ "sap/ui/core/UIComponent", "sap/ui/Device" ], function(UIComponent, Device) {
    "use strict";

    return UIComponent.extend("airbus.ui.propulsion_overview.Component", {

	metadata : {
		manifest : "json",
		config : { fullWidth : true}
	},

	/**
	 * The component is initialized by UI5 automatically during the startup
	 * of the app and calls the init method once.
	 * 
	 * @public
	 * @override
	 */
	init : function() {
	    // call the base component's init function
	    UIComponent.prototype.init.apply(this, arguments);

	    // enable routing
	    var oRouter = this.getRouter();
	    if (oRouter) {
		oRouter.initialize();
	    }

	    // Initialize userData model
	    var oDefaultModel = new sap.ui.model.json.JSONModel();
		this.setModel(oDefaultModel, "default");
		
		// Initialize Date Filter Model
		var oDateModel = new sap.ui.model.json.JSONModel();
		this.setModel(oDateModel, "date");

	    var sProgram = "N";
		
	    var oModel = this.getModel("digital");
	          

	},

	_readDefaultSelectionSuccess : function(data) {
	    var oDefaultModel = this.getModel("default");
	    var aPlant = [];
	    var aSalesorg = [];
	    var aDivision = [];
	    var aDischannel = [];
	    var aPurorg = [];
	    if (data.results) {
		var aModelData = data.results;
		for (var i = 0; i < aModelData.length; i++) {
		    aPlant.push(aModelData[i].Plant);
		    aSalesorg.push(aModelData[i].Salesorg);
		    aDivision.push(aModelData[i].Division);
		    aDischannel.push(aModelData[i].Dischannel);
		    aPurorg.push(aModelData[i].Purorg);
		}
		oDefaultModel.setProperty("/plant", aPlant);
		oDefaultModel.setProperty("/Salesorg", aSalesorg);
		oDefaultModel.setProperty("/Division", aDivision);
		oDefaultModel.setProperty("/Dischannel", aDischannel);
		oDefaultModel.setProperty("/Purorg", aPurorg);
	    }

	},

	_readDefaultSelectionError : function() {
	    sap.m.MessageToast.show("Error raised");
	}
    });

});