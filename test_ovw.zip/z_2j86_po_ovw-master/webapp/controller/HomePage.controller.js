/**************************************************************************************************************************************
* Project                : Digital Propulsion              
* Module                 :                                                                                        
* Functional document    : ...                                
* Technical document     : ...                                    
*-------------------------------------------------------------------------------------------------------------------------------------
* File name              : HomePage.controller.js                             
* Written by             : SOPRA Team                                       
* Company                : Sopra Steria                                                
* Creation date          : 21.01.2020                                            
*--------------------------------------------------------------------------------------------------------------------------------------
* File description       : This controller contains the functions that are supposed to be called inside several screens in the application
*--------------------------------------------------------------------------------------------------------------------------------------
* Last modification date :                                     
* Author                 :                                                           
* Description            :                                                                                                       
* Transport order        :                                                                          
***************************************************************************************************************************************/


sap.ui.define([
	"airbus/ui/propulsion_overview/controller/BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("airbus.ui.propulsion_overview.controller.HomePage", {
		
		onTilePress : function(){
		}

	});

});